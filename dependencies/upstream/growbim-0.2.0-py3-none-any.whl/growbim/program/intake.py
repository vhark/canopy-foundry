"""Source-backed aggregate program intake and cross-record semantic checks."""

from __future__ import annotations

from functools import lru_cache

from opencea.contracts import ContractError, dumps, loads, parse_uuid, validate


def new_program(project_id: str, name: str) -> dict:
    try:
        project_id = parse_uuid(project_id)
    except ContractError as exc:
        raise ContractError("invalid project UUID", code="invalid_uuid") from exc
    program = dict(
        schema_version="0.1",
        project_id=project_id,
        name=name,
        sources=[],
        statements=[],
        standards=[],
        requirements=[],
        hypotheses=[],
        resolutions=[],
        extensions={},
    )
    validate_program(program)
    return program


def validate_program(program: dict) -> None:
    # Keep Python-only container/type errors visible before canonical JSON caching.
    stack = [program]
    while stack:
        value = stack.pop()
        if isinstance(value, dict):
            if any(not isinstance(key, str) for key in value):
                validate("program", program)
            stack.extend(value.values())
        elif isinstance(value, list):
            stack.extend(value)
        elif value is not None and type(value) not in (str, int, float, bool):
            validate("program", program)
    # Content-keyed caching cannot be invalidated incorrectly when callers mutate dictionaries.
    _validate_program_canonical(dumps(program))


@lru_cache(maxsize=128)
def _validate_program_canonical(raw: bytes) -> None:
    program = loads(raw)
    validate("program", program)
    project_id = program["project_id"]
    ids: set[str] = set()
    for collection in (
        "sources",
        "statements",
        "standards",
        "requirements",
        "hypotheses",
        "resolutions",
    ):
        for record in program[collection]:
            identifier = record["id"]
            if identifier in ids:
                raise ContractError(f"duplicate record id: {identifier}")
            ids.add(identifier)
    sources = {item["id"] for item in program["sources"]}
    hypotheses = {item["id"] for item in program["hypotheses"]}
    hypothesis_records = {item["id"]: item for item in program["hypotheses"]}
    standards = {item["id"] for item in program["standards"]}
    requirements = {item["id"] for item in program["requirements"]}
    statements = program["statements"]
    statements_by_id = {item["id"]: item for item in statements}
    inferred_sources = {
        source_id
        for record in (
            *program["hypotheses"],
            *(s for s in statements if s["kind"] == "hypothesized"),
        )
        for source_id in record["source_ids"]
    }
    for collection in ("statements", "standards", "requirements", "hypotheses", "resolutions"):
        for record in program[collection]:
            for source_id in record.get("source_ids", []):
                if source_id not in sources:
                    raise ContractError(f"unknown source {source_id} in {collection}")
    for statement in statements:
        if statement["subject_id"] != project_id:
            raise ContractError("concept statements must refer to the aggregate project")
        if statement["kind"] == "verified":
            evidence = statement["verification"]["evidence_ids"]
            if not set(evidence).issubset(sources):
                raise ContractError("verified evidence must reference independent sources")
            if set(evidence).intersection(inferred_sources):
                raise ContractError("hypothesis provenance cannot independently verify a statement")
    for hypothesis in program["hypotheses"]:
        if hypothesis["subject_id"] != project_id:
            raise ContractError("concept hypothesis must refer to the aggregate project")
    for standard in program["standards"]:
        if standard.get("reviewer", "") == "" and standard["status"] != "proposed":
            raise ContractError("reviewed standards applicability requires named reviewer")
    for requirement in program["requirements"]:
        if requirement["subject_id"] != project_id:
            raise ContractError("concept requirement must refer to project")
        if not set(requirement.get("standard_ids", [])).issubset(standards):
            raise ContractError("requirement refers to unknown standard")
        if not set(requirement.get("depends_on", [])).issubset(requirements):
            raise ContractError("requirement refers to unknown dependency")
    resolved: set[str] = set()
    for resolution in program["resolutions"]:
        hypothesis_id = resolution["hypothesis_id"]
        if hypothesis_id not in hypotheses:
            raise ContractError("resolution refers to unknown hypothesis")
        if hypothesis_id in resolved:
            raise ContractError("hypothesis has conflicting duplicate resolutions")
        resolved.add(hypothesis_id)
        if resolution["decision"] == "confirmed":
            reported = statements_by_id.get(resolution["statement_id"])
            hypothesis = hypothesis_records[hypothesis_id]
            if (
                reported is None
                or reported["kind"] != "reported"
                or reported["subject_id"] != hypothesis["subject_id"]
                or reported["property"] != hypothesis["property"]
                or reported["value"] != hypothesis["value"]
                or not set(reported["source_ids"]).intersection(resolution["source_ids"])
            ):
                raise ContractError(
                    "confirmation must reference a matching sourced reported statement"
                )
