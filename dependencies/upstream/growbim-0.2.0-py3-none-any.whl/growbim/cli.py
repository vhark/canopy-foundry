"""JSON CLI with explicit, non-interchangeable offline and authenticated service modes."""

from __future__ import annotations

import argparse
import json
import os
import stat
import sys
from pathlib import Path
from uuid import uuid4

from opencea.contracts import ContractError, dumps, loads

from growbim.client import ServiceClient, ServiceError
from growbim.jobs.runner import JobLimits
from growbim.jobs.store import LocalJobStore
from growbim.project.artifacts import DESIGN_FILES
from growbim.project.revisions import MAX_ARCHIVE, MAX_FILE
from growbim.project.store import LocalProjectStore
from growbim.requirements.evaluate import assess_program
from growbim.requirements.questions import QuestionError, question_page
from growbim.storage import atomic_write


def _read_input(path: Path, maximum: int) -> bytes:
    with path.open("rb") as stream:
        data = stream.read(maximum + 1)
    if len(data) > maximum:
        raise ContractError(f"input exceeds {maximum} bytes")
    return data


def _read_design_file(path: Path, maximum: int) -> bytes:
    if any(parent.is_symlink() for parent in path.parents):
        raise ContractError("design input directory must not contain a symlink")
    try:
        descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
        with os.fdopen(descriptor, "rb") as stream:
            info = os.fstat(stream.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_size > maximum:
                raise ContractError("design input must be a bounded regular file")
            data = stream.read(maximum + 1)
    except OSError as exc:
        raise ContractError("cannot read design input as a regular file") from exc
    if len(data) > maximum:
        raise ContractError("design input exceeds size limit")
    return data


def _dispatch(
    args: argparse.Namespace, store: LocalProjectStore | None, client: ServiceClient | None
) -> dict:
    if args.command == "create":
        if client:
            return client.create(args.name, args.request_id)
        return store.create(args.name, args.request_id or str(uuid4()), args.project_id)
    if args.command == "inspect":
        return client.inspect(args.project_id) if client else store.inspect(args.project_id)
    if args.command == "accept":
        program = loads(_read_input(args.program, MAX_FILE))
        return (
            client.accept(args.project_id, args.expected_revision, args.request_id, program)
            if client
            else store.accept(args.project_id, args.expected_revision, args.request_id, program)
        )
    if args.command == "design":
        artifacts = {
            name: _read_design_file(args.directory / name, MAX_FILE) for name in DESIGN_FILES
        }
        decision = loads(_read_design_file(args.decision, MAX_FILE))
        accept = client.accept_design if client else store.accept_design
        return accept(args.project_id, args.expected_revision, args.request_id, artifacts, decision)
    if args.command == "assess":
        if client:
            return client.assess(args.project_id)
        snapshot = store.inspect(args.project_id)
        return dict(
            project_id=args.project_id,
            revision=snapshot["revision"],
            assessment=assess_program(snapshot["program"]),
        )
    if args.command == "export":
        data = client.export(args.project_id) if client else store.export(args.project_id)
        atomic_write(args.output, data)
        return dict(project_id=args.project_id, archive=str(args.output), bytes=len(data))
    if args.command == "import":
        return store.import_archive(_read_input(args.archive, MAX_ARCHIVE))
    if args.command == "questions":
        if args.question_command == "list":
            if client:
                return client.list_questions(
                    args.project_id, offset=args.offset, limit=args.limit, category=args.category
                )
            snapshot = store.inspect(args.project_id)
            return {
                "project_id": snapshot["project_id"],
                "revision": snapshot["revision"],
                **question_page(
                    snapshot["program"],
                    offset=args.offset,
                    limit=args.limit,
                    category=args.category,
                ),
            }
        value = loads(_read_input(args.value, MAX_FILE))
        answer = client.answer_question if client else store.answer_question
        return answer(
            args.project_id,
            args.expected_revision,
            args.request_id,
            args.question_id,
            args.statement_id,
            args.source_id,
            value,
        )
    jobs = None if client else LocalJobStore(args.root)
    if args.job_command == "submit":
        submit = client.submit_job if client else jobs.submit
        return submit(args.project_id, args.expected_revision, args.request_id)
    if args.job_command == "list":
        listing = client.list_jobs if client else jobs.list
        return listing(offset=args.offset, limit=args.limit)
    if args.job_command == "inspect":
        return client.inspect_job(args.job_id) if client else jobs.inspect(args.job_id)
    if args.job_command == "cancel":
        return client.cancel_job(args.job_id) if client else jobs.cancel(args.job_id)
    if args.job_command == "run":
        return jobs.run(args.job_id, limits=JobLimits(trusted_local=args.trusted_local))
    if args.job_command == "recover":
        return jobs.recover()
    data = (
        client.artifact(args.job_id, args.name) if client else jobs.artifact(args.job_id, args.name)
    )
    atomic_write(args.output, data)
    return dict(job_id=args.job_id, name=args.name, output=str(args.output), bytes=len(data))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="growbim")
    authority = parser.add_mutually_exclusive_group()
    authority.add_argument(
        "--root", type=Path, help="Offline store (default: ~/.local/share/growbim)"
    )
    authority.add_argument(
        "--server", help="Explicit HTTP(S) service origin; never falls back offline"
    )
    parser.add_argument(
        "--credential-file", type=Path, help="Owner-only access-key file for --server"
    )
    sub = parser.add_subparsers(dest="command", required=True)
    create = sub.add_parser("create")
    create.add_argument("name")
    create.add_argument("--project-id", default=None)
    create.add_argument("--request-id", default=None)
    inspect = sub.add_parser("inspect")
    inspect.add_argument("project_id")
    accept = sub.add_parser("accept")
    accept.add_argument("project_id")
    accept.add_argument("--expected-revision", required=True)
    accept.add_argument("--request-id", required=True)
    accept.add_argument("--program", type=Path, required=True)
    assess = sub.add_parser("assess")
    assess.add_argument("project_id")
    design = sub.add_parser("design")
    design_sub = design.add_subparsers(dest="design_command", required=True)
    design_accept = design_sub.add_parser("accept")
    design_accept.add_argument("project_id")
    design_accept.add_argument("--expected-revision", required=True)
    design_accept.add_argument("--request-id", required=True)
    design_accept.add_argument("--directory", type=Path, required=True)
    design_accept.add_argument("--decision", type=Path, required=True)
    export = sub.add_parser("export")
    export.add_argument("project_id")
    export.add_argument("--output", type=Path, required=True)
    importing = sub.add_parser("import")
    importing.add_argument("archive", type=Path)
    questions = sub.add_parser("questions")
    question_sub = questions.add_subparsers(dest="question_command", required=True)
    question_list = question_sub.add_parser("list")
    question_list.add_argument("project_id")
    question_list.add_argument("--offset", type=int, default=0)
    question_list.add_argument("--limit", type=int, default=50)
    question_list.add_argument("--category")
    question_answer = question_sub.add_parser("answer")
    question_answer.add_argument("project_id")
    question_answer.add_argument("question_id")
    question_answer.add_argument("--expected-revision", required=True)
    question_answer.add_argument("--request-id", required=True)
    question_answer.add_argument("--statement-id", required=True)
    question_answer.add_argument("--source-id", required=True)
    question_answer.add_argument("--value", type=Path, required=True)
    jobs = sub.add_parser("jobs")
    job_sub = jobs.add_subparsers(dest="job_command", required=True)
    submit = job_sub.add_parser("submit")
    submit.add_argument("project_id")
    submit.add_argument("--expected-revision", required=True)
    submit.add_argument("--request-id", required=True)
    listing = job_sub.add_parser("list")
    listing.add_argument("--offset", type=int, default=0)
    listing.add_argument("--limit", type=int, default=50)
    detail = job_sub.add_parser("inspect")
    detail.add_argument("job_id")
    run = job_sub.add_parser("run")
    run.add_argument("job_id")
    run.add_argument("--trusted-local", action="store_true")
    cancel = job_sub.add_parser("cancel")
    cancel.add_argument("job_id")
    job_sub.add_parser("recover")
    artifact = job_sub.add_parser("artifact")
    artifact.add_argument("job_id")
    artifact.add_argument("name")
    artifact.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    if bool(args.server) != bool(args.credential_file):
        parser.error("--server and --credential-file must be supplied together")
    if args.server:
        if args.command == "import" or (
            args.command == "jobs" and args.job_command in {"run", "recover"}
        ):
            parser.error(
                "This command is offline-only; the service owns its accepted state and workers"
            )
        if args.command == "create" and (args.project_id is not None or args.request_id is None):
            parser.error("Service creation requires --request-id and cannot accept --project-id")
    else:
        args.root = args.root or Path.home() / ".local" / "share" / "growbim"
    try:
        client = (
            ServiceClient(args.server, credential_file=args.credential_file)
            if args.server
            else None
        )
        store = None if client else LocalProjectStore(args.root)
        result = _dispatch(args, store, client)
        sys.stdout.buffer.write(dumps(result) + b"\n")
        return 0
    except ServiceError as exc:
        error = {"code": exc.code, "detail": exc.detail}
        if exc.status is not None:
            error["status"] = exc.status
        print(json.dumps(error), file=sys.stderr)
        return 1
    except QuestionError as exc:
        print(json.dumps({"code": exc.code, "detail": exc.detail}), file=sys.stderr)
        return 1
    except ContractError as exc:
        print(json.dumps({"code": exc.code, "detail": str(exc)}), file=sys.stderr)
        return 1
    except OSError as exc:
        print(json.dumps({"code": "storage_unavailable", "detail": str(exc)}), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
