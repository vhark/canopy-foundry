"""Explicit HTTP authority; service failures never invoke an offline store."""

from __future__ import annotations

import base64
import hashlib
import ipaddress
import math
import os
import re
import ssl
import stat
from http.client import HTTPException
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode, urlsplit
from urllib.request import HTTPRedirectHandler, HTTPSHandler, ProxyHandler, Request, build_opener

from opencea.contracts import ContractError, dumps, loads, parse_uuid, validate
from rfc3339_validator import validate_rfc3339

from growbim.program.intake import validate_program
from growbim.project.artifacts import DESIGN_FILES, design_request
from growbim.project.revisions import MAX_ARCHIVE
from growbim.storage import validate_digest

MAX_JSON_BYTES = 8 * 1024 * 1024
MAX_ARTIFACT_BYTES = 1024 * 1024


class ServiceError(Exception):
    def __init__(self, code: str, detail: str, status: int | None = None):
        super().__init__(detail)
        self.code = code
        self.detail = detail
        self.status = status


class _NoRedirects(HTTPRedirectHandler):
    def redirect_request(self, request, response, code, message, headers, new_url):
        return None


def _origin(server: str) -> str:
    if not isinstance(server, str) or any(c.isspace() or ord(c) < 32 or c == "\\" for c in server):
        raise ServiceError("invalid_server", "Use an explicit HTTP(S) service origin")
    try:
        parsed = urlsplit(server)
        port = parsed.port
        hostname = parsed.hostname
    except ValueError as exc:
        raise ServiceError("invalid_server", "Invalid service origin") from exc
    if (
        parsed.scheme not in {"https", "http"}
        or not hostname
        or parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
        or parsed.path not in {"", "/"}
        or port == 0
    ):
        raise ServiceError(
            "invalid_server", "Use an origin without credentials, path, query or fragment"
        )
    if parsed.scheme == "http":
        try:
            loopback = ipaddress.ip_address(hostname).is_loopback
        except ValueError:
            loopback = hostname == "localhost"
        if not loopback:
            raise ServiceError(
                "insecure_server", "Plain HTTP credentials are permitted only on loopback"
            )
    return f"{parsed.scheme}://{parsed.netloc}"


def _credential(path: Path) -> str:
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
        with os.fdopen(fd, "rb") as stream:
            info = os.fstat(stream.fileno())
            if (
                not stat.S_ISREG(info.st_mode)
                or info.st_mode & 0o077
                or info.st_uid != os.geteuid()
                or info.st_size > 4096
            ):
                raise ServiceError(
                    "invalid_credential", "Credential must be a private, owner-only regular file"
                )
            data = stream.read(4097)
    except (OSError, ValueError) as exc:
        raise ServiceError("invalid_credential", "Cannot read the private credential file") from exc
    try:
        token = data.decode("ascii").strip()
    except UnicodeError as exc:
        raise ServiceError("invalid_credential", "Credential is not an ASCII bearer token") from exc
    if (
        len(data) > 4096
        or not 1 <= len(token) <= 1024
        or not re.fullmatch(r"[A-Za-z0-9._~+/-]+=*", token)
    ):
        raise ServiceError("invalid_credential", "Credential file must contain one bearer token")
    return token


class ServiceClient:
    """A named service and private access-key file, with no implicit local mode."""

    def __init__(self, server: str, *, credential_file: Path, timeout: float = 15):
        self.origin = _origin(server)
        if (
            isinstance(timeout, bool)
            or not isinstance(timeout, (int, float))
            or not math.isfinite(timeout)
            or not 0 < timeout <= 120
        ):
            raise ServiceError(
                "invalid_request", "Request timeout must be finite and between 0 and 120 seconds"
            )
        self.timeout = timeout
        self._token = _credential(Path(credential_file))
        # Do not forward credentials through environment-selected proxies or redirects.
        self._opener = build_opener(
            ProxyHandler({}), _NoRedirects(), HTTPSHandler(context=ssl.create_default_context())
        )

    def _request(
        self,
        method: str,
        path: str,
        *,
        body: dict | None = None,
        maximum: int = MAX_JSON_BYTES,
        media_type: str = "application/json",
    ) -> bytes:
        if not path.startswith("/api/v1/"):
            raise ServiceError("invalid_request", "Service operations must use the versioned API")
        data = None if body is None else dumps(body)
        if data is not None and len(data) > 2 * 1024 * 1024:
            raise ServiceError("invalid_request", "Request exceeds the service's 2 MiB JSON limit")
        headers = {
            "Authorization": f"Bearer {self._token}",
            "Accept": media_type,
            "Accept-Encoding": "identity",
        }
        if data is not None:
            headers["Content-Type"] = "application/json"
        request = Request(self.origin + path, data=data, headers=headers, method=method)
        try:
            with self._opener.open(request, timeout=self.timeout) as response:
                if response.headers.get_content_type() != media_type:
                    raise ServiceError(
                        "invalid_response",
                        "Service returned an unexpected content type",
                        response.status,
                    )
                result = response.read(maximum + 1)
                if len(result) > maximum:
                    raise ServiceError(
                        "invalid_response",
                        "Service response exceeds the declared byte limit",
                        response.status,
                    )
                return result
        except HTTPError as exc:
            with exc:
                if 300 <= exc.code < 400:
                    raise ServiceError(
                        "service_redirect",
                        "Service redirect refused; credentials were not forwarded",
                        exc.code,
                    ) from None
                code, detail = f"http_{exc.code}", f"Service request failed (HTTP {exc.code})"
                try:
                    raw = exc.read(8193)
                    payload = loads(raw) if len(raw) <= 8192 else {}
                    candidate = payload.get("code")
                    if (
                        isinstance(candidate, str)
                        and candidate != self._token
                        and re.fullmatch(r"[a-z][a-z0-9_]{0,63}", candidate)
                    ):
                        code = candidate
                    if isinstance(payload.get("detail"), str):
                        detail = payload["detail"].replace(self._token, "[redacted]")[:1024]
                except (ContractError, OSError, HTTPException):
                    pass
                raise ServiceError(code, detail, exc.code) from None
        except (URLError, OSError, HTTPException) as exc:
            raise ServiceError(
                "service_unavailable",
                "Could not complete the service request; no local action was taken",
            ) from exc

    def _json(self, method: str, path: str, body: dict | None = None) -> dict:
        raw = self._request(method, path, body=body)
        try:
            return loads(raw)
        except ContractError as exc:
            raise ServiceError("invalid_response", "Service returned invalid JSON") from exc

    @staticmethod
    def _timestamp(value: object) -> bool:
        return isinstance(value, str) and validate_rfc3339(value)

    @classmethod
    def _job(cls, body: dict, job_id: str | None = None) -> dict:
        try:
            identifier = parse_uuid(body["id"])
            if job_id is not None and identifier != job_id:
                raise ContractError("wrong job identity")
            parse_uuid(body["request_id"])
            parse_uuid(body["project_id"])
            if body["actor_id"] is not None:
                parse_uuid(body["actor_id"])
            validate_digest(body["revision"])
            if (
                not isinstance(body["project_name"], str)
                or not body["project_name"]
                or body["operation"] != "assess_program"
                or body["status"] not in {"queued", "running", "succeeded", "failed", "cancelled"}
                or not isinstance(body["stage"], str)
                or not body["stage"]
                or type(body["cancel_requested"]) is not bool
                or not cls._timestamp(body["created_at"])
                or any(
                    value is not None and not cls._timestamp(value)
                    for value in (body["started_at"], body["finished_at"])
                )
                or not isinstance(body["artifacts"], list)
            ):
                raise ContractError("invalid job fields")
            error = body["error"]
            if error is not None and (
                not isinstance(error, dict)
                or not isinstance(error.get("code"), str)
                or not isinstance(error.get("detail"), str)
            ):
                raise ContractError("invalid job error")
            for artifact in body["artifacts"]:
                if (
                    not isinstance(artifact, dict)
                    or not isinstance(artifact.get("name"), str)
                    or artifact.get("kind") not in {"result", "log"}
                    or not isinstance(artifact.get("media_type"), str)
                    or type(artifact.get("bytes")) is not int
                    or not 0 <= artifact["bytes"] <= MAX_ARTIFACT_BYTES
                ):
                    raise ContractError("invalid job artifact")
                validate_digest(artifact["sha256"])
        except (KeyError, TypeError, ContractError) as exc:
            raise ServiceError("invalid_response", "Service returned an invalid job") from exc
        return body

    @classmethod
    def _page(cls, body: dict, offset: int, limit: int, presenter) -> dict:
        try:
            if (
                type(body["offset"]) is not int
                or body["offset"] != offset
                or type(body["limit"]) is not int
                or body["limit"] != limit
                or not isinstance(body["items"], list)
                or len(body["items"]) > limit
            ):
                raise ContractError("invalid page")
            for item in body["items"]:
                presenter(item)
        except (KeyError, TypeError, ContractError) as exc:
            raise ServiceError("invalid_response", "Service returned an invalid page") from exc
        return body

    @classmethod
    def _project_summary(cls, body: dict) -> dict:
        try:
            parse_uuid(body["id"])
            validate_digest(body["revision"])
            if (
                not isinstance(body["name"], str)
                or not body["name"]
                or not cls._timestamp(body["updated_at"])
            ):
                raise ContractError("invalid project summary")
        except (KeyError, TypeError, ContractError) as exc:
            raise ServiceError(
                "invalid_response", "Service returned an invalid project summary"
            ) from exc
        return body

    @staticmethod
    def _snapshot(body: dict, project_id: str | None = None) -> dict:
        try:
            if not isinstance(body.get("id"), str):
                raise ContractError("project identity must be a UUID string")
            identifier = parse_uuid(body["id"])
            revision = validate_digest(body["revision"])
            validate_program(body["program"])
            if body["program"]["project_id"] != identifier or project_id not in {None, identifier}:
                raise ContractError("project identity does not match")
        except (KeyError, TypeError, ContractError) as exc:
            raise ServiceError(
                "invalid_response", "Service returned an invalid project snapshot"
            ) from exc
        return {"project_id": identifier, "revision": revision, "program": body["program"]}

    @staticmethod
    def _identifier(value: str) -> str:
        return parse_uuid(value)

    def list_questions(
        self,
        project_id: str,
        *,
        offset: int = 0,
        limit: int = 50,
        category: str | None = None,
    ) -> dict:
        identifier = self._identifier(project_id)
        if type(offset) is not int or offset < 0 or type(limit) is not int or not 1 <= limit <= 100:
            raise ServiceError("invalid_request", "Invalid question page bounds")
        if category is not None and (not isinstance(category, str) or not category):
            raise ServiceError("invalid_request", "category must be a nonempty string")
        params = {"offset": offset, "limit": limit}
        if category is not None:
            params["category"] = category
        body = self._json("GET", f"/api/v1/projects/{identifier}/questions/?{urlencode(params)}")
        try:
            if self._identifier(body["project_id"]) != identifier:
                raise ContractError("question page has wrong project identity")
            revision = validate_digest(body["revision"])
            items = body["items"]
            total = body["total"]
            if (
                type(body["offset"]) is not int
                or body["offset"] != offset
                or type(body["limit"]) is not int
                or body["limit"] != limit
                or type(total) is not int
                or total < 0
                or not isinstance(items, list)
                or len(items) != min(limit, max(0, total - offset))
            ):
                raise ContractError("invalid question page metadata")
            for item in items:
                validate("question", item)
        except (KeyError, TypeError, ContractError) as exc:
            raise ServiceError(
                "invalid_response", "Service returned an invalid question page"
            ) from exc
        return {
            "project_id": identifier,
            "revision": revision,
            "items": items,
            "offset": offset,
            "limit": limit,
            "total": total,
        }

    def answer_question(
        self,
        project_id: str,
        expected_revision: str,
        request_id: str,
        question_id: str,
        statement_id: str,
        source_id: str,
        value: dict,
    ) -> dict:
        identifier = self._identifier(project_id)
        expected = validate_digest(expected_revision)
        request = self._identifier(request_id)
        statement = self._identifier(statement_id)
        source = self._identifier(source_id)
        if not isinstance(question_id, str) or not question_id:
            raise ServiceError("invalid_request", "question_id must be a nonempty string")
        body = self._json(
            "POST",
            f"/api/v1/projects/{identifier}/questions/{quote(question_id, safe='')}/answer/",
            {
                "expected_revision": expected,
                "request_id": request,
                "statement_id": statement,
                "source_id": source,
                "value": value,
            },
        )
        try:
            accepted_revision = validate_digest(body["accepted_revision"])
            if (
                type(body["replayed"]) is not bool
                or type(body["question_resolved"]) is not bool
                or body["answered_question_id"] != question_id
            ):
                raise ContractError("invalid question answer metadata")
            if not isinstance(body["project"], dict):
                raise ContractError("invalid current project")
            project = self._snapshot(body["project"], identifier)
        except (KeyError, TypeError, ContractError) as exc:
            raise ServiceError(
                "invalid_response", "Service returned an invalid question answer"
            ) from exc
        return {
            "accepted_revision": accepted_revision,
            "answered_question_id": question_id,
            "question_resolved": body["question_resolved"],
            "replayed": body["replayed"],
            "project": project,
        }

    def list_projects(self, *, offset: int = 0, limit: int = 50) -> dict:
        body = self._json(
            "GET", "/api/v1/projects/?" + urlencode({"offset": offset, "limit": limit})
        )
        return self._page(body, offset, limit, self._project_summary)

    def create(self, name: str, request_id: str) -> dict:
        body = self._json(
            "POST", "/api/v1/projects/", {"name": name, "request_id": parse_uuid(request_id)}
        )
        return self._snapshot(body)

    def inspect(self, project_id: str) -> dict:
        identifier = parse_uuid(project_id)
        return self._snapshot(self._json("GET", f"/api/v1/projects/{identifier}/"), identifier)

    def accept(
        self, project_id: str, expected_revision: str, request_id: str, program: dict
    ) -> dict:
        identifier = parse_uuid(project_id)
        request = parse_uuid(request_id)
        body = self._json(
            "POST",
            f"/api/v1/projects/{identifier}/revisions/",
            {
                "expected_revision": validate_digest(expected_revision),
                "request_id": request,
                "program": program,
            },
        )
        try:
            validate_digest(body["revision"])
            validate_digest(body["current_revision"])
            if parse_uuid(body["request_id"]) != request or type(body["replayed"]) is not bool:
                raise ContractError("invalid revision receipt")
        except (KeyError, TypeError, ContractError) as exc:
            raise ServiceError(
                "invalid_response", "Service returned an invalid revision receipt"
            ) from exc
        return body

    def accept_design(
        self,
        project_id: str,
        expected_revision: str,
        request_id: str,
        artifacts: dict[str, bytes],
        decision: dict,
    ) -> dict:
        identifier = parse_uuid(project_id)
        expected = validate_digest(expected_revision)
        request = parse_uuid(request_id)
        canonical = design_request(identifier, expected, request, artifacts, decision)
        body = self._json(
            "POST",
            f"/api/v1/projects/{identifier}/design/",
            {
                "expected_revision": expected,
                "request_id": request,
                "artifacts": {
                    name: base64.b64encode(artifacts[name]).decode("ascii") for name in DESIGN_FILES
                },
                "decision": canonical["decision"],
            },
        )
        try:
            if not isinstance(body, dict) or set(body) != {
                "revision",
                "current_revision",
                "request_id",
                "replayed",
            }:
                raise ContractError("invalid design receipt fields")
            validate_digest(body["revision"])
            validate_digest(body["current_revision"])
            if parse_uuid(body["request_id"]) != request or type(body["replayed"]) is not bool:
                raise ContractError("invalid design receipt")
            if not body["replayed"] and body["revision"] != body["current_revision"]:
                raise ContractError("new design revision must be current")
        except (KeyError, TypeError, ContractError) as exc:
            raise ServiceError(
                "invalid_response", "Service returned an invalid design receipt"
            ) from exc
        return body

    def assess(self, project_id: str) -> dict:
        identifier = parse_uuid(project_id)
        body = self._json("GET", f"/api/v1/projects/{identifier}/")
        snapshot = self._snapshot(body, identifier)
        try:
            validate("assessment", body["assessment"])
        except (KeyError, TypeError, ContractError) as exc:
            raise ServiceError(
                "invalid_response", "Service returned an invalid assessment"
            ) from exc
        return {
            "project_id": identifier,
            "revision": snapshot["revision"],
            "assessment": body["assessment"],
        }

    def export(self, project_id: str) -> bytes:
        return self._request(
            "GET",
            f"/api/v1/projects/{parse_uuid(project_id)}/export/",
            maximum=MAX_ARCHIVE,
            media_type="application/zip",
        )

    def submit_job(self, project_id: str, expected_revision: str, request_id: str) -> dict:
        identifier = parse_uuid(project_id)
        request = parse_uuid(request_id)
        revision = validate_digest(expected_revision)
        body = self._json(
            "POST",
            "/api/v1/jobs/",
            {
                "project_id": identifier,
                "expected_revision": revision,
                "request_id": request,
                "operation": "assess_program",
            },
        )
        try:
            if type(body["replayed"]) is not bool:
                raise ContractError("invalid job receipt")
            job = self._job(body["job"])
            if (
                job["project_id"] != identifier
                or job["revision"] != revision
                or job["request_id"] != request
            ):
                raise ContractError("wrong submitted job")
        except (KeyError, TypeError, ContractError) as exc:
            raise ServiceError(
                "invalid_response", "Service returned an invalid job receipt"
            ) from exc
        return body

    def list_jobs(self, *, offset: int = 0, limit: int = 50) -> dict:
        body = self._json("GET", "/api/v1/jobs/?" + urlencode({"offset": offset, "limit": limit}))
        return self._page(body, offset, limit, self._job)

    def inspect_job(self, job_id: str) -> dict:
        identifier = parse_uuid(job_id)
        return self._job(self._json("GET", f"/api/v1/jobs/{identifier}/"), identifier)

    def cancel_job(self, job_id: str) -> dict:
        identifier = parse_uuid(job_id)
        return self._job(self._json("POST", f"/api/v1/jobs/{identifier}/cancel/", {}), identifier)

    def artifact(self, job_id: str, name: str) -> bytes:
        if name not in {"assessment.json", "stdout.log", "stderr.log"}:
            raise ServiceError("invalid_request", "Unknown assessment artifact")
        job = self.inspect_job(job_id)
        descriptors = job.get("artifacts")
        if job.get("status") not in {"succeeded", "failed", "cancelled"} or not isinstance(
            descriptors, list
        ):
            raise ServiceError("invalid_artifact", "No terminal artifact has been published")
        matches = [
            item for item in descriptors if isinstance(item, dict) and item.get("name") == name
        ]
        if len(matches) != 1:
            raise ServiceError("invalid_artifact", "Artifact is not uniquely published by this job")
        descriptor = matches[0]
        size = descriptor.get("bytes")
        media_type = "application/json" if name == "assessment.json" else "text/plain"
        if (
            type(size) is not int
            or not 0 <= size <= MAX_ARTIFACT_BYTES
            or descriptor.get("media_type") != media_type
            or (name == "assessment.json" and job["status"] != "succeeded")
        ):
            raise ServiceError("invalid_artifact", "Invalid published artifact descriptor")
        try:
            expected_hash = validate_digest(descriptor.get("sha256"))
        except ContractError as exc:
            raise ServiceError("invalid_artifact", "Invalid published artifact digest") from exc
        data = self._request(
            "GET",
            f"/api/v1/jobs/{parse_uuid(job_id)}/artifacts/{name}/",
            maximum=size,
            media_type=media_type,
        )
        if len(data) != size or hashlib.sha256(data).hexdigest() != expected_hash:
            raise ServiceError(
                "invalid_artifact", "Downloaded artifact does not match its published digest"
            )
        return data
