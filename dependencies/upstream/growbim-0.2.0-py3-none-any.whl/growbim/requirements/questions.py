"""Pure paging and source-backed answers for currently derived project questions."""

from __future__ import annotations

import re

from growbim.program.intake import validate_program
from growbim.requirements.evaluate import assess_program
from opencea.contracts import ContractError, parse_uuid, validate


class QuestionError(ContractError):
    def __init__(self, code: str, detail: str):
        super().__init__(detail)
        self.code = code
        self.detail = detail


def question_page(
    program: dict, *, offset: int = 0, limit: int = 50, category: str | None = None
) -> dict:
    validate_program(program)
    if isinstance(offset, bool) or not isinstance(offset, int) or offset < 0:
        raise QuestionError("invalid_request", "offset must be a non-negative integer")
    if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 100:
        raise QuestionError("invalid_request", "limit must be an integer from 1 through 100")
    if category is not None and (not isinstance(category, str) or not category):
        raise QuestionError("invalid_request", "category must be a nonempty string")
    questions = assess_program(program)["questions"]
    filtered = (
        questions if category is None else [q for q in questions if q["category"] == category]
    )
    return {
        "items": filtered[offset : offset + limit],
        "offset": offset,
        "limit": limit,
        "total": len(filtered),
    }


def _uuid(value: str, field: str) -> str:
    try:
        return parse_uuid(value)
    except ContractError as exc:
        raise QuestionError("invalid_request", f"{field} must be a UUID") from exc


def answer_question(
    program: dict, *, question_id: str, statement_id: str, source_id: str, value: dict
) -> tuple[dict, bool]:
    assessment = assess_program(program)
    if not isinstance(question_id, str) or not re.fullmatch(
        r"(?:requirement|practice)-[0-9a-f]{16}", question_id
    ):
        raise QuestionError("invalid_request", "question_id is malformed")
    statement_id = _uuid(statement_id, "statement_id")
    source_id = _uuid(source_id, "source_id")
    question = next((q for q in assessment["questions"] if q["id"] == question_id), None)
    if question is None:
        raise QuestionError("question_not_found", "question is not currently open")

    source = next(
        (item for item in program["sources"] if _uuid(item["id"], "source_id") == source_id), None
    )
    if source is None:
        raise QuestionError("source_not_found", "source does not exist")
    if any(
        _uuid(record["id"], "statement_id") == statement_id
        for collection in (
            "sources",
            "statements",
            "standards",
            "requirements",
            "hypotheses",
            "resolutions",
        )
        for record in program[collection]
    ):
        raise QuestionError("statement_exists", "record ID already exists")

    if question["category"] == "requirement":
        requirement_id = question["requirement_ids"][0]
        requirement = next(
            record for record in program["requirements"] if record["id"] == requirement_id
        )
        subject_id = requirement["subject_id"]
    else:
        subject_id = program["project_id"]
    property_name = question["property"]

    statement = {
        "id": statement_id,
        "kind": "reported",
        "subject_id": subject_id,
        "property": property_name,
        "value": value,
        "source_ids": [source["id"]],
    }
    try:
        validate("statement", statement)
        answered = {**program, "statements": [*program["statements"], statement]}
        validate_program(answered)
    except ContractError as exc:
        raise QuestionError("invalid_request", "answer value is invalid") from exc
    resolved = not any(q["id"] == question_id for q in assess_program(answered)["questions"])
    return answered, resolved
