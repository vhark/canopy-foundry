"""Original draft practice prompts; never normative standards or compliance decisions."""

from __future__ import annotations

import hashlib
from collections import defaultdict
from decimal import Decimal

from growbim.program.intake import validate_program
from opencea.contracts import validate

# Original practice questions. These are not a reviewed GACP or jurisdictional rule pack.
TOPICS = (
    (
        "water",
        "source_water_analysis",
        "What source-water analysis supports treatment and irrigation choices?",
        8,
    ),
    (
        "water",
        "cultivation_method",
        "What cultivation method and occupied growing area determine water demand?",
        6,
    ),
    (
        "water",
        "irrigation_zoning",
        "What demand patterns, irrigation zones and reuse strategy are intended?",
        5,
    ),
    (
        "climate",
        "location_weather",
        "What location and design weather conditions govern the climate strategy?",
        8,
    ),
    (
        "climate",
        "environmental_conditions",
        "What environmental conditions, ventilation and crop moisture loads are required?",
        7,
    ),
    (
        "lighting",
        "crop_stage_light",
        "What crop/stage lighting targets and daylight contribution are intended?",
        7,
    ),
    (
        "lighting",
        "lighting_schedule",
        "What mounting geometry, operating schedule and electrical constraints apply?",
        5,
    ),
    (
        "controls",
        "control_sequences",
        "What control sequences, connected equipment and sensing are required?",
        7,
    ),
    (
        "controls",
        "alarms_failure_response",
        "What alarms, failure responses and operator responsibilities are required?",
        7,
    ),
    (
        "envelope",
        "envelope_performance",
        "What separation, moisture, cleanability and fire criteria govern the envelope?",
        7,
    ),
)


def _id(prefix: str, text: str) -> str:
    return prefix + "-" + hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


_UNITS = {
    "m": ("length", "1"),
    "cm": ("length", "0.01"),
    "mm": ("length", "0.001"),
    "km": ("length", "1000"),
    "kg": ("mass", "1"),
    "g": ("mass", "0.001"),
    "mg": ("mass", "0.000001"),
    "L": ("volume", "1"),
    "mL": ("volume", "0.001"),
}


def _incompatible(first: dict, second: dict) -> bool:
    if first["type"] != second["type"]:
        return True
    if first["type"] != "quantity":
        return first != second
    left, right = _UNITS.get(first["unit"]), _UNITS.get(second["unit"])
    if first["unit"] == second["unit"]:
        return first["value"] != second["value"]
    if left is None or right is None or left[0] != right[0]:
        return False  # Unknown conversion is not evidence of contradiction.
    return Decimal(str(first["value"])) * Decimal(left[1]) != Decimal(
        str(second["value"])
    ) * Decimal(right[1])


def _cycles(requirements: dict[str, dict]) -> list[list[str]]:
    edges = {key: record.get("depends_on", []) for key, record in requirements.items()}
    reverse: dict[str, list[str]] = {key: [] for key in requirements}
    for key, dependencies in edges.items():
        for dependency in dependencies:
            reverse[dependency].append(key)
    visited: set[str] = set()
    order: list[str] = []
    for root in edges:
        stack = [(root, False)]
        while stack:
            node, finished = stack.pop()
            if finished:
                order.append(node)
            elif node not in visited:
                visited.add(node)
                stack.append((node, True))
                stack.extend((child, False) for child in edges[node] if child not in visited)
    assigned: set[str] = set()
    components = []
    for root in reversed(order):
        if root in assigned:
            continue
        component = []
        stack = [root]
        assigned.add(root)
        while stack:
            node = stack.pop()
            component.append(node)
            for child in reverse[node]:
                if child not in assigned:
                    assigned.add(child)
                    stack.append(child)
        if len(component) > 1 or root in edges[root]:
            components.append(sorted(component))
    return sorted(components)


def assess_program(program: dict) -> dict:
    validate_program(program)
    findings = []
    conflicted = set()
    questions = []
    covered = defaultdict(list)
    compared = defaultdict(list)
    for statement in program["statements"]:
        if (
            statement["kind"] in ("reported", "verified", "required")
            and statement["value"]["type"] != "unknown"
        ):
            compared[statement["property"]].append(statement)
            if statement["kind"] in ("reported", "verified"):
                covered[statement["property"]].append(statement)
    for key, statements in sorted(compared.items()):
        for i, first in enumerate(statements):
            for other in statements[i + 1 :]:
                if _incompatible(first["value"], other["value"]):
                    conflicted.add(key)
                    findings.append(
                        dict(
                            id=_id("conflict", "-".join(sorted((first["id"], other["id"])))),
                            title="Conflicting source-backed statements",
                            message=f"{key} has incompatible retained statements; human reconciliation is needed.",
                            statement_ids=sorted((first["id"], other["id"])),
                            source_ids=sorted(set(first["source_ids"] + other["source_ids"])),
                            requirement_ids=sorted(
                                r["id"] for r in program["requirements"] if r["property"] == key
                            ),
                        )
                    )
    for standard in sorted(program["standards"], key=lambda record: record["id"]):
        if standard["status"] == "proposed":
            findings.append(
                dict(
                    id=_id("standards-review", standard["id"]),
                    title="Standards applicability review pending",
                    message="A named reviewer must determine this framework's edition, jurisdiction, product and process applicability. Independent rights and interpretation review are prerequisites to a qualified rule pack; this record does not certify compliance.",
                    standard_ids=[standard["id"]],
                    source_ids=standard["source_ids"],
                    requirement_ids=[],
                )
            )
    requirements = {r["id"]: r for r in program["requirements"]}
    for component in _cycles(requirements):
        findings.append(
            dict(
                id=_id("dependency-cycle", "-".join(component)),
                title="Unresolved coupled-design dependency",
                message="These requirements depend cyclically on each other; a reviewer must reconcile the coupled design.",
                requirement_ids=list(component),
                source_ids=sorted(
                    {
                        source
                        for identifier in component
                        for source in requirements[identifier]["source_ids"]
                    }
                ),
            )
        )
    for requirement in program["requirements"]:
        if requirement["property"] not in covered or requirement["property"] in conflicted:
            questions.append(
                dict(
                    id=_id("requirement", requirement["id"]),
                    title=f"Unresolved requirement: {requirement['title']}",
                    message="What source-backed information resolves this condition?",
                    source_ids=requirement["source_ids"],
                    requirement_ids=[requirement["id"]],
                    property=requirement["property"],
                    category="requirement",
                    priority=100
                    if requirement.get("safety")
                    else 90
                    if requirement.get("mandatory")
                    else 60,
                    effort=requirement.get("effort", 5),
                    sensitivity=requirement.get("sensitivity", 5),
                )
            )
    for category, prop, prompt, sensitivity in TOPICS:
        if prop not in covered or prop in conflicted:
            questions.append(
                dict(
                    id=_id("practice", prop),
                    title=f"{category.title()}: {prop.replace('_', ' ')}",
                    message=prompt
                    + " Original draft practice guidance; not a qualified GACP rule.",
                    source_ids=[],
                    requirement_ids=[],
                    property=prop,
                    category=category,
                    priority=40,
                    effort=5,
                    sensitivity=sensitivity,
                )
            )
    # Higher mandatory/safety priority, then blocked dependents, sensitivity and answer effort.
    dependents = defaultdict(set)
    for r in requirements.values():
        for dependency in r.get("depends_on", []):
            dependents[dependency].add(r["id"])

    def downstream(identifiers: list[str]) -> list[str]:
        seen = set(identifiers)
        blocked = set()
        stack = [dependent for identifier in identifiers for dependent in dependents[identifier]]
        while stack:
            current = stack.pop()
            if current not in seen:
                seen.add(current)
                blocked.add(current)
                stack.extend(dependents[current])
        return sorted(blocked)

    for question in questions:
        question["blocked_requirement_ids"] = downstream(question["requirement_ids"])
        question["blocked_decisions"] = len(question["blocked_requirement_ids"])
    questions.sort(
        key=lambda q: (
            -q["priority"],
            -q["blocked_decisions"],
            -q["sensitivity"],
            q["effort"],
            q["id"],
        )
    )
    decisions = {r["hypothesis_id"]: r for r in program["resolutions"]}
    hypotheses = [
        dict(
            id=h["id"],
            title=h["title"],
            message=h["message"],
            source_ids=h["source_ids"],
            requirement_ids=[],
            likelihood=h["likelihood"],
            status=decisions[h["id"]]["decision"] if h["id"] in decisions else "unresolved",
            basis=h["basis"],
            subject_id=h["subject_id"],
            property=h["property"],
            value=h["value"],
        )
        for h in sorted(program["hypotheses"], key=lambda h: h["id"])
    ]
    assessment = dict(findings=findings, questions=questions, hypotheses=hypotheses)
    validate("assessment", assessment)
    return assessment
