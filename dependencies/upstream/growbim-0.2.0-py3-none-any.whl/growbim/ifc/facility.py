"""Original illustrative 216 m² IFC4 facility; native entities are the design authority."""

from __future__ import annotations

import math
from itertools import pairwise

import ifcopenshell
import ifcopenshell.util.placement
import ifcopenshell.util.unit
from opencea.contracts import ContractError, parse_uuid

from . import _native as n

PROFILE = "org.grownetics.first-shipment-facility.v1"
KIND = "facility-216-v1"
# Coordinates are metres in the ground-storey frame. Partition area is illustrative;
# room polygons and floor polygon, rather than fixture metadata, define gross area.
ROOMS = (
    ("production-a", "Production A", 0, 0, 9, 4),
    ("production-b", "Production B", 9, 0, 9, 4),
    ("nursery", "Nursery", 0, 4, 9, 2),
    ("mechanical", "Mechanical", 9, 4, 9, 2),
    ("processing", "Processing", 0, 6, 10, 3),
    ("support", "Support", 10, 6, 6, 3),
    ("circulation-east", "Circulation east", 16, 6, 2, 3),
    ("circulation-main", "Circulation main", 0, 9, 18, 3),
)


def _construct(program, source_id):
    project_id = parse_uuid(program["project_id"])
    source_id = parse_uuid(source_id)
    if source_id not in {row["id"] for row in program["sources"]}:
        raise ContractError("facility source missing from accepted program")
    model = ifcopenshell.file(schema="IFC4")
    project = n._root(
        model,
        "IfcProject",
        project_id,
        KIND,
        "project",
        Name="Original illustrative 216 m² facility",
    )
    length = model.createIfcSIUnit(UnitType="LENGTHUNIT", Name="METRE")
    project.UnitsInContext = model.createIfcUnitAssignment(
        [
            length,
            model.createIfcSIUnit(UnitType="AREAUNIT", Name="SQUARE_METRE"),
            model.createIfcSIUnit(UnitType="VOLUMEUNIT", Name="CUBIC_METRE"),
        ]
    )
    context = model.createIfcGeometricRepresentationContext(
        None,
        "Model",
        3,
        1e-5,
        model.createIfcAxis2Placement3D(
            n._point(model, (0, 0, 0)),
            n._direction(model, (0, 0, 1)),
            n._direction(model, (1, 0, 0)),
        ),
        None,
    )
    project.RepresentationContexts = [context]
    spatial = {}
    parent, placement = project, None
    for cls, key, label in (
        ("IfcSite", "site", "Illustrative site"),
        ("IfcBuilding", "building", "First shipment shell"),
        ("IfcBuildingStorey", "storey", "Ground storey"),
    ):
        kwargs = dict(
            Name=label,
            CompositionType="ELEMENT",
            ObjectPlacement=n._placement(model, placement, (0, 0, 0)),
        )
        if cls == "IfcBuildingStorey":
            kwargs["Elevation"] = 0.0
        entity = n._root(model, cls, project_id, KIND, key, **kwargs)
        n._rel(
            model,
            "IfcRelAggregates",
            project_id,
            KIND,
            key,
            RelatingObject=parent,
            RelatedObjects=[entity],
        )
        spatial[key] = entity
        parent, placement = entity, entity.ObjectPlacement
    storey = spatial["storey"]
    n._pset(
        model,
        project_id,
        KIND,
        "project",
        project,
        "OpenCEA_Facility",
        {"Profile": (PROFILE, "IfcIdentifier"), "SourceId": (source_id, "IfcIdentifier")},
    )
    identity = dict(
        schema_version="0.2",
        id=n._id(project_id, KIND, "identity"),
        project_id=project_id,
        name="Original illustrative 216 m² facility",
        model_sha256="",
        source_ids=[source_id],
        subjects=[],
        roles=[],
        assets=[],
        elements=[],
        channels=[],
        bindings=[],
        deployments=[],
        occupancies=[],
        transitions=[],
        unresolved_bindings=[],
    )
    catalog = dict(schema_version="0.2", items=[])

    def item(key, cls, name, x, y, z, dx, dy, dz, container=storey):
        entity = n._root(
            model,
            cls,
            project_id,
            KIND,
            key,
            Name=name,
            ObjectPlacement=n._placement(model, container.ObjectPlacement, (x, y, z)),
            Representation=n._box(model, context, dx, dy, dz),
        )
        row = dict(
            id=n._id(project_id, KIND, "element/" + key),
            ifc_global_id=entity.GlobalId,
            ifc_class=cls,
            product_id=None,
            role_id=None,
            asset_id=None,
            state="active",
            evidence_kind="proposed",
        )
        identity["elements"].append(row)
        n._pset(
            model,
            project_id,
            KIND,
            key,
            entity,
            "OpenCEA_Identity",
            {"ElementId": (row["id"], "IfcIdentifier")},
        )
        n._quantities(model, project_id, KIND, key, entity, dx, dy, dz, length)
        n._rel(
            model,
            "IfcRelContainedInSpatialStructure",
            project_id,
            KIND,
            "contain/" + key,
            RelatingStructure=container,
            RelatedElements=[entity],
        )
        return entity

    floor = item("floor", "IfcSlab", "Ground floor polygon", 0, 0, -0.2, 18, 12, 0.2)
    floor_length, floor_width, _ = n._dimensions(floor)
    area_unit = next(unit for unit in project.UnitsInContext.Units if unit.UnitType == "AREAUNIT")
    quantities = n._root(
        model,
        "IfcElementQuantity",
        project_id,
        KIND,
        "quantity/storey-floor",
        Name="OpenCEA_StoreyFloor",
        Quantities=[
            model.createIfcQuantityArea(
                Name="GrossFloorArea",
                AreaValue=floor_length * floor_width,
                Unit=area_unit,
            )
        ],
    )
    n._rel(
        model,
        "IfcRelDefinesByProperties",
        project_id,
        KIND,
        "quantities/storey-floor",
        RelatedObjects=[storey],
        RelatingPropertyDefinition=quantities,
    )
    for key, name, x, y, dx, dy in ROOMS:
        room = n._root(
            model,
            "IfcSpace",
            project_id,
            KIND,
            "space/" + key,
            Name=name,
            CompositionType="ELEMENT",
            ObjectPlacement=n._placement(model, storey.ObjectPlacement, (x, y, 0)),
            Representation=n._box(model, context, dx, dy, 3),
        )
        spatial[key] = room
        n._rel(
            model,
            "IfcRelAggregates",
            project_id,
            KIND,
            "space/" + key,
            RelatingObject=storey,
            RelatedObjects=[room],
        )
        n._quantities(model, project_id, KIND, "space/" + key, room, dx, dy, 3, length)
        n._pset(
            model,
            project_id,
            KIND,
            "space/" + key,
            room,
            "OpenCEA_FacilityRoom",
            {"Zone": (key.split("-")[0], "IfcIdentifier")},
        )
    # Shared partitions occur once per common boundary; openings are cut in
    # the actual wall they traverse, including the corridor's exterior exit.
    partitions = (
        ("production-a", 0, 3.94, 9, 0.12, True),
        ("production-b", 9, 3.94, 9, 0.12, True),
        ("nursery", 0, 5.94, 9, 0.12, True),
        ("mechanical", 9, 5.94, 9, 0.12, True),
        ("processing", 0, 8.94, 10, 0.12, True),
        ("support", 10, 8.94, 6, 0.12, True),
        ("circulation-east", 16, 8.94, 2, 0.12, True),
        ("divide-production", 8.94, 0, 0.12, 4, False),
        ("divide-nursery", 8.94, 4, 0.12, 2, False),
        ("divide-processing", 9.94, 6, 0.12, 3, False),
        ("divide-support", 15.94, 6, 0.12, 3, False),
    )
    walls = {}
    for key, x, y, dx, dy, _doorway in partitions:
        walls[key] = item(
            "partition/" + key, "IfcWall", "Shared partition " + key, x, y, 0, dx, dy, 3
        )
    for key, x, y, dx, dy in (
        ("west", -0.15, 0, 0.15, 12),
        ("east", 18, 0, 0.15, 12),
        ("south", 0, -0.15, 18, 0.15),
        ("north", 0, 12, 18, 0.15),
    ):
        walls["shell/" + key] = item(
            "shell/" + key, "IfcWall", "Shell wall " + key, x, y, 0, dx, dy, 3
        )
    for key, x, y, dx, dy, doorway in (*partitions, ("shell/north", 0, 12, 18, 0.15, True)):
        if not doorway:
            continue
        offset = 0.25 if dx <= 2 else 0.8
        opening = n._root(
            model,
            "IfcOpeningElement",
            project_id,
            KIND,
            "opening/" + key,
            Name="Passable opening " + key,
            ObjectPlacement=n._placement(model, storey.ObjectPlacement, (x + offset, y, 0)),
            Representation=n._box(model, context, 1, dy, 2.1),
        )
        opening_id = n._id(project_id, KIND, "element/opening/" + key)
        identity["elements"].append(
            dict(
                id=opening_id,
                ifc_global_id=opening.GlobalId,
                ifc_class="IfcOpeningElement",
                product_id=None,
                role_id=None,
                asset_id=None,
                state="active",
                evidence_kind="proposed",
            )
        )
        n._pset(
            model,
            project_id,
            KIND,
            "opening/" + key,
            opening,
            "OpenCEA_Identity",
            {"ElementId": (opening_id, "IfcIdentifier")},
        )
        door = item("door/" + key, "IfcDoor", "Door " + key, x + offset, y + 0.03, 0, 1, 0.06, 2.1)
        door.OverallWidth, door.OverallHeight = 1.0, 2.1
        n._rel(
            model,
            "IfcRelVoidsElement",
            project_id,
            KIND,
            "void/" + key,
            RelatingBuildingElement=walls[key],
            RelatedOpeningElement=opening,
        )
        n._rel(
            model,
            "IfcRelFillsElement",
            project_id,
            KIND,
            "fill/" + key,
            RelatingOpeningElement=opening,
            RelatedBuildingElement=door,
        )
    # Two-tier benches: elevated canopy surfaces do not contribute to floor area.
    for room_key, x in (("production-a", 1), ("production-b", 10)):
        for tier in range(2):
            z = 0.35 + tier * 1.2
            item(
                f"bench/{room_key}/{tier}",
                "IfcElementAssembly",
                "Bench tier " + room_key,
                x,
                0.7,
                z,
                6,
                1.4,
                0.12,
            )
            item(
                f"canopy/{room_key}/{tier}",
                "IfcCovering",
                "Canopy surface " + room_key,
                x,
                0.7,
                z + 0.12,
                6,
                1.4,
                0.025,
            )
    item("nursery-bench", "IfcElementAssembly", "Nursery bench", 1, 4.5, 0.4, 6, 0.8, 0.12)
    equipment = {
        "air-handler": ("IfcFan", "Illustrative air distribution fan", 12, 4.2, 0, 1, 0.8, 1.5),
        "irrigation": ("IfcPump", "Illustrative irrigation pump", 15, 4.2, 0, 0.6, 0.6, 0.8),
        "distribution": (
            "IfcElectricDistributionBoard",
            "Illustrative electrical panel",
            17,
            4.2,
            0,
            0.4,
            0.3,
            1.4,
        ),
    }
    products = {}
    for key, spec in equipment.items():
        cls, label, *dimensions = spec
        products[key] = item(key, cls, label, *dimensions)
        product_id = n._id(project_id, KIND, "catalog/" + key)
        catalog["items"].append(
            {
                "schema_version": "0.1",
                "id": product_id,
                "name": label,
                "manufacturer": "OpenCEA original illustrative design",
                "model": "OCEA-FAC-" + key.upper(),
                "properties": {
                    name: {
                        "type": "quantity",
                        "value": value,
                        "unit": "m",
                        "evidence_kind": "declared",
                        "source_ids": [source_id],
                    }
                    for name, value in zip(
                        ("envelope_length", "envelope_width", "envelope_height"),
                        dimensions[3:],
                        strict=True,
                    )
                },
                "evidence_status": "declared",
                "source_ids": [source_id],
                "extensions": {
                    "unknowns": ["equipment capacity", "manufacturer specification"],
                    "representation": "illustrative envelope",
                },
            }
        )
        row = next(
            row for row in identity["elements"] if row["ifc_global_id"] == products[key].GlobalId
        )
        row["product_id"] = product_id
        typ = n._root(
            model,
            cls + "Type",
            project_id,
            KIND,
            "type/" + key,
            Name=label,
            PredefinedType="NOTDEFINED",
        )
        n._pset(
            model,
            project_id,
            KIND,
            "type/" + key,
            typ,
            "OpenCEA_Product",
            {"CatalogId": (product_id, "IfcIdentifier")},
        )
        n._rel(
            model,
            "IfcRelDefinesByType",
            project_id,
            KIND,
            "type/" + key,
            RelatingType=typ,
            RelatedObjects=[products[key]],
        )
        clearance = n._pset(
            model,
            project_id,
            KIND,
            key,
            products[key],
            "OpenCEA_ServiceClearance",
            {
                "Front": (0.6, "IfcLengthMeasure"),
                "Purpose": ("illustrative access envelope", "IfcText"),
            },
        )
        next(prop for prop in clearance.HasProperties if prop.Name == "Front").Unit = length
    runs = {
        "air": (
            "IfcDuctSegment",
            "Illustrative air duct",
            12,
            5.0,
            1.5,
            5,
            0.25,
            0.25,
            "AIRCONDITIONING",
        ),
        "water": (
            "IfcPipeSegment",
            "Illustrative water pipe",
            15,
            4.8,
            0.8,
            2,
            0.08,
            0.08,
            "WATERSUPPLY",
        ),
        "power": (
            "IfcCableCarrierSegment",
            "Illustrative cable tray",
            17,
            4.5,
            1.4,
            0.8,
            0.12,
            0.08,
            "ELECTRICAL",
        ),
    }
    for key, (cls, label, x, y, z, dx, dy, dz, system_type) in runs.items():
        run = item("run/" + key, cls, label, x, y, z, dx, dy, dz)
        system = n._root(
            model,
            "IfcDistributionSystem",
            project_id,
            KIND,
            "system/" + key,
            Name=key.capitalize() + " illustrative distribution",
            PredefinedType=system_type,
        )
        n._rel(
            model,
            "IfcRelAssignsToGroup",
            project_id,
            KIND,
            "system/" + key,
            RelatedObjects=[
                run,
                products[
                    {"air": "air-handler", "water": "irrigation", "power": "distribution"}[key]
                ],
            ],
            RelatingGroup=system,
        )
        equipment_entity = products[
            {"air": "air-handler", "water": "irrigation", "power": "distribution"}[key]
        ]
        equipment_origin = ifcopenshell.util.placement.get_local_placement(
            equipment_entity.ObjectPlacement
        )[:3, 3]
        run_origin = ifcopenshell.util.placement.get_local_placement(run.ObjectPlacement)[:3, 3]
        for side, host, flow, offset in (
            ("equipment", equipment_entity, "SOURCE", tuple(run_origin - equipment_origin)),
            ("run", run, "SINK", (0.0, 0.0, 0.0)),
        ):
            port_key = "port/" + key + "/" + side
            port = n._root(
                model,
                "IfcDistributionPort",
                project_id,
                KIND,
                port_key,
                Name=key + " " + side + " port",
                FlowDirection=flow,
                ObjectPlacement=n._placement(model, host.ObjectPlacement, offset),
                PredefinedType={"air": "DUCT", "water": "PIPE", "power": "CABLE"}[key],
                SystemType=system_type,
            )
            row = dict(
                id=n._id(project_id, KIND, "element/" + port_key),
                ifc_global_id=port.GlobalId,
                ifc_class="IfcDistributionPort",
                product_id=None,
                role_id=None,
                asset_id=None,
                state="active",
                evidence_kind="proposed",
            )
            identity["elements"].append(row)
            n._pset(
                model,
                project_id,
                KIND,
                port_key,
                port,
                "OpenCEA_Identity",
                {"ElementId": (row["id"], "IfcIdentifier")},
            )
            n._rel(
                model,
                "IfcRelNests",
                project_id,
                KIND,
                port_key,
                RelatingObject=host,
                RelatedObjects=[port],
            )
            products[key + "/" + side] = port
        n._rel(
            model,
            "IfcRelConnectsPorts",
            project_id,
            KIND,
            "connect/" + key,
            RelatingPort=products[key + "/equipment"],
            RelatedPort=products[key + "/run"],
        )
    return n._serialize(model, identity, catalog)


def build_facility(program, source_id):
    """Build a source-linked candidate, never mark a proposed installation installed."""
    artifacts = _construct(program, source_id)
    n.validate_candidate(artifacts, program)
    return artifacts


def is_facility(model):
    projects = model.by_type("IfcProject")
    return (
        len(projects) == 1
        and n._property_value(projects[0], "OpenCEA_Facility", "Profile") == PROFILE
    )


def _bounds(entity):
    """World-space bounds of one axis-aligned IFC extrusion (SI metres)."""
    import numpy as np

    if entity.ObjectPlacement is None or entity.Representation is None:
        raise ContractError("facility product has no spatial geometry")
    transform = ifcopenshell.util.placement.get_local_placement(entity.ObjectPlacement)
    if not np.isfinite(transform).all() or not np.allclose(
        transform,
        np.array(
            [
                [1, 0, 0, transform[0, 3]],
                [0, 1, 0, transform[1, 3]],
                [0, 0, 1, transform[2, 3]],
                [0, 0, 0, 1],
            ]
        ),
        rtol=0,
        atol=1e-6,
    ):
        raise ContractError("facility geometry requires finite axis-aligned rigid placement")
    try:
        (representation,) = entity.Representation.Representations
        (solid,) = representation.Items
        if (
            representation.RepresentationIdentifier != "Body"
            or representation.RepresentationType != "SweptSolid"
            or not solid.is_a("IfcExtrudedAreaSolid")
            or not solid.SweptArea.is_a("IfcArbitraryClosedProfileDef")
            or not solid.SweptArea.OuterCurve.is_a("IfcPolyline")
        ):
            raise ContractError("unsupported facility geometric representation")
        points = [tuple(point.Coordinates) for point in solid.SweptArea.OuterCurve.Points]
        if len(points) != 5 or any(len(point) != 2 for point in points):
            raise ContractError("facility polygon must be a closed rectangle")
        width, depth, height = points[1][0], points[2][1], solid.Depth
        dimensions = (width, depth, height)
        if (
            any(not math.isfinite(float(v)) or v <= 0 for v in dimensions)
            or not np.allclose(
                points,
                [
                    (0, 0),
                    (width, 0),
                    (width, depth),
                    (0, depth),
                    (0, 0),
                ],
                rtol=0,
                atol=1e-6,
            )
            or not np.allclose(solid.Position.Location.Coordinates, (0, 0, 0), rtol=0, atol=1e-6)
            or not np.allclose(solid.Position.Axis.DirectionRatios, (0, 0, 1), rtol=0, atol=1e-6)
            or not np.allclose(
                solid.Position.RefDirection.DirectionRatios, (1, 0, 0), rtol=0, atol=1e-6
            )
            or not np.allclose(
                solid.ExtrudedDirection.DirectionRatios, (0, 0, 1), rtol=0, atol=1e-6
            )
        ):
            raise ContractError(
                "facility polygon, solid frame or extrusion is not a closed rectangular prism"
            )
    except (AttributeError, IndexError, TypeError, ValueError) as exc:
        raise ContractError("facility product requires a closed extruded rectangle") from exc
    origin = transform[:3, 3]
    return tuple((float(v), float(v + d)) for v, d in zip(origin, dimensions, strict=True))


def _overlap(a, b):
    return all(min(u[1], v[1]) - max(u[0], v[0]) > 1e-6 for u, v in zip(a, b, strict=True))


def _within(inner, outer, tolerance=1e-6):
    return all(
        low - tolerance <= a <= b <= high + tolerance
        for (a, b), (low, high) in zip(inner, outer, strict=True)
    )


def _port_frame(port):
    import numpy as np

    if port.ObjectPlacement is None or not port.ObjectPlacement.is_a("IfcLocalPlacement"):
        raise ContractError("MEP port has no host-anchored placement")
    placement = port.ObjectPlacement.RelativePlacement
    if (
        not placement.is_a("IfcAxis2Placement3D")
        or not placement.Axis
        or not placement.RefDirection
    ):
        raise ContractError("MEP port requires an explicit three-dimensional frame")
    axis = np.asarray(placement.Axis.DirectionRatios, dtype=float)
    ref = np.asarray(placement.RefDirection.DirectionRatios, dtype=float)
    location = np.asarray(placement.Location.Coordinates, dtype=float)
    if (
        not np.isfinite(axis).all()
        or not np.isfinite(ref).all()
        or not np.isfinite(location).all()
        or not np.allclose(
            (np.dot(axis, axis), np.dot(ref, ref), np.dot(axis, ref)),
            (1.0, 1.0, 0.0),
            rtol=0,
            atol=1e-6,
        )
    ):
        raise ContractError("MEP port has a non-finite or non-rigid local frame")
    matrix = ifcopenshell.util.placement.get_local_placement(port.ObjectPlacement)
    rotation = matrix[:3, :3]
    if (
        not np.isfinite(matrix).all()
        or not np.allclose(rotation.T @ rotation, np.eye(3), rtol=0, atol=1e-6)
        or not math.isclose(np.linalg.det(rotation), 1.0, abs_tol=1e-6)
        or not np.allclose(matrix[3], (0, 0, 0, 1), rtol=0, atol=1e-6)
    ):
        raise ContractError("MEP port world frame must be finite and rigid")
    return matrix


def validate_facility(artifacts, program, model, identity):
    """Check physical polygons, access boundaries, collision envelopes and IFC MEP."""
    import numpy as np

    if identity["id"] != n._id(identity["project_id"], KIND, "identity"):
        if is_facility(model):
            raise ContractError("facility identity was replaced")
        return
    if not is_facility(model):
        raise ContractError("facility profile declaration was removed")
    projects = model.by_type("IfcProject")
    if (
        len(identity["source_ids"]) != 1
        or n._property_value(projects[0], "OpenCEA_Facility", "SourceId")
        != identity["source_ids"][0]
    ):
        raise ContractError("facility source does not match its accepted program")
    assignment = projects[0].UnitsInContext
    units = (
        {
            kind: [unit for unit in assignment.Units if unit.UnitType == kind]
            for kind in ("LENGTHUNIT", "AREAUNIT", "VOLUMEUNIT")
        }
        if assignment
        else {}
    )
    expected_units = {
        "LENGTHUNIT": "METRE",
        "AREAUNIT": "SQUARE_METRE",
        "VOLUMEUNIT": "CUBIC_METRE",
    }
    if (
        assignment is None
        or len(assignment.Units) != 3
        or any(
            len(units[kind]) != 1
            or not units[kind][0].is_a("IfcSIUnit")
            or units[kind][0].Name != name
            or units[kind][0].Prefix is not None
            for kind, name in expected_units.items()
        )
        or ifcopenshell.util.unit.calculate_unit_scale(model) != 1
    ):
        raise ContractError("facility requires canonical metre, square-metre and cubic-metre units")
    length_unit, area_unit = units["LENGTHUNIT"][0], units["AREAUNIT"][0]
    if any(quantity.Unit != length_unit for quantity in model.by_type("IfcQuantityLength")) or any(
        quantity.Unit != area_unit for quantity in model.by_type("IfcQuantityArea")
    ):
        raise ContractError("facility explicit IFC quantity units differ from canonical SI units")
    if any(
        prop.Unit != length_unit
        for prop in model.by_type("IfcPropertySingleValue")
        if prop.NominalValue and prop.NominalValue.is_a("IfcLengthMeasure")
    ):
        raise ContractError(
            "facility explicit length-property units differ from canonical SI units"
        )
    storeys, floors, spaces = (
        model.by_type("IfcBuildingStorey"),
        model.by_type("IfcSlab"),
        model.by_type("IfcSpace"),
    )
    if len(storeys) != 1 or len(floors) != 1 or not spaces:
        raise ContractError("facility requires one geometric storey and a floor polygon")
    sites, buildings = model.by_type("IfcSite"), model.by_type("IfcBuilding")
    if len(sites) != 1 or len(buildings) != 1:
        raise ContractError("facility requires explicit site and building")
    aggregates = {
        (rel.RelatingObject.GlobalId, entity.GlobalId)
        for rel in model.by_type("IfcRelAggregates")
        for entity in rel.RelatedObjects
    }
    if not all(
        pair in aggregates
        for pair in (
            (projects[0].GlobalId, sites[0].GlobalId),
            (sites[0].GlobalId, buildings[0].GlobalId),
            (buildings[0].GlobalId, storeys[0].GlobalId),
            *((storeys[0].GlobalId, room.GlobalId) for room in spaces),
        )
    ):
        raise ContractError("facility site, building, storey or room hierarchy is disconnected")
    mapped_elements = {
        row["ifc_global_id"] for row in identity["elements"] if row["state"] == "active"
    }
    if mapped_elements != {entity.GlobalId for entity in model.by_type("IfcElement")} | {
        entity.GlobalId for entity in model.by_type("IfcDistributionPort")
    }:
        raise ContractError("facility IFC element or port has no UUID crosswalk")
    for element in model.by_type("IfcElement"):
        _bounds(element)
    floor = _bounds(floors[0])
    room_boxes = {room.GlobalId: _bounds(room) for room in spaces}
    ground = floor[:2]
    for room in spaces:
        box = room_boxes[room.GlobalId]
        if not _within(box[:2], ground) or abs(box[2][0] - floor[2][1]) > 1e-6:
            raise ContractError("room polygon lies outside storey floor")
    xs = sorted({x for box in (ground, *(box[:2] for box in room_boxes.values())) for x in box[0]})
    ys = sorted({y for box in (ground, *(box[:2] for box in room_boxes.values())) for y in box[1]})
    for x0, x1 in pairwise(xs):
        for y0, y1 in pairwise(ys):
            if x1 <= x0 or y1 <= y0:
                continue
            sample = ((x0 + x1) / 2, (y0 + y1) / 2)
            if (
                sum(
                    box[0][0] < sample[0] < box[0][1] and box[1][0] < sample[1] < box[1][1]
                    for box in room_boxes.values()
                )
                != 1
            ):
                raise ContractError("room polygons overlap or leave an unallocated floor cell")
    expected_area = (ground[0][1] - ground[0][0]) * (ground[1][1] - ground[1][0])
    gross = [
        q
        for rel in storeys[0].IsDefinedBy
        if rel.is_a("IfcRelDefinesByProperties")
        and rel.RelatingPropertyDefinition.is_a("IfcElementQuantity")
        and rel.RelatingPropertyDefinition.Name == "OpenCEA_StoreyFloor"
        for q in rel.RelatingPropertyDefinition.Quantities
        if q.Name == "GrossFloorArea"
    ]
    if len(gross) != 1 or abs(gross[0].AreaValue - expected_area) > 1e-6:
        raise ContractError("gross floor quantity differs from storey polygon")
    walls = model.by_type("IfcWall")
    wall_boxes = {wall.GlobalId: _bounds(wall) for wall in walls}
    for box in room_boxes.values():
        for axis in (0, 1):
            for edge in box[axis]:
                cross = 1 - axis
                segments = []
                for wall_box in wall_boxes.values():
                    if (
                        abs((wall_box[axis][0] + wall_box[axis][1]) / 2 - edge) < 0.16
                        and wall_box[axis][1] - wall_box[axis][0] <= 0.31
                        and wall_box[2][0] <= box[2][0] + 1e-6
                        and wall_box[2][1] >= box[2][1] - 1e-6
                    ):
                        segments.append(wall_box[cross])
                cursor = box[cross][0]
                for low, high in sorted(segments):
                    if low > cursor + 0.02:
                        break
                    cursor = max(cursor, high)
                if cursor < box[cross][1] - 0.02:
                    raise ContractError("room boundary lacks an enclosing shared wall")
    doors = model.by_type("IfcDoor")
    voids = model.by_type("IfcRelVoidsElement")
    fills = model.by_type("IfcRelFillsElement")
    if not doors or len(voids) != len(doors) or len(fills) != len(doors):
        raise ContractError("facility door and wall opening topology is incomplete")
    for rel in voids:
        opening, wall = rel.RelatedOpeningElement, rel.RelatingBuildingElement
        if wall.GlobalId not in wall_boxes:
            raise ContractError("access opening is not hosted by an enclosing wall")
        opening_box, wall_box = _bounds(opening), wall_boxes[wall.GlobalId]
        if not _within(opening_box, wall_box, 0.04):
            raise ContractError("door opening does not cut its host wall")
        related = [r.RelatedBuildingElement for r in fills if r.RelatingOpeningElement == opening]
        if len(related) != 1 or related[0] not in doors:
            raise ContractError("wall opening lacks a fitted door")
        door = related[0]
        door_box = _bounds(door)
        narrow_axis = min((0, 1), key=lambda axis: wall_box[axis][1] - wall_box[axis][0])
        wide_axis = 1 - narrow_axis
        if (
            not _within(door_box, opening_box, 0.001)
            or opening_box[narrow_axis][0] > wall_box[narrow_axis][0] + 0.001
            or opening_box[narrow_axis][1] < wall_box[narrow_axis][1] - 0.001
            or opening_box[wide_axis][1] - opening_box[wide_axis][0] < 0.9
            or door_box[wide_axis][1] - door_box[wide_axis][0] < 0.9
            or door_box[2][1] - door_box[2][0] < 2.0
            or opening_box[2][0] > floor[2][1] + 1e-6
            or not math.isclose(door_box[2][0], floor[2][1], abs_tol=1e-6)
            or not math.isclose(
                door.OverallWidth, door_box[wide_axis][1] - door_box[wide_axis][0], abs_tol=1e-6
            )
            or not math.isclose(door.OverallHeight, door_box[2][1] - door_box[2][0], abs_tol=1e-6)
        ):
            raise ContractError("door lacks full clear passage through its host wall")
    if not any(
        abs(_bounds(rel.RelatingBuildingElement)[1][1] - ground[1][1] - 0.15) < 0.02
        for rel in voids
    ):
        raise ContractError("circulation has no exterior exit")
    mechanical = [
        room_boxes[space.GlobalId]
        for space in spaces
        if n._property_value(space, "OpenCEA_FacilityRoom", "Zone") == "mechanical"
    ]
    if len(mechanical) != 1:
        raise ContractError("facility needs one identified mechanical zone")
    equipment_types = ("IfcFan", "IfcPump", "IfcElectricDistributionBoard")
    equipment = [entity for cls in equipment_types for entity in model.by_type(cls)]
    if not equipment:
        raise ContractError("facility requires sourced mechanical equipment")
    clearances = []
    for entity in equipment:
        box = _bounds(entity)
        if not _within(box, mechanical[0]):
            raise ContractError("equipment leaves mechanical room")
        front = n._property_value(entity, "OpenCEA_ServiceClearance", "Front")
        if not isinstance(front, (float, int)) or not math.isfinite(front) or front <= 0:
            raise ContractError("equipment has no usable service-clearance evidence")
        clearance = (box[0], (box[1][1], box[1][1] + front), box[2])
        if not _within(clearance, mechanical[0]):
            raise ContractError("equipment service clearance leaves mechanical room")
        clearances.append(clearance)
        for other in equipment:
            if other != entity and (
                _overlap(box, _bounds(other)) or _overlap(clearance, _bounds(other))
            ):
                raise ContractError("equipment collides with another installation or clearance")
        for door in doors:
            if _overlap(box, _bounds(door)) or _overlap(clearance, _bounds(door)):
                raise ContractError("equipment obstructs an access door")
    run_types = ("IfcDuctSegment", "IfcPipeSegment", "IfcCableCarrierSegment")
    runs = [entity for cls in run_types for entity in model.by_type(cls)]
    for run in runs:
        box = _bounds(run)
        if not _within(box, mechanical[0]):
            raise ContractError("MEP run leaves its mechanical-zone service corridor")
        if any(
            _overlap(box, _bounds(obstacle))
            for obstacle in (*walls, *doors, *equipment)
            if obstacle != run
        ):
            raise ContractError("MEP run collides with enclosure, door or equipment")
        if any(_overlap(box, clearance) for clearance in clearances):
            raise ContractError("MEP run obstructs equipment service clearance")
        if any(_overlap(box, _bounds(other)) for other in runs if other != run):
            raise ContractError("MEP runs collide")
    ports = model.by_type("IfcDistributionPort")
    connections = model.by_type("IfcRelConnectsPorts")
    systems = model.by_type("IfcDistributionSystem")
    if not ports or len(ports) != 2 * len(connections) or not systems:
        raise ContractError("facility MEP endpoint or connection topology is incomplete")
    mapped = {
        row["ifc_global_id"]
        for row in identity["elements"]
        if row["state"] == "active" and row["ifc_class"] == "IfcDistributionPort"
    }
    if mapped != {port.GlobalId for port in ports}:
        raise ContractError("MEP ports require distinct UUID crosswalk entries")
    hosts = {}
    for rel in model.by_type("IfcRelNests"):
        for port in rel.RelatedObjects:
            if port.is_a("IfcDistributionPort"):
                if port.GlobalId in hosts or not rel.RelatingObject.is_a("IfcDistributionElement"):
                    raise ContractError("MEP port has multiple or invalid equipment hosts")
                hosts[port.GlobalId] = rel.RelatingObject
    if set(hosts) != mapped:
        raise ContractError("MEP port lacks a distribution-element host")
    groups = {}
    for rel in model.by_type("IfcRelAssignsToGroup"):
        if rel.RelatingGroup in systems:
            for member in rel.RelatedObjects:
                groups.setdefault(member.GlobalId, set()).add(rel.RelatingGroup.GlobalId)
    consumed = set()
    for connection in connections:
        left, right = connection.RelatingPort, connection.RelatedPort
        if left.GlobalId in consumed or right.GlobalId in consumed or left == right:
            raise ContractError("MEP port reused across connections")
        consumed.update((left.GlobalId, right.GlobalId))
        host_left, host_right = hosts[left.GlobalId], hosts[right.GlobalId]
        shared = groups.get(host_left.GlobalId, set()) & groups.get(host_right.GlobalId, set())
        compatibility = {
            ("AIRCONDITIONING", "DUCT"): ("IfcFan", "IfcDuctSegment"),
            ("WATERSUPPLY", "PIPE"): ("IfcPump", "IfcPipeSegment"),
            ("ELECTRICAL", "CABLE"): ("IfcElectricDistributionBoard", "IfcCableCarrierSegment"),
        }
        expected_hosts = compatibility.get((left.SystemType, left.PredefinedType))
        if (
            left.FlowDirection != "SOURCE"
            or right.FlowDirection != "SINK"
            or left.SystemType != right.SystemType
            or left.PredefinedType != right.PredefinedType
            or expected_hosts is None
            or host_left.is_a() != expected_hosts[0]
            or host_right.is_a() != expected_hosts[1]
            or len(shared) != 1
            or next(system for system in systems if system.GlobalId in shared).PredefinedType
            != left.SystemType
        ):
            raise ContractError("MEP port direction, medium, host or system membership mismatch")
        left_frame, right_frame = _port_frame(left), _port_frame(right)
        if not np.allclose(left_frame, right_frame, rtol=0, atol=1e-6):
            raise ContractError("connected IFC MEP port frames do not coincide")
        for port, frame in ((left, left_frame), (right, right_frame)):
            host = hosts[port.GlobalId]
            if port.ObjectPlacement.PlacementRelTo != host.ObjectPlacement:
                raise ContractError("MEP port placement is not anchored to its host")
            point = frame[:3, 3]
            if not all(
                a - 1e-6 <= value <= b + 1e-6
                for value, (a, b) in zip(point, _bounds(host), strict=True)
            ):
                raise ContractError("MEP port does not terminate on its host geometry")
    if consumed != mapped:
        raise ContractError("MEP port has no unique connected endpoint")
