"""Sourced IFC4 study profile; geometry uses native IFC units, room frame is SI."""

from __future__ import annotations

import json
import math
from fractions import Fraction
from importlib.resources import files

import ifcopenshell
import ifcopenshell.util.placement
import ifcopenshell.util.unit
from opencea.contracts import ContractError, parse_uuid

from . import _native as n

PROFILE = "org.grownetics.one-room-shift.v1"
KIND = "reference-room-v1"
INCH = Fraction(127, 5000)
LENGTH = float(Fraction(797, 16) * INCH)
DEPTH = float(Fraction(421, 16) * INCH)
HEIGHT = float(Fraction(1269, 16) * INCH)


def _profile(model):
    space = model.by_type("IfcSpace")
    if (
        len(space) != 1
        or n._property_value(space[0], "OpenCEA_ReferenceRoom", "Profile") != PROFILE
    ):
        raise ContractError("unsupported reference-room profile")
    return space[0]


def _dimensions(model):
    space = _profile(model)
    if space.Representation is None:
        raise ContractError("required room geometry is missing")
    return tuple(n._dimensions(space))


def _rack(model, identity):
    rows = [
        r
        for r in identity["elements"]
        if r["ifc_class"] == "IfcFurniture" and r["state"] == "active"
    ]
    if len(rows) != 1:
        raise ContractError("reference profile requires exactly one rack")
    return rows[0], model.by_guid(rows[0]["ifc_global_id"])


def build_reference_room(program, room_source_id, rack_source_id, *, scenario_source_id=None):
    project_id = parse_uuid(program["project_id"])
    sources = {item["id"] for item in program["sources"]}
    source_ids = [parse_uuid(room_source_id), parse_uuid(rack_source_id)]
    if scenario_source_id is not None:
        source_ids.append(parse_uuid(scenario_source_id))
    if not set(source_ids) <= sources:
        raise ContractError("reference room source missing from program")
    rack_definition = json.loads(
        files("growbim.ifc").joinpath("resources", "catalog", "reference-rack.json").read_text()
    )
    model = ifcopenshell.file(schema="IFC4")
    project = n._root(
        model, "IfcProject", project_id, KIND, "project", Name="Original synthetic one-room study"
    )
    unit = model.createIfcSIUnit(UnitType="LENGTHUNIT", Name="METRE")
    project.UnitsInContext = model.createIfcUnitAssignment(
        [
            unit,
            model.createIfcSIUnit(UnitType="AREAUNIT", Name="SQUARE_METRE"),
            model.createIfcSIUnit(UnitType="VOLUMEUNIT", Name="CUBIC_METRE"),
        ]
    )
    context = model.createIfcGeometricRepresentationContext(
        None,
        "Model",
        3,
        1e-5,
        model.createIfcAxis2Placement3D(
            n._point(model, (0, 0, 0)),
            n._direction(model, (0, 0, 1)),
            n._direction(model, (1, 0, 0)),
        ),
        None,
    )
    project.RepresentationContexts = [context]
    parent, placement = project, None
    for cls, key, label in [
        ("IfcSite", "site", "Synthetic site"),
        ("IfcBuilding", "building", "Synthetic building"),
        ("IfcBuildingStorey", "storey", "Ground storey"),
        ("IfcSpace", "room", "One room"),
    ]:
        kwargs = dict(
            Name=label,
            CompositionType="ELEMENT",
            ObjectPlacement=n._placement(model, placement, (0, 0, 0)),
        )
        if cls == "IfcBuildingStorey":
            kwargs["Elevation"] = 0.0
        if cls == "IfcSpace":
            kwargs["Representation"] = n._box(model, context, 6, 4, 3)
        entity = n._root(model, cls, project_id, KIND, key, **kwargs)
        n._rel(
            model,
            "IfcRelAggregates",
            project_id,
            KIND,
            key,
            RelatingObject=parent,
            RelatedObjects=[entity],
        )
        parent, placement = entity, entity.ObjectPlacement
    space = parent
    n._pset(
        model,
        project_id,
        KIND,
        "room",
        space,
        "OpenCEA_ReferenceRoom",
        {
            "Profile": (PROFILE, "IfcIdentifier"),
            "Version": ("1", "IfcIdentifier"),
            "Length": (6, "IfcLengthMeasure"),
            "Depth": (4, "IfcLengthMeasure"),
            "Height": (3, "IfcLengthMeasure"),
            "AisleDepth": (1.2, "IfcLengthMeasure"),
            "EntryX": (0.2, "IfcLengthMeasure"),
            "EntryY": (0.6, "IfcLengthMeasure"),
            "RoomSourceId": (room_source_id, "IfcIdentifier"),
            "RackSourceId": (rack_source_id, "IfcIdentifier"),
        },
    )
    n._quantities(model, project_id, KIND, "room", space, 6, 4, 3, unit)
    specs = [
        (
            "rack",
            "IfcFurniture",
            "RACK-01",
            (1, 1.5, 0),
            (LENGTH, DEPTH, HEIGHT),
            "rack",
            rack_source_id,
        ),
        (
            "light",
            "IfcLightFixture",
            "Synthetic light symbol",
            (2, 2, 2.7),
            (0.6, 0.3, 0.15),
            "light",
            room_source_id,
        ),
        (
            "irrigation",
            "IfcElementAssembly",
            "Synthetic irrigation symbol",
            (4.8, 2, 0.0),
            (0.3, 0.3, 0.5),
            "irrigation",
            room_source_id,
        ),
        (
            "environment",
            "IfcElementAssembly",
            "Synthetic environmental symbol",
            (4.8, 3, 0.0),
            (0.4, 0.4, 0.7),
            "environment",
            room_source_id,
        ),
        (
            "sensor-a",
            "IfcSensor",
            "S-A",
            (2, 3, 1.8),
            (0.12, 0.12, 0.12),
            "sensor",
            scenario_source_id or room_source_id,
        ),
        (
            "sensor-b",
            "IfcSensor",
            "S-B",
            (3, 3, 1.8),
            (0.12, 0.12, 0.12),
            "sensor",
            scenario_source_id or room_source_id,
        ),
        ("slab", "IfcSlab", "Synthetic slab", (0, 0, -0.15), (6, 4, 0.15), None, None),
        ("west-wall", "IfcWall", "West enclosing wall", (-0.15, 0, 0), (0.15, 4, 3), None, None),
        ("east-wall", "IfcWall", "East enclosing wall", (6, 0, 0), (0.15, 4, 3), None, None),
        (
            "south-wall",
            "IfcWall",
            "South enclosing wall",
            (-0.15, -0.15, 0),
            (6.3, 0.15, 3),
            None,
            None,
        ),
        (
            "north-wall",
            "IfcWall",
            "North enclosing wall",
            (-0.15, 4, 0),
            (6.3, 0.15, 3),
            None,
            None,
        ),
    ]
    identity = dict(
        schema_version="0.2",
        id=n._id(project_id, KIND, "identity"),
        project_id=project_id,
        name="Original synthetic one-room study",
        model_sha256="",
        source_ids=source_ids,
        subjects=[],
        roles=[],
        assets=[],
        elements=[],
        channels=[],
        bindings=[],
        deployments=[],
        occupancies=[],
        transitions=[],
        unresolved_bindings=[],
    )
    catalog = dict(schema_version="0.2", items=[])

    def make_product(key, name, source):
        props = rack_definition["properties"] if key == "rack" else {}
        metadata = (
            {
                "unknowns": rack_definition["unknowns"],
                "representation": "envelope",
                "source_url": rack_definition["source_url"],
                "source_section": rack_definition["source_section"],
                "dimensional_precision": rack_definition["dimensions_note"],
                "shelf_count": rack_definition["shelf_count"],
                "shelf_kind": rack_definition["shelf_kind"],
                "conditional_load_note": rack_definition["conditional_load_note"],
            }
            if key == "rack"
            else {"unknowns": ["performance not specified"]}
        )
        item = dict(
            schema_version="0.1",
            id=n._id(project_id, KIND, "catalog/" + key),
            name=rack_definition["name"] if key == "rack" else name,
            manufacturer=rack_definition["manufacturer"]
            if key == "rack"
            else "OpenCEA original synthetic example",
            model=rack_definition["model"] if key == "rack" else "OCEA-SYN-" + key.upper(),
            properties={
                p: dict(
                    type="quantity",
                    value=value,
                    unit="m",
                    evidence_kind="declared",
                    source_ids=[source],
                )
                for p, value in props.items()
            },
            evidence_status="declared",
            source_ids=[source],
            extensions=metadata,
        )
        catalog["items"].append(item)
        return item

    types = {}
    for _key, _cls, name, _, _, product, source in specs:
        if not product or product in types:
            continue
        item = make_product(product, name, source)
        typ_cls = {
            "rack": "IfcFurnitureType",
            "light": "IfcLightFixtureType",
            "sensor": "IfcSensorType",
            "irrigation": "IfcElementAssemblyType",
            "environment": "IfcElementAssemblyType",
        }[product]
        typ = n._root(
            model,
            typ_cls,
            project_id,
            KIND,
            "type/" + product,
            Name=item["name"],
            PredefinedType="NOTDEFINED",
            **({"AssemblyPlace": "NOTDEFINED"} if product == "rack" else {}),
        )
        n._pset(
            model,
            project_id,
            KIND,
            "type/" + product,
            typ,
            "OpenCEA_Product",
            {"CatalogId": (item["id"], "IfcIdentifier")},
        )
        if product == "rack":
            declared = n._pset(
                model,
                project_id,
                KIND,
                "type/" + product,
                typ,
                "OpenCEA_Declared",
                {p: (v, "IfcLengthMeasure") for p, v in rack_definition["properties"].items()},
            )
            for prop in declared.HasProperties:
                prop.Unit = unit
            n._pset(
                model,
                project_id,
                KIND,
                "type/rack",
                typ,
                "OpenCEA_DetailLevel",
                {
                    "Purpose": ("envelope", "IfcIdentifier"),
                    "DimensionalPrecision": (rack_definition["dimensions_note"], "IfcText"),
                    "ShelfCount": (str(rack_definition["shelf_count"]), "IfcText"),
                    "ConditionalLoad": (rack_definition["conditional_load_note"], "IfcText"),
                    "Unknowns": ("; ".join(rack_definition["unknowns"]), "IfcText"),
                },
            )
        types[product] = (typ, item)
    entities = {}
    typed_occurrences = {product: [] for product in types}
    for key, cls, name, xyz, dims, product, _ in specs:
        entity = n._root(
            model,
            cls,
            project_id,
            KIND,
            key,
            Name=name,
            ObjectPlacement=n._placement(model, space.ObjectPlacement, xyz),
            Representation=n._box(model, context, *dims),
        )
        entities[key] = entity
        row = dict(
            id=n._id(project_id, KIND, "element/" + key),
            ifc_global_id=entity.GlobalId,
            ifc_class=cls,
            product_id=types[product][1]["id"] if product else None,
            role_id=None,
            asset_id=None,
            state="active",
            evidence_kind="proposed",
        )
        identity["elements"].append(row)
        n._pset(
            model,
            project_id,
            KIND,
            key,
            entity,
            "OpenCEA_Identity",
            {"ElementId": (row["id"], "IfcIdentifier")},
        )
        n._quantities(model, project_id, KIND, key, entity, *dims, unit)
        n._rel(
            model,
            "IfcRelContainedInSpatialStructure",
            project_id,
            KIND,
            "contain/" + key,
            RelatingStructure=space,
            RelatedElements=[entity],
        )
        if product:
            typed_occurrences[product].append(entity)
        if key == "rack":
            n._pset(
                model,
                project_id,
                KIND,
                key,
                entity,
                "OpenCEA_Representation",
                {
                    "Purpose": ("envelope", "IfcIdentifier"),
                    "Unknowns": ("internal members; shelf positions; caster sweep", "IfcText"),
                },
            )
    for product, occurrences in typed_occurrences.items():
        n._rel(
            model,
            "IfcRelDefinesByType",
            project_id,
            KIND,
            "type/" + product,
            RelatingType=types[product][0],
            RelatedObjects=occurrences,
        )
    opening = n._root(
        model,
        "IfcOpeningElement",
        project_id,
        KIND,
        "opening",
        Name="West door opening",
        ObjectPlacement=n._placement(model, space.ObjectPlacement, (-0.15, 0.1, 0)),
        Representation=n._box(model, context, 0.15, 1, 2.1),
    )
    door = n._root(
        model,
        "IfcDoor",
        project_id,
        KIND,
        "door",
        Name="Synthetic door",
        OverallWidth=1.0,
        OverallHeight=2.1,
        ObjectPlacement=n._placement(model, space.ObjectPlacement, (-0.105, 0.1, 0)),
        Representation=n._box(model, context, 0.06, 1, 2.1),
    )
    row = dict(
        id=n._id(project_id, KIND, "element/door"),
        ifc_global_id=door.GlobalId,
        ifc_class="IfcDoor",
        product_id=None,
        role_id=None,
        asset_id=None,
        state="active",
        evidence_kind="proposed",
    )
    identity["elements"].append(row)
    n._pset(
        model,
        project_id,
        KIND,
        "door",
        door,
        "OpenCEA_Identity",
        {"ElementId": (row["id"], "IfcIdentifier")},
    )
    n._quantities(model, project_id, KIND, "door", door, 0.06, 1, 2.1, unit)
    n._rel(
        model,
        "IfcRelContainedInSpatialStructure",
        project_id,
        KIND,
        "contain/door",
        RelatingStructure=space,
        RelatedElements=[door],
    )
    n._rel(
        model,
        "IfcRelVoidsElement",
        project_id,
        KIND,
        "void/door",
        RelatingBuildingElement=entities["west-wall"],
        RelatedOpeningElement=opening,
    )
    n._rel(
        model,
        "IfcRelFillsElement",
        project_id,
        KIND,
        "fill/door",
        RelatingOpeningElement=opening,
        RelatedBuildingElement=door,
    )
    artifacts = n._serialize(model, identity, catalog)
    n.validate_candidate(artifacts, program)
    return artifacts


def reference_access(artifacts):
    model, identity, _ = n._read_candidate(artifacts)
    space = _profile(model)
    length, depth, height = (
        value * ifcopenshell.util.unit.calculate_unit_scale(model) for value in _dimensions(model)
    )
    row, rack = _rack(model, identity)
    scale = ifcopenshell.util.unit.calculate_unit_scale(model)
    room_matrix = ifcopenshell.util.placement.get_local_placement(space.ObjectPlacement)
    import numpy as np

    inverse = np.linalg.inv(room_matrix)

    def corners_for(entity):
        transform = inverse @ ifcopenshell.util.placement.get_local_placement(
            entity.ObjectPlacement
        )
        a, b, c = (v * scale for v in n._dimensions(entity))
        points = [
            transform @ [x / scale, y / scale, z / scale, 1]
            for x in (0, a)
            for y in (0, b)
            for z in (0, c)
        ]
        return [[float(point[i] * scale) for i in range(3)] for point in points]

    corners = corners_for(rack)
    findings = []
    occupied = []
    for item in identity["elements"]:
        if item["state"] != "active" or item["product_id"] is None:
            continue
        entity = model.by_guid(item["ifc_global_id"])
        points = corners_for(entity)
        label = "rack" if item["id"] == row["id"] else entity.Name
        if any(
            not (
                -1e-6 <= x <= length + 1e-6
                and -1e-6 <= y <= depth + 1e-6
                and -1e-6 <= z <= height + 1e-6
            )
            for x, y, z in points
        ):
            findings.append(f"{label} outside room bounds")
        if min(p[2] for p in points) < 1.6:
            occupied.append(
                (
                    label,
                    min(p[0] for p in points),
                    max(p[0] for p in points),
                    min(p[1] for p in points),
                    max(p[1] for p in points),
                )
            )
    if min(c[1] for c in corners) < 1.2 - 1e-6:
        findings.append("rack obstructs reserved aisle")
    transform = inverse @ ifcopenshell.util.placement.get_local_placement(rack.ObjectPlacement)
    r_length = n._dimensions(rack)[0]
    service = transform @ [r_length / 2, -0.6 / scale, 0, 1]
    point = [float(service[i] * scale) for i in range(3)]
    if not (0 <= point[0] <= length and 0 <= point[1] <= depth):
        findings.append("rack service point outside room")
    # Two room-local segments: west entry along aisle y=.6, then to the transformed service point.
    for label, x0, x1, y0, y1 in occupied:
        if (
            x1 > min(0.2, point[0]) + 1e-6 and x0 < max(0.2, point[0]) - 1e-6 and y0 < 0.6 < y1
        ) or (
            x0 < point[0] < x1 and y1 > min(0.6, point[1]) + 1e-6 and y0 < max(0.6, point[1]) - 1e-6
        ):
            findings.append(f"{label} obstructs service route")
    return dict(
        profile=PROFILE,
        routeDistanceM=abs(point[0] - 0.2) + abs(point[1] - 0.6) if not findings else None,
        servicePointM=point if not findings else None,
        findings=findings,
    )


def move_reference_rack(artifacts, *, x_m, y_m, rotation_degrees):
    """Move the unique reference rack in room-local SI, regardless of its old parent."""
    model, identity, catalog = n._candidate(artifacts)
    space = _profile(model)
    row, rack = _rack(model, identity)
    room_matrix = ifcopenshell.util.placement.get_local_placement(space.ObjectPlacement)
    rack_matrix = ifcopenshell.util.placement.get_local_placement(rack.ObjectPlacement)
    import numpy as np

    room_local = np.linalg.inv(room_matrix) @ rack_matrix
    rack.ObjectPlacement.PlacementRelTo = space.ObjectPlacement
    # The generic native move writes coordinates relative to PlacementRelTo.
    candidate = n._serialize(model, identity, catalog)
    moved = n.move_element(
        candidate,
        row["id"],
        x_m=x_m,
        y_m=y_m,
        z_m=float(room_local[2, 3] * ifcopenshell.util.unit.calculate_unit_scale(model)),
        rotation_degrees=rotation_degrees,
    )
    access = reference_access(moved)
    if access["findings"]:
        raise ContractError("; ".join(access["findings"]))
    return moved


def resize_reference_room(artifacts, *, length_m, depth_m, height_m, program=None):
    dimensions = (length_m, depth_m, height_m)
    if any(not isinstance(v, (int, float)) or not math.isfinite(v) for v in dimensions) or not (
        4 <= length_m <= 12 and 3 <= depth_m <= 8 and 2.5 <= height_m <= 5
    ):
        raise ContractError("room dimensions outside study bounds")
    model, identity, catalog = n._candidate(artifacts)
    space = _profile(model)
    scale = 1 / ifcopenshell.util.unit.calculate_unit_scale(model)

    def size(key, dims, xyz=None):
        entity = (
            space
            if key == "room"
            else model.by_guid(
                next(
                    r["ifc_global_id"]
                    for r in identity["elements"]
                    if r["id"] == n._id(identity["project_id"], KIND, "element/" + key)
                )
            )
        )
        solid = n._geometry(entity)
        points = solid.SweptArea.OuterCurve.Points
        for index, coords in enumerate(
            ((0, 0), (dims[0], 0), (dims[0], dims[1]), (0, dims[1]), (0, 0))
        ):
            points[index].Coordinates = tuple(float(v) for v in coords)
        solid.Depth = float(dims[2])
        n._update_measures(entity, dims)
        if xyz is not None:
            entity.ObjectPlacement.RelativePlacement.Location.Coordinates = tuple(
                float(v) for v in xyz
            )

    size("room", tuple(value * scale for value in dimensions))
    for key, dims, xyz in [
        ("slab", (length_m, depth_m, 0.15), (0, 0, -0.15)),
        ("east-wall", (0.15, depth_m, height_m), (length_m, 0, 0)),
        ("south-wall", (length_m + 0.3, 0.15, height_m), (-0.15, -0.15, 0)),
        ("north-wall", (length_m + 0.3, 0.15, height_m), (-0.15, depth_m, 0)),
        ("west-wall", (0.15, depth_m, height_m), (-0.15, 0, 0)),
    ]:
        size(key, tuple(value * scale for value in dims), tuple(value * scale for value in xyz))
    for prop in next(
        rel.RelatingPropertyDefinition
        for rel in space.IsDefinedBy
        if rel.is_a("IfcRelDefinesByProperties")
        and rel.RelatingPropertyDefinition.is_a("IfcPropertySet")
        and rel.RelatingPropertyDefinition.Name == "OpenCEA_ReferenceRoom"
    ).HasProperties:
        if prop.Name in ("Length", "Depth", "Height"):
            prop.NominalValue.wrappedValue = (
                dimensions[("Length", "Depth", "Height").index(prop.Name)] * scale
            )
    result = n._serialize(model, identity, catalog)
    access = reference_access(result)
    if access["findings"]:
        raise ContractError("; ".join(access["findings"]))
    if program is not None:
        n.validate_candidate(result, program)
    return result
