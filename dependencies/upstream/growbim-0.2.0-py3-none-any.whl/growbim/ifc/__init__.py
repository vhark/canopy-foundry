"""Optional IFC4 candidate authoring. Importing this module never imports the native extra."""


def build_facility(program, source_id):
    from .facility import build_facility as implementation

    return implementation(program, source_id)


def reconcile_facility_edit(artifacts, edited_ifc, program, element_id):
    from .exchange import reconcile_facility_edit as implementation

    return implementation(artifacts, edited_ifc, program, element_id)


def build_reference_room(program, room_source_id, rack_source_id, *, scenario_source_id=None):
    from .reference_room import build_reference_room as implementation

    return implementation(
        program, room_source_id, rack_source_id, scenario_source_id=scenario_source_id
    )


def resize_reference_room(artifacts, *, length_m, depth_m, height_m, program=None):
    from .reference_room import resize_reference_room as implementation

    return implementation(
        artifacts, length_m=length_m, depth_m=depth_m, height_m=height_m, program=program
    )


def reference_access(artifacts):
    from .reference_room import reference_access as implementation

    return implementation(artifacts)


def move_reference_rack(artifacts, *, x_m, y_m, rotation_degrees):
    from .reference_room import move_reference_rack as implementation

    return implementation(artifacts, x_m=x_m, y_m=y_m, rotation_degrees=rotation_degrees)


def reconcile_placement_edit(artifacts, edited_ifc, program, element_id):
    from .exchange import reconcile_placement_edit as implementation

    return implementation(artifacts, edited_ifc, program, element_id)


def build_fixture(kind, project_id, source_id, *, length_unit="m"):
    from ._native import build_fixture as implementation

    return implementation(kind, project_id, source_id, length_unit=length_unit)


def fixture_expectations(kind):
    from ._native import fixture_expectations as implementation

    return implementation(kind)


def validate_candidate(artifacts, program):
    from ._native import validate_candidate as implementation

    return implementation(artifacts, program)


def resize_element(artifacts, element_id, *, length_m):
    from ._native import resize_element as implementation

    return implementation(artifacts, element_id, length_m=length_m)


def move_element(artifacts, element_id, *, x_m, y_m, z_m, rotation_degrees=0):
    from ._native import move_element as implementation

    return implementation(
        artifacts, element_id, x_m=x_m, y_m=y_m, z_m=z_m, rotation_degrees=rotation_degrees
    )


def rename_element(artifacts, element_id, name):
    from ._native import rename_element as implementation

    return implementation(artifacts, element_id, name)


def copy_element(artifacts, element_id, *, at, name=None):
    from ._native import copy_element as implementation

    return implementation(artifacts, element_id, at=at, name=name)


def install_element(artifacts, element_id, *, source_id):
    from ._native import install_element as implementation

    return implementation(artifacts, element_id, source_id=source_id)


def replace_element(artifacts, element_id, *, source_id, at, retain_role=False):
    from ._native import replace_element as implementation

    return implementation(
        artifacts, element_id, source_id=source_id, at=at, retain_role=retain_role
    )


def retire_element(artifacts, element_id, *, at):
    from ._native import retire_element as implementation

    return implementation(artifacts, element_id, at=at)
