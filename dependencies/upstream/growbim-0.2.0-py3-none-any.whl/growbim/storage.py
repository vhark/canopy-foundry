"""Durable file writes and shared identifiers for local project and job storage."""

from __future__ import annotations

import hashlib
import os
import tempfile
from pathlib import Path

from opencea.contracts import ContractError


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def validate_digest(value: str) -> str:
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(c not in "0123456789abcdef" for c in value)
    ):
        raise ContractError("invalid revision hash")
    return value


def fsync_dir(folder: Path) -> None:
    fd = os.open(folder, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def durable_mkdir(folder: Path) -> None:
    if folder.is_symlink():
        raise ContractError("symlink in storage directory")
    if folder.is_dir():
        fsync_dir(folder.parent)
        return
    durable_mkdir(folder.parent)
    try:
        folder.mkdir(mode=0o700)
    except FileExistsError:
        if not folder.is_dir() or folder.is_symlink():
            raise ContractError("invalid storage directory") from None
    fsync_dir(folder.parent)


def atomic_write(path: Path, data: bytes) -> None:
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=".pending-")
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(tmp, path)
        fsync_dir(path.parent)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)
