"""GrowBIM offline concept program operations."""
