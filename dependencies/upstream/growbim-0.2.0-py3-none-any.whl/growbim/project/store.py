"""Offline accepted-head store; service acceptance instead belongs to its database."""

from __future__ import annotations

import fcntl
import os
from contextlib import contextmanager
from pathlib import Path
from uuid import uuid4

from growbim.program.intake import new_program
from growbim.project.artifacts import design_request
from growbim.project.revisions import (
    MAX_ARCHIVE,
    MAX_FILE,
    _project,
    _read_manifest,
    export_project,
    import_project,
    parse_archive_header,
    prepare_revision,
    read_program,
    request_hash,
)
from growbim.requirements.questions import QuestionError, answer_question
from growbim.storage import atomic_write, durable_mkdir, validate_digest
from opencea.contracts import ContractError, dumps, loads, parse_uuid


class LocalProjectStore:
    def __init__(self, root: Path):
        self.root = Path(root)

    @contextmanager
    def _lock(self, project_id: str):
        project = _project(self.root, project_id)
        durable_mkdir(project)
        lock = project / ".lock"
        if lock.is_symlink():
            raise ContractError("unsafe project lock")
        fd = os.open(lock, os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0), 0o600)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX)
            yield project
        finally:
            fcntl.flock(fd, fcntl.LOCK_UN)
            os.close(fd)

    def head(self, project_id: str) -> str | None:
        project_id = parse_uuid(project_id)
        project = _project(self.root, project_id)
        path = project / "HEAD"
        if path.is_symlink():
            raise ContractError("unsafe HEAD symlink", code="storage_unavailable")
        if not path.exists():
            return None
        try:
            revision = validate_digest(path.read_text(encoding="ascii").strip())
        except (OSError, UnicodeError, ContractError) as exc:
            raise ContractError("invalid accepted HEAD", code="storage_unavailable") from exc
        read_program(self.root, project_id, revision)
        return revision

    def create(self, name: str, request_id: str, project_id: str | None = None) -> dict:
        request_id = parse_uuid(request_id)
        if project_id is not None:
            project_id = parse_uuid(project_id)
        receipts = self.root / "create-receipts"
        durable_mkdir(receipts)
        lock = receipts / ".lock"
        if lock.is_symlink():
            raise ContractError("unsafe project lock", code="storage_unavailable")
        fd = os.open(lock, os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0), 0o600)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX)
            receipt_path = receipts / request_id
            if receipt_path.is_symlink():
                raise ContractError("unsafe creation receipt", code="storage_unavailable")
            if receipt_path.exists():
                receipt = loads(receipt_path.read_bytes())
                if receipt["name"] != name or (
                    project_id is not None and project_id != receipt["project_id"]
                ):
                    raise ContractError(
                        "request id reused with different payload", code="request_reused"
                    )
                return dict(
                    revision=receipt["revision"],
                    project_id=receipt["project_id"],
                    program=read_program(self.root, receipt["project_id"], receipt["revision"]),
                )
            project_id = project_id or str(uuid4())
            with self._lock(project_id) as project:
                if self.head(project_id) is not None:
                    raise ContractError("project already exists", code="invalid_project")
                program = new_program(project_id, name)
                manifest = prepare_revision(
                    self.root,
                    project_id,
                    None,
                    request_id,
                    {"operation": "create", "name": name},
                    program,
                )
                atomic_write(project / "HEAD", (manifest["revision"] + "\n").encode("ascii"))
                atomic_write(
                    receipt_path,
                    dumps(dict(name=name, project_id=project_id, revision=manifest["revision"])),
                )
                return dict(revision=manifest["revision"], project_id=project_id, program=program)
        finally:
            fcntl.flock(fd, fcntl.LOCK_UN)
            os.close(fd)

    def inspect(self, project_id: str) -> dict:
        project_id = parse_uuid(project_id)
        revision = self.head(project_id)
        if revision is None:
            raise ContractError("project not found", code="project_not_found")
        return dict(
            project_id=project_id,
            revision=revision,
            program=read_program(self.root, project_id, revision),
        )

    def accept(
        self,
        project_id: str,
        expected_revision: str,
        request_id: str,
        program: dict | None,
        request: dict | None = None,
        *,
        artifacts: dict[str, bytes] | None = None,
    ) -> dict:
        project_id = parse_uuid(project_id)
        request_id = parse_uuid(request_id)
        validate_digest(expected_revision)
        with self._lock(project_id) as project:
            current = self.head(project_id)
            if current is None:
                raise ContractError("project not found", code="project_not_found")
            # The immutable receipt is checked before the accepted-head CAS. An exact retry
            # continues to return the original revision even if later revisions were accepted.
            request = (
                request
                if request is not None
                else dict(
                    expected_revision=expected_revision, request_id=request_id, program=program
                )
            )
            ancestor = current
            seen = set()
            boundary_path = project / "WINDOW"
            if boundary_path.is_symlink():
                raise ContractError("symlink in revision", code="storage_unavailable")
            boundary = (
                validate_digest(boundary_path.read_text(encoding="ascii").strip())
                if boundary_path.exists()
                else None
            )
            while ancestor is not None and ancestor != boundary:
                if ancestor in seen:
                    raise ContractError("cyclic accepted history", code="storage_unavailable")
                seen.add(ancestor)
                manifest, _ = _read_manifest(self.root, project_id, ancestor)
                if manifest["request_id"] == request_id:
                    recorded_program = read_program(self.root, project_id, ancestor)
                    if manifest["request_hash"] != request_hash(
                        request, recorded_program if program is None else program, expected_revision
                    ):
                        raise ContractError(
                            "request id reused with different payload", code="request_reused"
                        )
                    return dict(
                        revision=ancestor,
                        current_revision=current,
                        request_id=request_id,
                        replayed=True,
                    )
                ancestor = manifest["parent_revision"]
            if current != expected_revision:
                raise ContractError(f"stale revision: current={current}", code="revision_conflict")
            if program is None:
                if request.get("operation") != "accept_design":
                    raise ContractError("revision requires a program")
                program = read_program(self.root, project_id, expected_revision)
            manifest = prepare_revision(
                self.root,
                project_id,
                current,
                request_id,
                request,
                program,
                artifacts=artifacts,
            )
            atomic_write(project / "HEAD", (manifest["revision"] + "\n").encode("ascii"))
            return dict(
                revision=manifest["revision"],
                current_revision=manifest["revision"],
                request_id=request_id,
                replayed=False,
            )

    def accept_design(
        self,
        project_id: str,
        expected_revision: str,
        request_id: str,
        artifacts: dict[str, bytes],
        decision: dict,
    ) -> dict:
        request = design_request(project_id, expected_revision, request_id, artifacts, decision)
        return self.accept(
            project_id,
            expected_revision,
            request_id,
            None,
            request=request,
            artifacts=artifacts,
        )

    def answer_question(
        self,
        project_id: str,
        expected_revision: str,
        request_id: str,
        question_id: str,
        statement_id: str,
        source_id: str,
        value: dict,
    ) -> dict:
        project_id = parse_uuid(project_id)
        validate_digest(expected_revision)
        identifiers = {}
        for name, identifier in (
            ("request_id", request_id),
            ("statement_id", statement_id),
            ("source_id", source_id),
        ):
            try:
                identifiers[name] = parse_uuid(identifier)
            except ContractError as exc:
                raise QuestionError("invalid_request", f"{name} must be a UUID") from exc
        expected = read_program(self.root, project_id, expected_revision)
        candidate, resolved = answer_question(
            expected,
            question_id=question_id,
            statement_id=identifiers["statement_id"],
            source_id=identifiers["source_id"],
            value=value,
        )
        accepted = self.accept(
            project_id,
            expected_revision,
            identifiers["request_id"],
            candidate,
            request={
                "operation": "answer_question",
                "project_id": project_id,
                "request_id": identifiers["request_id"],
                "expected_revision": expected_revision,
                "question_id": question_id,
                "statement_id": identifiers["statement_id"],
                "source_id": identifiers["source_id"],
                "value": value,
            },
        )
        return {
            "accepted_revision": accepted["revision"],
            "answered_question_id": question_id,
            "question_resolved": resolved,
            "replayed": accepted["replayed"],
            "project": self.inspect(project_id),
        }

    def export(self, project_id: str) -> bytes:
        project_id = parse_uuid(project_id)
        revision = self.head(project_id)
        if revision is None:
            raise ContractError("project not found", code="project_not_found")
        return export_project(self.root, project_id, revision)

    def import_archive(self, data: bytes) -> dict:
        # Validation occurs before accepting a new HEAD. The importer never overwrites
        # an existing accepted project, even if candidate revisions were already present.
        import io
        import zipfile

        try:
            if len(data) > MAX_ARCHIVE:
                raise ContractError("archive exceeds size limit")
            with zipfile.ZipFile(io.BytesIO(data)) as archive:
                header_info = archive.getinfo("project.json")
                if header_info.file_size > MAX_FILE:
                    raise ContractError("oversized archive header")
                header = loads(archive.read(header_info))
            project_id, imported_revision, _ = parse_archive_header(header)
        except (KeyError, ValueError, zipfile.BadZipFile) as exc:
            if isinstance(exc, ContractError):
                raise
            raise ContractError("invalid archive header") from exc
        with self._lock(project_id) as project:
            current = self.head(project_id)
            if current is not None and current != imported_revision:
                raise ContractError("import conflicts with existing accepted HEAD")
            imported = import_project(self.root, data)
            if current is None:
                atomic_write(project / "HEAD", (imported["revision"] + "\n").encode("ascii"))
            return imported
