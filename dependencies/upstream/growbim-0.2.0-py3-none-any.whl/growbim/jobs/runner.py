"""Fixed, private assessment subprocess and checked artifact boundary."""

from __future__ import annotations

import hashlib
import os
import signal
import stat
import subprocess
import sys
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from opencea.contracts import ContractError, dumps, loads, parse_uuid

from growbim.program.intake import validate_program
from growbim.project.revisions import MAX_FILE
from growbim.storage import validate_digest

_ALLOWED = {
    "assessment.json": ("result", "application/json"),
    "stdout.log": ("log", "text/plain"),
    "stderr.log": ("log", "text/plain"),
}
_MAX_ARTIFACT = 16 * 1024 * 1024


@dataclass(frozen=True)
class JobLimits:
    wall_seconds: int = 30
    cpu_seconds: int = 10
    memory_bytes: int = 536870912
    output_bytes: int = 1048576
    trusted_local: bool = False


@dataclass(frozen=True)
class JobResult:
    status: str
    error: dict | None
    artifacts: list[dict]


def _regular(path: Path, maximum: int) -> bytes:
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > maximum:
            raise ContractError("unsafe or oversized artifact")
        with os.fdopen(os.dup(fd), "rb") as stream:
            data = stream.read(maximum + 1)
        if len(data) != info.st_size or len(data) > maximum or os.fstat(fd).st_size != info.st_size:
            raise ContractError("artifact changed during read")
        return data
    finally:
        os.close(fd)


def read_artifact(work_dir: Path, descriptor: dict) -> bytes:
    name = descriptor.get("name")
    if (
        name not in _ALLOWED
        or descriptor.get("kind") != _ALLOWED[name][0]
        or descriptor.get("media_type") != _ALLOWED[name][1]
    ):
        raise ContractError("invalid artifact descriptor")
    size = descriptor.get("bytes")
    digest = descriptor.get("sha256")
    if (
        type(size) is not int
        or size < 0
        or size > _MAX_ARTIFACT
        or not isinstance(digest, str)
        or len(digest) != 64
    ):
        raise ContractError("invalid artifact descriptor")
    work_dir = Path(work_dir)
    if work_dir.is_symlink() or (work_dir / "output").is_symlink():
        raise ContractError("unsafe artifact directory")
    try:
        data = _regular(work_dir / "output" / name, min(size, _MAX_ARTIFACT))
    except (OSError, ValueError) as exc:
        raise ContractError("artifact unavailable") from exc
    if len(data) != size or hashlib.sha256(data).hexdigest() != digest:
        raise ContractError("artifact size or digest mismatch")
    return data


def _descriptor(name: str, data: bytes) -> dict:
    return dict(
        name=name,
        kind=_ALLOWED[name][0],
        media_type=_ALLOWED[name][1],
        bytes=len(data),
        sha256=hashlib.sha256(data).hexdigest(),
    )


def _failure(code: str, detail: str) -> JobResult:
    return JobResult("failed", dict(code=code, detail=detail), [])


def _stop(child: subprocess.Popen) -> None:
    try:
        os.killpg(child.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    child.wait()


def _persist_artifacts(work_dir: Path, names: tuple[str, ...]) -> None:
    output = work_dir / "output"
    for name in names:
        fd = os.open(output / name, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
        try:
            info = os.fstat(fd)
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                raise ContractError("unsafe artifact")
            os.fsync(fd)
        finally:
            os.close(fd)
    for directory in (output, work_dir, work_dir.parent):
        fd = os.open(directory, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)


def run_assessment(
    program: dict,
    *,
    revision: str,
    work_dir: Path,
    cancel: Callable[[], bool] | None = None,
    progress: Callable[[str], None] | None = None,
    limits: JobLimits | None = None,
) -> JobResult:
    limits = limits or JobLimits()
    if os.name != "posix" or (sys.platform != "linux" and not limits.trusted_local):
        raise ContractError(
            "bounded execution requires Linux; non-Linux POSIX requires explicit trusted_local policy (no hard memory isolation)"
        )
    if any(
        type(value) is not int or value <= 0
        for value in (
            limits.wall_seconds,
            limits.cpu_seconds,
            limits.memory_bytes,
            limits.output_bytes,
        )
    ):
        raise ContractError("job limits must be positive integers")
    if limits.output_bytes > _MAX_ARTIFACT:
        raise ContractError("job output limit exceeds artifact ceiling")
    validate_digest(revision)
    validate_program(program)
    parse_uuid(program["project_id"])
    frozen = dumps(program)
    if len(frozen) > MAX_FILE:
        raise ContractError("program exceeds input limit")
    work_dir = Path(work_dir)
    if work_dir.exists() or work_dir.is_symlink():
        raise ContractError("run directory must be new")
    work_dir.mkdir(mode=0o700)
    (work_dir / "output").mkdir(mode=0o700)
    input_path = work_dir / "input.json"
    with input_path.open("xb") as stream:
        stream.write(frozen)
        stream.flush()
        os.fsync(stream.fileno())
    input_path.chmod(0o400)

    parent_read, parent_write = os.pipe()
    child = None
    stdout_path, stderr_path = (work_dir / "output" / name for name in ("stdout.log", "stderr.log"))
    try:
        with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
            child = subprocess.Popen(
                [
                    sys.executable,
                    "-I",
                    "-m",
                    "growbim.jobs._child",
                    str(parent_read),
                    str(work_dir.absolute()),
                    revision,
                    str(limits.cpu_seconds),
                    str(limits.output_bytes),
                    str(limits.memory_bytes),
                ],
                stdin=subprocess.DEVNULL,
                stdout=stdout,
                stderr=stderr,
                pass_fds=(parent_read,),
                start_new_session=True,
                close_fds=True,
                env={
                    "PATH": "/usr/bin:/bin",
                    "LANG": "C.UTF-8",
                    "PYTHONIOENCODING": "utf-8",
                    "PYTHONDONTWRITEBYTECODE": "1",
                },
            )
        os.close(parent_read)
        parent_read = -1
        started = time.monotonic()
        while child.poll() is None:
            if cancel is not None and cancel():
                _stop(child)
                return JobResult("cancelled", None, [])
            if time.monotonic() - started >= limits.wall_seconds:
                _stop(child)
                return _failure("wall_timeout", "assessment exceeded wall-clock limit")
            sizes = sum(path.stat().st_size for path in (stdout_path, stderr_path) if path.exists())
            result_path = work_dir / "output" / "assessment.json"
            if result_path.exists():
                sizes += result_path.stat().st_size
            if sizes > limits.output_bytes:
                _stop(child)
                return _failure("output_limit", "assessment exceeded output budget")
            time.sleep(0.02)
        if (
            sum(path.stat().st_size for path in (work_dir / "output").iterdir() if path.is_file())
            > limits.output_bytes
        ):
            return _failure("output_limit", "assessment exceeded output budget")
        if child.returncode == 2:
            try:
                raw_failure = _regular(work_dir / "output" / "failure.json", 4096)
                failure = loads(raw_failure)
                if (
                    set(failure) == {"code", "detail"}
                    and isinstance(failure["code"], str)
                    and isinstance(failure["detail"], str)
                    and dumps(failure) == raw_failure
                ):
                    return _failure(failure["code"], failure["detail"])
            except (OSError, ContractError, TypeError):
                pass
        if child.returncode:
            if child.returncode == -signal.SIGXFSZ:
                return _failure("output_limit", "assessment exceeded output budget")
            code = (
                "resource_limit"
                if child.returncode < 0 and -child.returncode in (signal.SIGXCPU, signal.SIGKILL)
                else "worker_error"
            )
            return _failure(
                code,
                "assessment process exceeded a resource limit"
                if code == "resource_limit"
                else "assessment process failed",
            )
        if cancel is not None and cancel():
            return JobResult("cancelled", None, [])
        output = work_dir / "output"
        if any(entry.name not in _ALLOWED or entry.is_symlink() for entry in output.iterdir()):
            return _failure("worker_error", "unexpected assessment output")
        artifacts = []
        total = 0
        for name in ("assessment.json", "stdout.log", "stderr.log"):
            try:
                data = _regular(output / name, limits.output_bytes)
            except (OSError, ContractError):
                return _failure("output_limit", "assessment output missing, unsafe or oversized")
            total += len(data)
            if total > limits.output_bytes:
                return _failure("output_limit", "assessment exceeded output budget")
            if name == "assessment.json":
                try:
                    result = loads(data)
                    if (
                        result
                        != dict(
                            schema_version="0.1",
                            operation="assess_program",
                            project_id=program["project_id"],
                            revision=revision,
                            assessment=result["assessment"],
                        )
                        or dumps(result) != data
                    ):
                        raise ContractError("invalid assessment identity")
                except (KeyError, ContractError):
                    return _failure("worker_error", "invalid assessment result")
            if data or name == "assessment.json":
                artifacts.append(_descriptor(name, data))
        if progress is not None:
            progress("checking_output")
        try:
            _persist_artifacts(work_dir, tuple(item["name"] for item in artifacts))
        except (OSError, ContractError):
            return _failure("worker_error", "assessment artifacts could not be persisted")
        return JobResult("succeeded", None, artifacts)
    finally:
        if child is not None and child.poll() is None:
            _stop(child)
        if parent_read >= 0:
            os.close(parent_read)
        os.close(parent_write)
