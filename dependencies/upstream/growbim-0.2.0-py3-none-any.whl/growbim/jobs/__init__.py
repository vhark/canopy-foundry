"""Fixed offline assessment jobs and durable local receipts."""
