"""Fixed assessment recipe. Not a general-purpose job or plugin entrypoint."""

from __future__ import annotations

import os
import resource
import select
import signal
import sys
import threading
from pathlib import Path

from opencea.contracts import ContractError, dumps, loads

from growbim.requirements.evaluate import assess_program


def _watch_parent(fd: int) -> None:
    # EOF means the parent died without reaping this process group. The pipe is
    # deliberately inherited only by this child, not by descendants it creates.
    select.select([fd], [], [])
    try:
        os.killpg(0, signal.SIGKILL)
    except ProcessLookupError:
        pass
    os._exit(1)


def main() -> int:
    fd = int(sys.argv[1])
    work = Path(sys.argv[2])
    revision = sys.argv[3]
    cpu, output_limit, memory = map(int, sys.argv[4:7])
    resource.setrlimit(resource.RLIMIT_CPU, (cpu, cpu))
    resource.setrlimit(resource.RLIMIT_FSIZE, (output_limit, output_limit))
    if sys.platform == "linux":
        resource.setrlimit(resource.RLIMIT_AS, (memory, memory))
    threading.Thread(target=_watch_parent, args=(fd,), daemon=True).start()
    program = loads((work / "input.json").read_bytes())
    try:
        assessment = assess_program(program)
    except ContractError as exc:
        (work / "output" / "failure.json").write_bytes(dumps(dict(code=exc.code, detail=str(exc))))
        return 2
    output = dumps(
        dict(
            schema_version="0.1",
            operation="assess_program",
            project_id=program["project_id"],
            revision=revision,
            assessment=assessment,
        )
    )
    path = work / "output" / "assessment.json"
    handle = os.open(
        path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600
    )
    with os.fdopen(handle, "wb") as stream:
        stream.write(output)
        stream.flush()
        os.fsync(stream.fileno())
    return 0


if __name__ == "__main__":
    sys.exit(main())
