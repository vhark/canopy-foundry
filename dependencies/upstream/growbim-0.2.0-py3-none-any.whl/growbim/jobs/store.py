"""Durable offline job receipts separate from accepted project HEAD."""

from __future__ import annotations

import fcntl
import os
import sys
import threading
import traceback
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from uuid import uuid4

from opencea.contracts import ContractError, dumps, loads, parse_uuid

from growbim.jobs.runner import JobLimits, read_artifact, run_assessment
from growbim.project.revisions import MAX_FILE, read_program
from growbim.project.store import LocalProjectStore
from growbim.storage import atomic_write, durable_mkdir, validate_digest

_LOCK_GUARD = threading.Lock()
_LOCKS: dict[str, threading.Lock] = {}


def _thread_lock(key: str) -> threading.Lock:
    with _LOCK_GUARD:
        return _LOCKS.setdefault(key, threading.Lock())


def _now() -> str:
    return datetime.now(UTC).isoformat()


class LocalJobStore:
    def __init__(self, root: Path):
        self.root = Path(root)
        self.projects = LocalProjectStore(self.root)

    @property
    def directory(self) -> Path:
        return self.root / "jobs"

    @contextmanager
    def _file_lock(self, path: Path, *, blocking: bool = True):
        if path.is_symlink():
            raise ContractError("unsafe job lock")
        key = str(path.absolute())
        thread = _thread_lock(key)
        if not thread.acquire(blocking=blocking):
            yield False
            return
        fd = None
        try:
            fd = os.open(path, os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0), 0o600)
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | (0 if blocking else fcntl.LOCK_NB))
            except BlockingIOError:
                yield False
                return
            try:
                yield True
            finally:
                fcntl.flock(fd, fcntl.LOCK_UN)
        finally:
            if fd is not None:
                os.close(fd)
            thread.release()

    @contextmanager
    def _metadata_lock(self):
        durable_mkdir(self.directory)
        with self._file_lock(self.directory / ".lock"):
            yield

    def _path(self, job_id: str) -> Path:
        path = self.directory / parse_uuid(job_id)
        if path.is_symlink():
            raise ContractError("unsafe job directory")
        return path

    def _read(self, job_id: str) -> dict:
        job_id = parse_uuid(job_id)
        path = self._path(job_id) / "record.json"
        if path.is_symlink():
            raise ContractError("unsafe job record")
        try:
            if path.stat().st_size > MAX_FILE:
                raise ContractError("oversized job record")
            record = loads(path.read_bytes())
        except (FileNotFoundError, IsADirectoryError) as exc:
            raise ContractError("job not found", code="job_not_found") from exc
        if record.get("id") != job_id:
            raise ContractError("job identity mismatch", code="storage_unavailable")
        return record

    def _save(self, record: dict) -> None:
        atomic_write(self._path(record["id"]) / "record.json", dumps(record))

    def _records(self) -> tuple[list[dict], list[str]]:
        if not self.directory.exists():
            return [], []
        records, corrupt_paths = [], []
        for entry in self.directory.iterdir():
            if entry.name.startswith("."):
                continue
            record_path = entry / "record.json"
            if not record_path.exists() and not record_path.is_symlink():
                continue  # Crash before the queued receipt: no accepted job exists.
            try:
                record = self._read(entry.name)
                if not all(
                    isinstance(record[key], str)
                    for key in (
                        "id",
                        "request_id",
                        "created_at",
                        "status",
                        "project_id",
                        "project_name",
                        "revision",
                        "operation",
                    )
                ):
                    raise ContractError("invalid job record")
                parse_uuid(record["request_id"])
                records.append(record)
            except (ContractError, OSError, TypeError, KeyError, AttributeError):
                corrupt_paths.append(str(record_path))
        return sorted(records, key=lambda item: (item["created_at"], item["id"])), corrupt_paths

    def _request_path(self, request_id: str) -> Path:
        return self.directory / ".requests" / parse_uuid(request_id)

    def _ensure_index(self) -> None:
        index = self.directory / ".requests"
        durable_mkdir(index)
        marker = index / ".indexed"
        if marker.exists():
            return
        for record in self._records()[0]:
            atomic_write(self._request_path(record["request_id"]), record["id"].encode("ascii"))
        atomic_write(marker, b"")

    def submit(
        self,
        project_id: str,
        expected_revision: str,
        request_id: str,
        operation: str = "assess_program",
    ) -> dict:
        project_id = parse_uuid(project_id)
        request_id = parse_uuid(request_id)
        validate_digest(expected_revision)
        if operation != "assess_program":
            raise ContractError("unsupported job operation")
        with self._metadata_lock():
            self._ensure_index()
            request_path = self._request_path(request_id)
            if request_path.is_symlink():
                raise ContractError("unsafe job request index", code="storage_unavailable")
            if request_path.exists():
                if request_path.stat().st_size > 36:
                    raise ContractError("invalid job request index", code="storage_unavailable")
                prior_id = parse_uuid(request_path.read_text("ascii"))
                try:
                    prior = self._read(prior_id)
                except ContractError as exc:
                    if exc.code != "job_not_found":
                        raise
                else:
                    if prior["request_id"] != request_id or (
                        prior["project_id"],
                        prior["revision"],
                        prior["operation"],
                    ) != (project_id, expected_revision, operation):
                        raise ContractError(
                            "request id reused with different payload", code="request_reused"
                        )
                    return dict(job=prior, replayed=True)
            else:
                prior_id = None
            current = self.projects.head(project_id)
            if current is None:
                raise ContractError("project not found", code="project_not_found")
            if current != expected_revision:
                raise ContractError(f"stale revision: current={current}", code="revision_conflict")
            program = read_program(self.root, project_id, expected_revision)
            job_id = prior_id or str(uuid4())
            path = self._path(job_id)
            durable_mkdir(path)
            atomic_write(request_path, job_id.encode("ascii"))
            record = dict(
                id=job_id,
                request_id=request_id,
                project_id=project_id,
                project_name=program["name"],
                revision=expected_revision,
                operation=operation,
                status="queued",
                stage="queued",
                cancel_requested=False,
                created_at=_now(),
                started_at=None,
                finished_at=None,
                error=None,
                artifacts=[],
                actor_id=None,
            )
            self._save(record)
            return dict(job=record, replayed=False)

    def inspect(self, job_id: str) -> dict:
        with self._metadata_lock():
            return self._read(job_id)

    def list(self, offset: int = 0, limit: int = 50) -> dict:
        if type(offset) is not int or type(limit) is not int or offset < 0 or not 1 <= limit <= 100:
            raise ContractError("invalid job page")
        with self._metadata_lock():
            records, corrupt_paths = self._records()
            return dict(
                items=records[offset : offset + limit],
                offset=offset,
                limit=limit,
                corrupt_paths=corrupt_paths,
            )

    def cancel(self, job_id: str) -> dict:
        with self._metadata_lock():
            record = self._read(job_id)
            if record["status"] == "queued":
                record.update(
                    status="cancelled", stage="cancelled", cancel_requested=True, finished_at=_now()
                )
                self._save(record)
            elif record["status"] == "running" and not record["cancel_requested"]:
                record["cancel_requested"] = True
                self._save(record)
            return record

    def run(self, job_id: str, *, limits: JobLimits | None = None) -> dict:
        if os.name != "posix" or (
            sys.platform != "linux" and not (limits and limits.trusted_local)
        ):
            raise ContractError(
                "local job execution requires Linux or explicit trusted-local POSIX policy"
            )
        path = self._path(job_id)
        with self._file_lock(path / ".run.lock", blocking=False) as acquired:
            if not acquired:
                return self.inspect(job_id)
            with self._metadata_lock():
                record = self._read(job_id)
                if record["status"] != "queued":
                    return record
                record.update(status="running", stage="preparing_input", started_at=_now())
                self._save(record)

            def cancellation() -> bool:
                return self.inspect(job_id)["cancel_requested"]

            def progress(stage: str) -> None:
                with self._metadata_lock():
                    current = self._read(job_id)
                    if current["status"] == "running":
                        current["stage"] = stage
                        self._save(current)

            try:
                program = read_program(self.root, record["project_id"], record["revision"])
                progress("assessing")
                result = run_assessment(
                    program,
                    revision=record["revision"],
                    work_dir=path / "run",
                    cancel=cancellation,
                    progress=progress,
                    limits=limits,
                )
                error = None
            except ContractError as exc:
                result = None
                error = dict(code=exc.code, detail=str(exc))
            except Exception as exc:
                result = None
                error = dict(
                    code="internal_error", detail=str(exc), traceback=traceback.format_exc()
                )
            with self._metadata_lock():
                current = self._read(job_id)
                if current["status"] != "running":
                    raise ContractError("job claim changed during execution")
                if error is not None:
                    current.update(status="failed", error=error, artifacts=[])
                elif current["cancel_requested"] and result.status == "succeeded":
                    current.update(status="cancelled", error=None, artifacts=[])
                else:
                    current.update(
                        status=result.status,
                        error=result.error,
                        artifacts=result.artifacts if result.status == "succeeded" else [],
                    )
                current.update(stage=current["status"], finished_at=_now())
                self._save(current)
                return current

    def recover(self) -> list[dict]:
        recovered = []
        with self._metadata_lock():
            for record in self._records()[0]:
                if record["status"] != "running":
                    continue
                with self._file_lock(
                    self._path(record["id"]) / ".run.lock", blocking=False
                ) as acquired:
                    if acquired:
                        record.update(
                            status="failed",
                            stage="failed",
                            finished_at=_now(),
                            error=dict(
                                code="worker_lost",
                                detail="worker claim ended without a terminal result",
                            ),
                            artifacts=[],
                        )
                        self._save(record)
                        recovered.append(record)
        return recovered

    def artifact(self, job_id: str, name: str) -> bytes:
        with self._metadata_lock():
            record = self._read(job_id)
            if record["status"] != "succeeded":
                raise ContractError("job has no published artifacts")
            descriptor = next(
                (entry for entry in record["artifacts"] if entry["name"] == name), None
            )
            if descriptor is None:
                raise ContractError("artifact not found")
            return read_artifact(self._path(job_id) / "run", descriptor)
