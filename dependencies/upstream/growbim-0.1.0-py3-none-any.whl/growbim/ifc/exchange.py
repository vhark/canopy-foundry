"""Strict placement-only authoring exchange; no foreign IFC may replace an accepted revision."""

from __future__ import annotations

import hashlib
import math
from copy import deepcopy

import ifcopenshell
import ifcopenshell.geom
import ifcopenshell.util.placement
import ifcopenshell.util.unit
import ifcopenshell.validate
import numpy as np
from opencea.contracts import ContractError, dumps, loads

from . import _native as native
from .reference_room import _profile, _rack, reference_access


def _parse(data):
    if not isinstance(data, bytes) or len(data) > 32 * 1024 * 1024:
        raise ContractError("edited IFC must be bounded bytes")
    try:
        model = ifcopenshell.file.from_string(data.decode("utf-8"))
    except (RuntimeError, ValueError, UnicodeError) as exc:
        raise ContractError("invalid edited IFC") from exc
    if model.schema != "IFC4":
        raise ContractError("edited IFC must be IFC4")
    diagnostics = ifcopenshell.validate.json_logger()
    ifcopenshell.validate.validate(model, diagnostics)
    if diagnostics.statements:
        raise ContractError(
            "edited IFC violates IFC4 schema: " + diagnostics.statements[0]["message"]
        )
    return model


def _semantic(value):
    if value is None or isinstance(value, (str, int, bool)):
        return value
    if isinstance(value, float):
        return round(value, 9)
    if isinstance(value, (tuple, list)):
        items = [_semantic(v) for v in value]
        if all(
            hasattr(v, "is_a")
            and (
                v.is_a("IfcRoot")
                or v.is_a("IfcProperty")
                or v.is_a("IfcPhysicalQuantity")
                or v.is_a("IfcUnit")
            )
            for v in value
        ):
            return tuple(sorted(items, key=repr))
        return tuple(items)
    if hasattr(value, "is_a"):
        if value.is_a("IfcRoot"):
            return ("root", value.GlobalId)
        return (
            value.is_a(),
            tuple(
                (name, _semantic(val))
                for name, val in value.get_info().items()
                if name not in ("id", "type", "OwnerHistory")
            ),
        )
    return str(value)


def _root_attributes(entity):
    return tuple(
        (name, _semantic(value))
        for name, value in entity.get_info().items()
        if name not in ("id", "type", "OwnerHistory", "ObjectPlacement", "Representation")
    )


def _mesh(entity):
    if not getattr(entity, "Representation", None):
        return None
    settings = ifcopenshell.geom.settings()
    try:
        shape = ifcopenshell.geom.create_shape(settings, entity)
    except (RuntimeError, ValueError) as exc:
        raise ContractError("unsupported edited IFC geometry") from exc
    # The native shape owns the geometry buffers; retain it throughout comparison.
    geometry = shape.geometry
    verts = geometry.verts
    if (
        not verts
        or not geometry.faces
        or len(verts) % 3
        or len(geometry.faces) % 3
        or not all(math.isfinite(v) for v in verts)
    ):
        raise ContractError("unsupported empty or non-finite IFC geometry")
    triangles = []
    for offset in range(0, len(geometry.faces), 3):
        triangles.append(
            tuple(
                sorted(
                    tuple(round(verts[3 * i + j], 6) for j in range(3))
                    for i in geometry.faces[offset : offset + 3]
                )
            )
        )
    return tuple(sorted(triangles))


def _representation_profile(model):
    """Reject hidden/unmapped IFC additions without depending on STEP entity numbering."""
    from collections import Counter

    inventory = Counter(entity.is_a() for entity in model if not entity.is_a("IfcOwnerHistory"))
    descriptions = []
    for product in model.by_type("IfcProduct"):
        if product.Representation is None:
            continue
        descriptions.append(
            (
                product.GlobalId,
                tuple(
                    sorted(
                        (
                            representation.RepresentationIdentifier,
                            representation.RepresentationType,
                            representation.ContextOfItems.ContextIdentifier,
                            representation.ContextOfItems.ContextType,
                            tuple(sorted(item.is_a() for item in representation.Items)),
                        )
                        for representation in product.Representation.Representations
                    )
                ),
            )
        )
    return inventory, tuple(sorted(descriptions))


def _position(model, entity, space):
    scale = ifcopenshell.util.unit.calculate_unit_scale(model)
    parent = ifcopenshell.util.placement.get_local_placement(space.ObjectPlacement)
    world = ifcopenshell.util.placement.get_local_placement(entity.ObjectPlacement)
    result = np.linalg.inv(parent) @ world
    result[:3, 3] *= scale
    return result


def _synchronized_candidate(base, edited_ifc, program):
    identity = deepcopy(loads(base["identity-map.json"]))
    identity["model_sha256"] = hashlib.sha256(edited_ifc).hexdigest()
    candidate = {
        "model.ifc": edited_ifc,
        "identity-map.json": dumps(identity),
        "catalog.json": base["catalog.json"],
    }
    native.validate_candidate(candidate, program)
    return candidate


def reconcile_placement_edit(artifacts, edited_ifc, program, element_id):
    """Return three source-linked artifacts only when rack placement alone changed."""
    native.validate_candidate(artifacts, program)
    original, identity, _ = native._read_candidate(artifacts)
    before_space = _profile(original)
    row, before_rack = _rack(original, identity)
    if row["id"] != element_id:
        raise ContractError("only the mapped rack can be reconciled")
    changed = _parse(edited_ifc)
    changed_space = _profile(changed)
    if not np.allclose(
        ifcopenshell.util.placement.get_local_placement(before_space.ObjectPlacement),
        ifcopenshell.util.placement.get_local_placement(changed_space.ObjectPlacement),
        rtol=0,
        atol=1e-6,
    ):
        raise ContractError("reference room world placement changed")
    if (
        abs(
            ifcopenshell.util.unit.calculate_unit_scale(original)
            - ifcopenshell.util.unit.calculate_unit_scale(changed)
        )
        > 1e-12
    ):
        raise ContractError("edited IFC length units changed")
    if _representation_profile(original) != _representation_profile(changed):
        raise ContractError("IFC representation inventory changed")
    left = {root.GlobalId: root for root in original.by_type("IfcRoot")}
    right = {root.GlobalId: root for root in changed.by_type("IfcRoot")}
    if (
        len(left) != len(original.by_type("IfcRoot"))
        or len(right) != len(changed.by_type("IfcRoot"))
        or left.keys() != right.keys()
    ):
        raise ContractError("IFC root identities changed")
    for guid, old in left.items():
        new = right[guid]
        if old.is_a() != new.is_a() or _root_attributes(old) != _root_attributes(new):
            raise ContractError("IFC semantics changed outside rack placement")
        if old.is_a("IfcProduct"):
            if _mesh(old) != _mesh(new):
                raise ContractError("IFC local geometry changed")
            if old.ObjectPlacement is None or new.ObjectPlacement is None:
                if bool(old.ObjectPlacement) != bool(new.ObjectPlacement):
                    raise ContractError("IFC placement changed")
            elif (
                not np.allclose(
                    _position(original, old, before_space),
                    _position(changed, new, changed_space),
                    rtol=0,
                    atol=1e-6,
                )
                and guid != row["ifc_global_id"]
            ):
                raise ContractError("unselected IFC placement changed")
    rack = right[row["ifc_global_id"]]
    prior = _position(original, before_rack, before_space)
    after = _position(changed, rack, changed_space)
    if abs(after[2, 3] - prior[2, 3]) > 1e-6 or abs(after[2, 3]) > 1e-6:
        raise ContractError("rack elevation change unsupported")
    if not np.allclose(after[3, :], (0, 0, 0, 1), rtol=0, atol=1e-6):
        raise ContractError("invalid rack transform")
    angle = math.degrees(math.atan2(after[1, 0], after[0, 0])) % 360
    if min(abs(angle - allowed) for allowed in (0, 90, 360)) > 1e-5 or not np.allclose(
        after[:3, :3],
        [
            [math.cos(math.radians(angle)), -math.sin(math.radians(angle)), 0],
            [math.sin(math.radians(angle)), math.cos(math.radians(angle)), 0],
            [0, 0, 1],
        ],
        rtol=0,
        atol=1e-6,
    ):
        raise ContractError("rack orientation must be rigid 0 or 90 degrees")
    candidate = _synchronized_candidate(artifacts, edited_ifc, program)
    access = reference_access(candidate)
    if access["findings"]:
        raise ContractError("; ".join(access["findings"]))
    return candidate
