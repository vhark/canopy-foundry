"""Synthetic IFC4 fixture and candidate authoring; loaded only on explicit native calls."""

from __future__ import annotations

import copy
import hashlib
import json
import math
from importlib.resources import files
from uuid import UUID, uuid4, uuid5

from opencea.contracts import ContractError, dumps, loads
from opencea.identity import validate_identity_map

try:
    import ifcopenshell
    import ifcopenshell.guid
    import ifcopenshell.util.unit
    import ifcopenshell.validate
except ImportError as exc:
    raise ContractError(
        "the optional IfcOpenShell 0.8.5 extra is unavailable", code="capability_unavailable"
    ) from exc

_NS = UUID("adb316dd-f9b4-4b42-b8b6-09a4f12e77d1")
_FILES = ("model.ifc", "identity-map.json", "catalog.json")
_SCALES = {"m": 1.0, "mm": 1000.0, "ft": 1 / 0.3048}


def _id(project, kind, name):
    return str(uuid5(_NS, f"{project}/{kind}/{name}"))


def _guid(project, kind, name):
    return ifcopenshell.guid.compress(uuid5(_NS, f"ifc/{project}/{kind}/{name}").hex)


def _root(model, cls, project, kind, key, **kwargs):
    return model.create_entity(cls, GlobalId=_guid(project, kind, key), **kwargs)


def _point(model, xyz):
    return model.createIfcCartesianPoint(tuple(float(v) for v in xyz))


def _direction(model, xyz):
    return model.createIfcDirection(tuple(float(v) for v in xyz))


def _placement(model, parent, xyz, rotation=0):
    angle = math.radians(rotation)
    axis = model.createIfcAxis2Placement3D(
        _point(model, xyz),
        _direction(model, (0, 0, 1)),
        _direction(model, (math.cos(angle), math.sin(angle), 0)),
    )
    return model.createIfcLocalPlacement(parent, axis)


def _rel(model, cls, project, kind, key, **kwargs):
    return _root(model, cls, project, kind, f"rel/{key}", **kwargs)


def _property(model, name, value, measure="IfcLengthMeasure"):
    return model.createIfcPropertySingleValue(
        Name=name, NominalValue=model.create_entity(measure, float(value))
    )


def _pset(model, project, kind, key, element, name, values):
    props = [
        _property(model, label, value, measure)
        if isinstance(value, (int, float))
        else model.createIfcPropertySingleValue(
            Name=label, NominalValue=model.create_entity(measure, value)
        )
        for label, (value, measure) in values.items()
    ]
    pset = _root(
        model, "IfcPropertySet", project, kind, f"pset/{key}/{name}", Name=name, HasProperties=props
    )
    if element.is_a("IfcTypeObject"):
        element.HasPropertySets = list(element.HasPropertySets or ()) + [pset]
    else:
        _rel(
            model,
            "IfcRelDefinesByProperties",
            project,
            kind,
            f"properties/{key}/{name}",
            RelatedObjects=[element],
            RelatingPropertyDefinition=pset,
        )
    return pset


def _box(model, context, length, width, height):
    points = [
        _point(model, xy) for xy in ((0, 0), (length, 0), (length, width), (0, width), (0, 0))
    ]
    profile = model.createIfcArbitraryClosedProfileDef(
        "AREA", None, model.createIfcPolyline(points)
    )
    solid = model.createIfcExtrudedAreaSolid(
        profile,
        model.createIfcAxis2Placement3D(
            _point(model, (0, 0, 0)), _direction(model, (0, 0, 1)), _direction(model, (1, 0, 0))
        ),
        _direction(model, (0, 0, 1)),
        height,
    )
    shape = model.createIfcShapeRepresentation(context, "Body", "SweptSolid", [solid])
    return model.createIfcProductDefinitionShape(None, None, [shape])


def _quantities(model, project, kind, key, element, length, width, height, unit):
    quantities = [
        model.createIfcQuantityLength(Name=name, LengthValue=dimension, Unit=unit)
        for name, dimension in (("Length", length), ("Width", width), ("Height", height))
    ]
    values = _root(
        model,
        "IfcElementQuantity",
        project,
        kind,
        f"quantity/{key}",
        Name="OpenCEA_Dimensions",
        Quantities=quantities,
    )
    _rel(
        model,
        "IfcRelDefinesByProperties",
        project,
        kind,
        f"quantities/{key}",
        RelatedObjects=[element],
        RelatingPropertyDefinition=values,
    )
    geometry = _pset(
        model,
        project,
        kind,
        key,
        element,
        "OpenCEA_Geometry",
        {
            "Length": (length, "IfcLengthMeasure"),
            "Width": (width, "IfcLengthMeasure"),
            "Height": (height, "IfcLengthMeasure"),
        },
    )
    for prop in geometry.HasProperties:
        prop.Unit = unit


def _recipe(kind):
    if kind not in ("indoor", "greenhouse"):
        raise ContractError("unknown synthetic fixture kind")
    return json.loads(
        files("growbim.ifc")
        .joinpath("resources", "fixtures", kind, "recipe.json")
        .read_text(encoding="utf-8")
    )


def fixture_expectations(kind):
    """Independent SI reference values from the original fixture recipe."""
    recipe = _recipe(kind)
    return {
        "spaces": len(recipe["spaces"]),
        "doors": 1,
        "bench_ifc_class": "IfcElementAssembly",
        "bench_length_m": recipe["bench_length_m"],
        "bench_width_m": recipe["bench_width_m"],
        "bench_height_m": recipe["bench_height_m"],
        "width_m": recipe["width_m"],
        "height_m": recipe["height_m"],
        "bench_world_origin_m": recipe["bench_world_origin_m"],
        "bench_world_x_axis": [math.cos(math.radians(45)), math.sin(math.radians(45)), 0.0],
        "bench_world_y_axis": [-math.sin(math.radians(45)), math.cos(math.radians(45)), 0.0],
        "solid_profile_origin": "corner",
        "systems": recipe["systems"],
        "service_coverage": recipe["service_coverage"],
    }


def _catalog(kind, project, source):
    entries = json.loads(
        files("growbim.ifc")
        .joinpath("resources", "catalog", f"{kind}.json")
        .read_text(encoding="utf-8")
    )
    items = []
    for row in entries:
        props = {
            name: {
                "type": "quantity",
                "value": value,
                "unit": "m" if name.endswith("_m") else "W" if name.endswith("_w") else "s",
                "evidence_kind": "declared",
                "source_ids": [source],
            }
            for name, value in row["properties"].items()
        }
        items.append(
            {
                "schema_version": "0.1",
                "id": _id(project, kind, f"catalog/{row['key']}"),
                "name": row["name"],
                "manufacturer": "OpenCEA original synthetic example",
                "model": row["model"],
                "properties": props,
                "evidence_status": "declared",
                "source_ids": [source],
                "extensions": {},
            }
        )
    return entries, {"schema_version": "0.2", "items": items}


def _serialize(model, identity, catalog):
    model.header.file_name.time_stamp = "2026-09-28T00:00:00"
    data = model.to_string().encode("utf-8")
    identity["model_sha256"] = hashlib.sha256(data).hexdigest()
    return {"model.ifc": data, "identity-map.json": dumps(identity), "catalog.json": dumps(catalog)}


def build_fixture(kind, project_id, source_id, *, length_unit="m"):
    """Build three standalone candidate bytes, never install or accept them."""
    from opencea.contracts import parse_uuid

    project_id, source_id = parse_uuid(project_id), parse_uuid(source_id)
    recipe = _recipe(kind)
    if length_unit not in _SCALES:
        raise ContractError("length unit must be m, mm, or ft")
    scale = _SCALES[length_unit]
    model = ifcopenshell.file(schema="IFC4")
    project = _root(model, "IfcProject", project_id, kind, "project", Name=recipe["name"])
    length = (
        model.createIfcSIUnit(
            UnitType="LENGTHUNIT", Name="METRE", Prefix="MILLI" if length_unit == "mm" else None
        )
        if length_unit != "ft"
        else _foot(model)
    )
    units = [
        length,
        model.createIfcSIUnit(UnitType="AREAUNIT", Name="SQUARE_METRE"),
        model.createIfcSIUnit(UnitType="TIMEUNIT", Name="SECOND"),
        model.createIfcSIUnit(UnitType="POWERUNIT", Name="WATT"),
    ]
    project.UnitsInContext = model.createIfcUnitAssignment(units)
    context = model.createIfcGeometricRepresentationContext(
        None,
        "Model",
        3,
        1e-5,
        model.createIfcAxis2Placement3D(
            _point(model, (0, 0, 0)), _direction(model, (0, 0, 1)), _direction(model, (1, 0, 0))
        ),
        None,
    )
    project.RepresentationContexts = [context]
    site = _root(
        model,
        "IfcSite",
        project_id,
        kind,
        "site",
        Name="Synthetic site",
        CompositionType="ELEMENT",
        ObjectPlacement=_placement(model, None, (0, 0, 0)),
    )
    building = _root(
        model,
        "IfcBuilding",
        project_id,
        kind,
        "building",
        Name="Cultivation building",
        CompositionType="ELEMENT",
        ObjectPlacement=_placement(model, site.ObjectPlacement, (0, 0, 0)),
    )
    storey = _root(
        model,
        "IfcBuildingStorey",
        project_id,
        kind,
        "storey",
        Name="Ground storey",
        CompositionType="ELEMENT",
        Elevation=0.0,
        ObjectPlacement=_placement(model, building.ObjectPlacement, (scale, scale, 0)),
    )
    for parent, child, key in (
        (project, site, "site"),
        (site, building, "building"),
        (building, storey, "storey"),
    ):
        _rel(
            model,
            "IfcRelAggregates",
            project_id,
            kind,
            key,
            RelatingObject=parent,
            RelatedObjects=[child],
        )
    spaces = []
    for index, name in enumerate(recipe["spaces"]):
        position = (scale, 0, 0) if index == 0 else (0, recipe["depth_m"] * scale * 0.75, 0)
        space = _root(
            model,
            "IfcSpace",
            project_id,
            kind,
            f"space/{index}",
            Name=name,
            CompositionType="ELEMENT",
            ObjectPlacement=_placement(
                model, storey.ObjectPlacement, position, 30 if index == 0 else 0
            ),
        )
        _rel(
            model,
            "IfcRelAggregates",
            project_id,
            kind,
            f"space/{index}",
            RelatingObject=storey,
            RelatedObjects=[space],
        )
        spaces.append(space)
    entries, catalog = _catalog(kind, project_id, source_id)
    types = {}
    for row, item in zip(entries, catalog["items"], strict=True):
        kwargs = {"PredefinedType": "NOTDEFINED"}
        if row["ifc_type"] == "IfcDoorType":
            kwargs["OperationType"] = "NOTDEFINED"
        typ = _root(
            model,
            row["ifc_type"],
            project_id,
            kind,
            f"type/{row['key']}",
            Name=row["name"],
            **kwargs,
        )
        _pset(
            model,
            project_id,
            kind,
            f"type/{row['key']}",
            typ,
            "OpenCEA_Product",
            {"CatalogId": (item["id"], "IfcIdentifier")},
        )
        declared = {}
        for name, value in row["properties"].items():
            measure = (
                "IfcLengthMeasure"
                if name.endswith("_m")
                else "IfcPowerMeasure"
                if name.endswith("_w")
                else "IfcTimeMeasure"
            )
            declared[name] = (value * scale if name.endswith("_m") else value, measure)
        properties = _pset(
            model, project_id, kind, f"type/{row['key']}", typ, "OpenCEA_Declared", declared
        )
        for prop in properties.HasProperties:
            unit_type = (
                "LENGTHUNIT"
                if prop.Name.endswith("_m")
                else "POWERUNIT"
                if prop.Name.endswith("_w")
                else "TIMEUNIT"
            )
            prop.Unit = next(unit for unit in units if unit.UnitType == unit_type)
        types[row["key"]] = typ
    identity = {
        "schema_version": "0.2",
        "id": _id(project_id, kind, "identity"),
        "project_id": project_id,
        "name": recipe["name"],
        "model_sha256": "",
        "source_ids": [source_id],
        "subjects": [],
        "roles": [],
        "assets": [],
        "elements": [],
        "channels": [],
        "bindings": [],
        "deployments": [],
        "occupancies": [],
        "transitions": [],
        "unresolved_bindings": [],
    }
    light_system = []
    sensor_system = []

    def element(cls, key, name, space, xyz, angle, dimensions, product=None, role=None):
        entity = _root(
            model,
            cls,
            project_id,
            kind,
            key,
            Name=name,
            ObjectPlacement=_placement(model, space.ObjectPlacement, xyz, angle),
            Representation=_box(model, context, *(v * scale for v in dimensions)),
        )
        row = {
            "id": _id(project_id, kind, f"element/{key}"),
            "ifc_global_id": entity.GlobalId,
            "ifc_class": cls,
            "product_id": catalog["items"][[entry["key"] for entry in entries].index(product)]["id"]
            if product
            else None,
            "role_id": role,
            "asset_id": None,
            "state": "active",
            "evidence_kind": "proposed",
        }
        identity["elements"].append(row)
        values = {"ElementId": (row["id"], "IfcIdentifier")}
        if role:
            values["RoleId"] = (role, "IfcIdentifier")
        _pset(model, project_id, kind, key, entity, "OpenCEA_Identity", values)
        _quantities(model, project_id, kind, key, entity, *(v * scale for v in dimensions), length)
        _rel(
            model,
            "IfcRelContainedInSpatialStructure",
            project_id,
            kind,
            f"contain/{key}",
            RelatingStructure=space,
            RelatedElements=[entity],
        )
        if product:
            _rel(
                model,
                "IfcRelDefinesByType",
                project_id,
                kind,
                f"type/{key}",
                RelatedObjects=[entity],
                RelatingType=types[product],
            )
        return entity

    role = _id(project_id, kind, "role/cultivation")
    identity["roles"].append(
        {"id": role, "name": "Cultivation occupancy slot", "source_ids": [source_id]}
    )
    # Three composed levels: translated storey, translated/rotated space, and rotated bench.
    world_x, world_y, _ = recipe["bench_world_origin_m"]
    dx, dy = world_x - 2, world_y - 1
    x_local = (dx * math.cos(math.pi / 6) + dy * math.sin(math.pi / 6)) * scale
    y_local = (-dx * math.sin(math.pi / 6) + dy * math.cos(math.pi / 6)) * scale
    bench = element(
        "IfcElementAssembly",
        "bench/a",
        "Bench assembly A",
        spaces[0],
        (x_local, y_local, 0),
        15,
        (recipe["bench_length_m"], recipe["bench_width_m"], recipe["bench_height_m"]),
        "bench",
        role,
    )
    tray = _root(
        model,
        "IfcMember",
        project_id,
        kind,
        "bench/a/tray",
        Name="Cultivation tray",
        ObjectPlacement=_placement(
            model, bench.ObjectPlacement, (0, 0, recipe["bench_height_m"] * scale * 0.85)
        ),
        Representation=_box(
            model,
            context,
            recipe["bench_length_m"] * scale,
            recipe["bench_width_m"] * scale,
            recipe["bench_height_m"] * scale * 0.15,
        ),
    )
    _rel(
        model,
        "IfcRelAggregates",
        project_id,
        kind,
        "bench/a/tray",
        RelatingObject=bench,
        RelatedObjects=[tray],
    )
    light = element(
        "IfcLightFixture",
        "light/a",
        "Synthetic light A",
        spaces[0],
        (3 * scale, scale, 2.7 * scale),
        0,
        (0.8, 0.3, 0.15),
        "light",
    )
    sensor = element(
        "IfcSensor",
        "sensor/a",
        "Synthetic sensor A",
        spaces[0],
        (2 * scale, 2 * scale, 1.8 * scale),
        0,
        (0.12, 0.12, 0.2),
        "sensor",
    )
    light_system.append(light)
    sensor_system.append(sensor)
    wall = element(
        "IfcWall",
        "wall/entry",
        "Entry wall",
        spaces[1],
        (0, 0, 0),
        0,
        (recipe["width_m"], 0.2, recipe["height_m"]),
    )
    if kind == "greenhouse":
        element(
            "IfcRoof",
            "roof",
            "Glazed roof",
            spaces[0],
            (0, 0, recipe["height_m"] * scale),
            0,
            (recipe["width_m"], recipe["depth_m"], 0.12),
        )
    opening = _root(
        model,
        "IfcOpeningElement",
        project_id,
        kind,
        "opening/entry",
        Name="Entrance opening",
        ObjectPlacement=_placement(model, wall.ObjectPlacement, (1.0 * scale, 0, 0)),
        Representation=_box(
            model,
            context,
            recipe["door_width_m"] * scale,
            0.2 * scale,
            recipe["door_height_m"] * scale,
        ),
    )
    door = element(
        "IfcDoor",
        "door/entry",
        "Entrance door",
        spaces[1],
        (1.0 * scale, 0, 0),
        0,
        (recipe["door_width_m"], 0.06, recipe["door_height_m"]),
        "door",
    )
    door.OverallWidth = recipe["door_width_m"] * scale
    door.OverallHeight = recipe["door_height_m"] * scale
    _rel(
        model,
        "IfcRelVoidsElement",
        project_id,
        kind,
        "void/entry",
        RelatingBuildingElement=wall,
        RelatedOpeningElement=opening,
    )
    _rel(
        model,
        "IfcRelFillsElement",
        project_id,
        kind,
        "fill/entry",
        RelatingOpeningElement=opening,
        RelatedBuildingElement=door,
    )
    for index, (name, members) in enumerate(
        zip(recipe["systems"], (light_system, sensor_system), strict=True)
    ):
        system = _root(model, "IfcSystem", project_id, kind, f"system/{index}", Name=name)
        _rel(
            model,
            "IfcRelAssignsToGroup",
            project_id,
            kind,
            f"system-members/{index}",
            RelatingGroup=system,
            RelatedObjects=members,
        )
        _rel(
            model,
            "IfcRelServicesBuildings",
            project_id,
            kind,
            f"coverage/{index}",
            RelatingSystem=system,
            RelatedBuildings=[spaces[0]],
        )
    identity["channels"].append(
        {
            "id": _id(project_id, kind, "channel/air-temperature"),
            "quantity": "air_temperature",
            "unit": "degC",
            "source_ids": [source_id],
        }
    )
    return _serialize(model, identity, catalog)


def _foot(model):
    si = model.createIfcSIUnit(UnitType="LENGTHUNIT", Name="METRE")
    dims = model.createIfcDimensionalExponents(1, 0, 0, 0, 0, 0, 0)
    factor = model.createIfcMeasureWithUnit(model.createIfcReal(0.3048), si)
    return model.createIfcConversionBasedUnit(dims, "LENGTHUNIT", "foot", factor)


def _property_value(entity, pset_name, property_name):
    if entity.is_a("IfcTypeObject"):
        sets = entity.HasPropertySets or ()
    else:
        sets = (
            rel.RelatingPropertyDefinition
            for rel in entity.IsDefinedBy
            if rel.is_a("IfcRelDefinesByProperties")
        )
    for pset in sets:
        if pset.is_a("IfcPropertySet") and pset.Name == pset_name:
            for prop in pset.HasProperties:
                if prop.Name == property_name:
                    return prop.NominalValue.wrappedValue
    return None


def _read_candidate(artifacts):
    if not isinstance(artifacts, dict) or set(artifacts) != set(_FILES):
        raise ContractError("candidate must have exactly the three design artifacts")
    if any(not isinstance(artifacts[key], bytes) for key in _FILES):
        raise ContractError("candidate artifacts must be bytes")
    identity = loads(artifacts["identity-map.json"])
    catalog = loads(artifacts["catalog.json"])
    if hashlib.sha256(artifacts["model.ifc"]).hexdigest() != identity.get("model_sha256"):
        raise ContractError("IFC model digest differs from identity map")
    try:
        model = ifcopenshell.file.from_string(artifacts["model.ifc"].decode("utf-8"))
    except (RuntimeError, ValueError, UnicodeError) as exc:
        raise ContractError("invalid IFC model bytes") from exc
    if model.schema != "IFC4":
        raise ContractError("candidate model must be IFC4")
    diagnostics = ifcopenshell.validate.json_logger()
    ifcopenshell.validate.validate(model, diagnostics)
    if diagnostics.statements:
        raise ContractError(
            "candidate violates IFC4 schema: " + diagnostics.statements[0]["message"]
        )
    return model, identity, catalog


def validate_candidate(artifacts, program):
    """Validate byte integrity, pure semantic identities and actual native IFC relations."""
    model, identity, catalog = _read_candidate(artifacts)
    validate_identity_map(identity, catalog, program)
    known_types = {item["id"] for item in catalog["items"]}
    actual_types = {}
    for rel in model.by_type("IfcRelDefinesByType"):
        product_id = _property_value(rel.RelatingType, "OpenCEA_Product", "CatalogId")
        for entity in rel.RelatedObjects:
            if entity.GlobalId in actual_types:
                raise ContractError("IFC occurrence has multiple catalog type relationships")
            actual_types[entity.GlobalId] = (product_id, rel.RelatingType.is_a())
    roots = model.by_type("IfcRoot")
    global_ids = {entity.GlobalId for entity in roots}
    if len(global_ids) != len(roots):
        raise ContractError("IFC model contains duplicate GlobalIds")
    for item in identity["elements"]:
        guid = item["ifc_global_id"]
        if item["state"] == "retired":
            if guid in global_ids:
                raise ContractError("retired element remains in IFC model")
            continue
        try:
            entity = model.by_guid(guid)
        except RuntimeError as exc:
            raise ContractError("active element missing from IFC model") from exc
        if entity.is_a() != item["ifc_class"]:
            raise ContractError("mapped IFC class differs from actual entity")
        if _property_value(entity, "OpenCEA_Identity", "ElementId") != item["id"]:
            raise ContractError("IFC occurrence does not carry its mapped element ID")
        if _property_value(entity, "OpenCEA_Identity", "RoleId") != item["role_id"]:
            raise ContractError("IFC role differs from identity map")
        if _property_value(entity, "OpenCEA_Identity", "AssetId") != item["asset_id"]:
            raise ContractError("IFC asset differs from identity map")
        if item["product_id"] is not None and item["product_id"] not in known_types:
            raise ContractError("unknown catalog product for IFC occurrence")
        actual = actual_types.get(guid)
        if (actual is None and item["product_id"] is not None) or (
            actual is not None and actual[0] != item["product_id"]
        ):
            raise ContractError("catalog type relationship missing or inconsistent")
        expected_type = {
            "IfcElementAssembly": "IfcElementAssemblyType",
            "IfcFurniture": "IfcFurnitureType",
            "IfcLightFixture": "IfcLightFixtureType",
            "IfcSensor": "IfcSensorType",
            "IfcDoor": "IfcDoorType",
        }.get(item["ifc_class"])
        if actual is not None and (expected_type is None or actual[1] != expected_type):
            raise ContractError("catalog type class differs from IFC occurrence")


def _candidate(artifacts):
    model, identity, catalog = _read_candidate(artifacts)
    return model, copy.deepcopy(identity), catalog


def _element(model, identity, element_id):
    row = next((record for record in identity["elements"] if record["id"] == element_id), None)
    if row is None or row["state"] != "active":
        raise ContractError("element is not active in candidate")
    try:
        return row, model.by_guid(row["ifc_global_id"])
    except RuntimeError as exc:
        raise ContractError("element is missing in IFC candidate") from exc


def _geometry(entity):
    representations = entity.Representation.Representations
    return next(
        item
        for representation in representations
        for item in representation.Items
        if item.is_a("IfcExtrudedAreaSolid")
    )


def _dimensions(entity):
    solid = _geometry(entity)
    points = solid.SweptArea.OuterCurve.Points
    return (points[1].Coordinates[0], points[2].Coordinates[1], solid.Depth)


def _update_measures(entity, dimensions):
    for rel in entity.IsDefinedBy:
        if not rel.is_a("IfcRelDefinesByProperties"):
            continue
        definition = rel.RelatingPropertyDefinition
        if definition.is_a("IfcElementQuantity") and definition.Name == "OpenCEA_Dimensions":
            for quantity in definition.Quantities:
                if quantity.Name in ("Length", "Width", "Height"):
                    quantity.LengthValue = dimensions[
                        ("Length", "Width", "Height").index(quantity.Name)
                    ]
        if definition.is_a("IfcPropertySet") and definition.Name == "OpenCEA_Geometry":
            for prop in definition.HasProperties:
                if prop.Name in ("Length", "Width", "Height"):
                    prop.NominalValue.wrappedValue = dimensions[
                        ("Length", "Width", "Height").index(prop.Name)
                    ]


def _assembly_children(model, entity):
    return [
        child
        for rel in model.by_type("IfcRelAggregates")
        if rel.RelatingObject == entity
        for child in rel.RelatedObjects
    ]


def _set_solid_length(entity, length):
    for index in (1, 2):
        point = _geometry(entity).SweptArea.OuterCurve.Points[index]
        point.Coordinates = (length, point.Coordinates[1])


def resize_element(artifacts, element_id, *, length_m):
    """Resize an assembly along its local X axis in SI metres; preserve both identities."""
    if not math.isfinite(length_m) or length_m <= 0:
        raise ContractError("length must be finite and positive")
    model, identity, catalog = _candidate(artifacts)
    _, entity = _element(model, identity, element_id)
    if entity.is_a() != "IfcElementAssembly":
        raise ContractError("only bench assemblies support the length resize operation")
    dimensions = list(_dimensions(entity))
    dimensions[0] = length_m / ifcopenshell.util.unit.calculate_unit_scale(model)
    _set_solid_length(entity, dimensions[0])
    for child in _assembly_children(model, entity):
        _set_solid_length(child, dimensions[0])
    _update_measures(entity, dimensions)
    return _serialize(model, identity, catalog)


def move_element(artifacts, element_id, *, x_m, y_m, z_m, rotation_degrees=0):
    """Set local placement relative to the containing spatial element, in SI metres."""
    if any(not math.isfinite(value) for value in (x_m, y_m, z_m, rotation_degrees)):
        raise ContractError("placement coordinates must be finite")
    model, identity, catalog = _candidate(artifacts)
    _, entity = _element(model, identity, element_id)
    scale = 1 / ifcopenshell.util.unit.calculate_unit_scale(model)
    placement = entity.ObjectPlacement
    placement.RelativePlacement.Location.Coordinates = (x_m * scale, y_m * scale, z_m * scale)
    angle = math.radians(rotation_degrees)
    placement.RelativePlacement.RefDirection.DirectionRatios = (
        math.cos(angle),
        math.sin(angle),
        0.0,
    )
    return _serialize(model, identity, catalog)


def rename_element(artifacts, element_id, name):
    """Rename the occurrence without changing its stable element or IFC identity."""
    if not isinstance(name, str) or not name.strip():
        raise ContractError("element name must not be empty")
    model, identity, catalog = _candidate(artifacts)
    _, entity = _element(model, identity, element_id)
    entity.Name = name
    return _serialize(model, identity, catalog)


def _clone(model, identity, entity, row, *, name, role_id=None):
    uid = str(uuid4())
    guid = ifcopenshell.guid.compress(uuid4().hex)
    dimensions = _dimensions(entity)
    context = model.by_type("IfcGeometricRepresentationContext")[0]
    location = entity.ObjectPlacement.RelativePlacement.Location.Coordinates
    angle = entity.ObjectPlacement.RelativePlacement.RefDirection.DirectionRatios
    parent = entity.ObjectPlacement.PlacementRelTo
    clone = model.create_entity(
        entity.is_a(),
        GlobalId=guid,
        Name=name,
        ObjectPlacement=_placement(
            model, parent, location, math.degrees(math.atan2(angle[1], angle[0]))
        ),
        Representation=_box(model, context, *dimensions),
    )
    if entity.is_a("IfcDoor"):
        clone.OverallWidth, clone.OverallHeight = entity.OverallWidth, entity.OverallHeight
    new_row = {
        **row,
        "id": uid,
        "ifc_global_id": guid,
        "role_id": role_id,
        "asset_id": None,
        "state": "active",
        "evidence_kind": "proposed",
    }
    identity["elements"].append(new_row)
    project, kind = identity["project_id"], identity["name"]
    _pset(
        model,
        project,
        kind,
        uid,
        clone,
        "OpenCEA_Identity",
        {
            "ElementId": (uid, "IfcIdentifier"),
            **({"RoleId": (role_id, "IfcIdentifier")} if role_id else {}),
        },
    )
    unit = next(
        unit
        for unit in model.by_type("IfcProject")[0].UnitsInContext.Units
        if unit.UnitType == "LENGTHUNIT"
    )
    _quantities(model, project, kind, uid, clone, *dimensions, unit)
    for rel in model.by_type("IfcRelContainedInSpatialStructure"):
        if entity in rel.RelatedElements:
            _rel(
                model,
                "IfcRelContainedInSpatialStructure",
                project,
                kind,
                f"clone-contain/{uid}",
                RelatingStructure=rel.RelatingStructure,
                RelatedElements=[clone],
            )
    for rel in model.by_type("IfcRelDefinesByType"):
        if entity in rel.RelatedObjects:
            rel.RelatedObjects = (*rel.RelatedObjects, clone)
    for rel in model.by_type("IfcRelAssignsToGroup"):
        if entity in rel.RelatedObjects and rel.RelatingGroup.is_a("IfcSystem"):
            _rel(
                model,
                "IfcRelAssignsToGroup",
                project,
                kind,
                f"clone-system/{uid}/{rel.RelatingGroup.GlobalId}",
                RelatingGroup=rel.RelatingGroup,
                RelatedObjects=[clone],
            )
    for child in _assembly_children(model, entity):
        child_location = child.ObjectPlacement.RelativePlacement.Location.Coordinates
        child_dimensions = _dimensions(child)
        component = model.create_entity(
            child.is_a(),
            GlobalId=ifcopenshell.guid.compress(uuid4().hex),
            Name=child.Name,
            ObjectPlacement=_placement(model, clone.ObjectPlacement, child_location),
            Representation=_box(model, context, *child_dimensions),
        )
        _rel(
            model,
            "IfcRelAggregates",
            project,
            kind,
            f"clone-component/{uid}/{component.GlobalId}",
            RelatingObject=clone,
            RelatedObjects=[component],
        )
    return new_row, clone


def copy_element(artifacts, element_id, *, at, name=None):
    """Copy active occurrence with fresh identities, not assets or temporal relationships."""
    model, identity, catalog = _candidate(artifacts)
    _utc_time(at)
    row, entity = _element(model, identity, element_id)
    if entity.is_a() not in ("IfcElementAssembly", "IfcLightFixture", "IfcSensor"):
        raise ContractError("copy supports bench, light and sensor occurrences")
    new_role = None
    if row["role_id"]:
        role = next(record for record in identity["roles"] if record["id"] == row["role_id"])
        new_role = str(uuid4())
        identity["roles"].append({**role, "id": new_role})
    new_row, _ = _clone(model, identity, entity, row, name=name or entity.Name, role_id=new_role)
    identity["transitions"].append(
        {"kind": "copy", "from_element_id": element_id, "to_element_id": new_row["id"], "at": at}
    )
    return _serialize(model, identity, catalog)


def _identity_property(model, entity, name, value):
    for rel in entity.IsDefinedBy:
        if (
            rel.is_a("IfcRelDefinesByProperties")
            and rel.RelatingPropertyDefinition.is_a("IfcPropertySet")
            and rel.RelatingPropertyDefinition.Name == "OpenCEA_Identity"
        ):
            pset = rel.RelatingPropertyDefinition
            pset.HasProperties = list(pset.HasProperties) + [
                model.createIfcPropertySingleValue(
                    Name=name, NominalValue=model.createIfcIdentifier(value)
                )
            ]
            return
    raise ContractError("element lacks OpenCEA identity property set")


def install_element(artifacts, element_id, *, source_id):
    """Explicitly report one installed physical unit backed by the candidate source."""
    model, identity, catalog = _candidate(artifacts)
    row, entity = _element(model, identity, element_id)
    if source_id not in identity["source_ids"]:
        raise ContractError("installation source must be declared in candidate")
    if row["asset_id"] is not None or row["product_id"] is None:
        raise ContractError("installation requires unassigned catalog-linked element")
    asset_id = str(uuid4())
    identity["assets"].append(
        {"id": asset_id, "product_id": row["product_id"], "source_ids": [source_id]}
    )
    row["asset_id"] = asset_id
    row["evidence_kind"] = "reported"
    _identity_property(model, entity, "AssetId", asset_id)
    return _serialize(model, identity, catalog)


def _utc_time(at):
    from datetime import datetime

    try:
        timestamp = datetime.fromisoformat(at.replace("Z", "+00:00"))
    except (ValueError, TypeError, AttributeError) as exc:
        raise ContractError("transition time must be UTC RFC3339") from exc
    if timestamp.tzinfo is None or timestamp.utcoffset().total_seconds() != 0:
        raise ContractError("transition time must be UTC")
    return timestamp


def _close_intervals(identity, element_id, at):
    from datetime import datetime

    timestamp = _utc_time(at)
    for collection in ("deployments", "occupancies"):
        for record in identity[collection]:
            if record["element_id"] != element_id:
                continue
            start = datetime.fromisoformat(record["starts_at"].replace("Z", "+00:00"))
            if start >= timestamp:
                raise ContractError("transition cannot precede a deployment or occupancy")
            end = record["ends_at"]
            if end is None or datetime.fromisoformat(end.replace("Z", "+00:00")) > timestamp:
                record["ends_at"] = at
    bindings = [item for item in identity["bindings"] if item["element_id"] == element_id]
    identity["bindings"] = [
        item for item in identity["bindings"] if item["element_id"] != element_id
    ]
    identity["unresolved_bindings"].extend(
        {**item, "reason": "physical element retired; human resolution required"}
        for item in bindings
    )


def _remove(model, entity):
    import ifcopenshell.api.root

    for child in _assembly_children(model, entity):
        ifcopenshell.api.root.remove_product(model, product=child)
    ifcopenshell.api.root.remove_product(model, product=entity)


def replace_element(artifacts, element_id, *, source_id, at, retain_role=False):
    """Install a new unit in place of an explicitly installed unit; never rebind readings."""
    model, identity, catalog = _candidate(artifacts)
    row, entity = _element(model, identity, element_id)
    if row["asset_id"] is None or source_id not in identity["source_ids"]:
        raise ContractError("replacement needs installed unit and declared source")
    replacement, new_entity = _clone(
        model,
        identity,
        entity,
        row,
        name=entity.Name,
        role_id=row["role_id"] if retain_role else None,
    )
    replacement["asset_id"] = str(uuid4())
    replacement["evidence_kind"] = "reported"
    identity["assets"].append(
        {"id": replacement["asset_id"], "product_id": row["product_id"], "source_ids": [source_id]}
    )
    _identity_property(model, new_entity, "AssetId", replacement["asset_id"])
    _close_intervals(identity, element_id, at)
    row["state"] = "retired"
    identity["transitions"].append(
        {
            "kind": "replace",
            "from_element_id": element_id,
            "to_element_id": replacement["id"],
            "at": at,
        }
    )
    _remove(model, entity)
    return _serialize(model, identity, catalog)


def retire_element(artifacts, element_id, *, at):
    """Remove active IFC occurrence, retaining its historical identity and unresolved links."""
    model, identity, catalog = _candidate(artifacts)
    row, entity = _element(model, identity, element_id)
    _close_intervals(identity, element_id, at)
    row["state"] = "retired"
    identity["transitions"].append(
        {"kind": "retire", "from_element_id": element_id, "to_element_id": None, "at": at}
    )
    _remove(model, entity)
    return _serialize(model, identity, catalog)
