"""Immutable content-addressed concept revisions and bounded portable archive windows."""

from __future__ import annotations

import io
import os
import tempfile
import zipfile
from itertools import pairwise
from pathlib import Path

from growbim.program.intake import validate_program
from growbim.project.artifacts import DESIGN_FILES, design_request, validate_design_artifacts
from growbim.storage import (
    atomic_write,
    durable_mkdir,
    fsync_dir,
    sha256,
    validate_digest,
)
from opencea.contracts import ContractError, dumps, loads, parse_uuid, validate

MAX_ARCHIVE = 16 * 1024 * 1024
MAX_FILE = 4 * 1024 * 1024
MAX_REVISIONS = 128


def request_hash(request: dict, program: dict, parent_revision: str | None) -> str:
    return sha256(dumps(dict(request=request, program=program, parent_revision=parent_revision)))


def _project(root: Path, project_id: str) -> Path:
    project_id = parse_uuid(project_id)
    root = Path(root).resolve()
    project = root / "projects" / project_id
    for path in (root / "projects", project, project / "revisions"):
        if path.is_symlink():
            raise ContractError("symlink in project storage", code="storage_unavailable")
    return project


def _read_manifest(root: Path, project_id: str, revision: str) -> tuple[dict, bytes]:
    path = _project(root, project_id) / "revisions" / validate_digest(revision)
    if path.is_symlink() or (path / "manifest.json").is_symlink():
        raise ContractError("symlink in revision", code="storage_unavailable")
    if path.is_dir() and any(entry.is_symlink() for entry in path.iterdir()):
        raise ContractError("symlink in revision", code="storage_unavailable")
    try:
        manifest_path = path / "manifest.json"
        if manifest_path.stat().st_size > MAX_FILE:
            raise ContractError("oversized manifest", code="storage_unavailable")
        raw = manifest_path.read_bytes()
        manifest = loads(raw)
        validate("manifest", manifest)
        if {entry.name for entry in path.iterdir()} != {"manifest.json", *manifest["files"]}:
            raise ContractError("unexpected revision files", code="storage_unavailable")
        if manifest["project_id"] != project_id or manifest["revision"] != revision:
            raise ContractError("revision identity mismatch", code="storage_unavailable")
        base = {key: value for key, value in manifest.items() if key != "revision"}
        if sha256(dumps(base)) != revision:
            raise ContractError("manifest content hash mismatch", code="storage_unavailable")
        return manifest, raw
    except (OSError, UnicodeError) as exc:
        raise ContractError("missing revision manifest", code="storage_unavailable") from exc
    except ContractError as exc:
        raise ContractError(str(exc), code="storage_unavailable") from exc


def _check_program(manifest: dict, raw: bytes) -> dict:
    if len(raw) > MAX_FILE or sha256(raw) != manifest["files"]["program.json"]:
        raise ContractError("program content hash or size mismatch", code="storage_unavailable")
    try:
        program = loads(raw)
        validate_program(program)
        if program["project_id"] != manifest["project_id"]:
            raise ContractError("program project identity mismatch")
        if (
            request_hash(manifest["request"], program, manifest["parent_revision"])
            != manifest["request_hash"]
        ):
            raise ContractError("receipt does not bind its request and program")
        return program
    except (ContractError, KeyError) as exc:
        raise ContractError(str(exc), code="storage_unavailable") from exc


def _read_program(root: Path, project_id: str, manifest: dict) -> tuple[dict, bytes]:
    path = _project(root, project_id) / "revisions" / manifest["revision"] / "program.json"
    try:
        if path.stat().st_size > MAX_FILE:
            raise ContractError("oversized program", code="storage_unavailable")
        raw = path.read_bytes()
    except (OSError, UnicodeError) as exc:
        raise ContractError("missing revision program", code="storage_unavailable") from exc
    return _check_program(manifest, raw), raw


def read_program(root: Path, project_id: str, revision: str) -> dict:
    manifest, _ = _read_manifest(root, project_id, revision)
    program, _ = _read_program(root, project_id, manifest)
    _read_artifacts(root, project_id, manifest, program)
    return program


def _check_artifacts(manifest: dict, artifacts: dict[str, bytes], program: dict) -> None:
    declared = set(manifest["files"]) - {"program.json"}
    if declared != (set(DESIGN_FILES) if declared else set()) or set(artifacts) != declared:
        raise ContractError("incomplete design artifact set", code="storage_unavailable")
    for name, data in artifacts.items():
        if len(data) > MAX_FILE or sha256(data) != manifest["files"][name]:
            raise ContractError("design artifact hash or size mismatch", code="storage_unavailable")
    try:
        if artifacts:
            validate_design_artifacts(artifacts, program)
        _check_design_receipt(manifest, artifacts, program)
    except ContractError as exc:
        raise ContractError(str(exc), code="storage_unavailable") from exc


def _check_design_receipt(manifest: dict, artifacts: dict[str, bytes], program: dict) -> None:
    request = manifest["request"]
    if request.get("operation") == "accept_design" and not artifacts:
        raise ContractError("design acceptance requires artifacts")
    if request.get("operation") == "accept_design":
        _check_design_request(
            request,
            manifest["project_id"],
            manifest["parent_revision"],
            manifest["request_id"],
            artifacts,
            program,
        )
    elif artifacts and manifest["schema_version"] != "0.2":
        raise ContractError("design artifacts require versioned manifest")


def _check_design_request(
    request: dict,
    project_id: str,
    parent_revision: str,
    request_id: str,
    artifacts: dict[str, bytes],
    program: dict,
) -> None:
    if parent_revision is None:
        raise ContractError("design acceptance requires a parent revision")
    if request != design_request(
        project_id, parent_revision, request_id, artifacts, request.get("decision")
    ):
        raise ContractError("design request does not bind artifacts and decision")
    if not set(request["decision"]["source_ids"]).issubset(
        {source["id"] for source in program["sources"]}
    ):
        raise ContractError("design decision has unknown sources")


def _read_artifacts(root: Path, project_id: str, manifest: dict, program: dict) -> dict[str, bytes]:
    folder = _project(root, project_id) / "revisions" / manifest["revision"]
    artifacts = {}
    for name in manifest["files"]:
        if name == "program.json":
            continue
        path = folder / name
        if path.is_symlink():
            raise ContractError("symlink in revision", code="storage_unavailable")
        try:
            if path.stat().st_size > MAX_FILE:
                raise ContractError("oversized artifact", code="storage_unavailable")
            artifacts[name] = path.read_bytes()
        except OSError as exc:
            raise ContractError("missing revision artifact", code="storage_unavailable") from exc
    _check_artifacts(manifest, artifacts, program)
    return artifacts


def read_artifacts(root: Path, project_id: str, revision: str) -> dict[str, bytes]:
    manifest, _ = _read_manifest(root, project_id, revision)
    program, _ = _read_program(root, project_id, manifest)
    return _read_artifacts(root, project_id, manifest, program)


def prepare_revision(
    root: Path,
    project_id: str,
    parent_revision: str | None,
    request_id: str,
    request: dict,
    program: dict,
    *,
    artifacts: dict[str, bytes] | None = None,
) -> dict:
    project_id = parse_uuid(project_id)
    request_id = parse_uuid(request_id)
    if parent_revision is not None:
        validate_digest(parent_revision)
    if not isinstance(request, dict):
        raise ContractError("request must be an object")
    validate_program(program)
    if program["project_id"] != project_id:
        raise ContractError("program project identity mismatch")
    if artifacts is None and request.get("operation") == "accept_design":
        raise ContractError("design acceptance requires explicit artifacts")
    if artifacts is not None:
        if parent_revision is None or request.get("operation") != "accept_design":
            raise ContractError("artifact replacement requires design acceptance")
        _check_design_request(request, project_id, parent_revision, request_id, artifacts, program)
        if any(len(value) > MAX_FILE for value in artifacts.values()):
            raise ContractError("design artifact exceeds size limit")
        validate_design_artifacts(artifacts, program, native=True)
    elif parent_revision is not None:
        artifacts = read_artifacts(root, project_id, parent_revision)
        if artifacts:
            validate_design_artifacts(artifacts, program)
    else:
        artifacts = {}
    if parent_revision is not None:
        parent = read_program(root, project_id, parent_revision)
        if request.get("operation") == "accept_design" and program != parent:
            raise ContractError("design acceptance cannot change the program")
        prior = {item["id"]: item for item in parent["hypotheses"]}
        current = {item["id"]: item for item in program["hypotheses"]}
        prior_resolutions = {item["hypothesis_id"]: item for item in parent["resolutions"]}
        current_resolutions = {item["hypothesis_id"]: item for item in program["resolutions"]}
        if any(
            current.get(identifier) != prior[identifier]
            or current_resolutions.get(identifier) != resolution
            for identifier, resolution in prior_resolutions.items()
        ):
            raise ContractError(
                "decided hypothesis cannot be changed or removed",
                code="decided_hypothesis_locked",
            )
        for collection in ("sources", "statements"):
            if not {item["id"] for item in parent[collection]}.issubset(
                {item["id"] for item in program[collection]}
            ):
                raise ContractError(f"{collection} cannot be removed", code="provenance_removal")
    raw = dumps(program)
    if len(raw) > MAX_FILE:
        raise ContractError("program exceeds size limit")
    receipt_hash = request_hash(request, program, parent_revision)
    project = _project(root, project_id)
    revisions = project / "revisions"
    durable_mkdir(revisions)
    base = dict(
        schema_version="0.2" if artifacts else "0.1",
        project_id=project_id,
        parent_revision=parent_revision,
        request_id=request_id,
        request=request,
        request_hash=receipt_hash,
        files={
            "program.json": sha256(raw),
            **{name: sha256(value) for name, value in artifacts.items()},
        },
    )
    revision = sha256(dumps(base))
    manifest = dict(base, revision=revision)
    manifest_raw = dumps(manifest)
    if len(manifest_raw) > MAX_FILE:
        raise ContractError("request receipt exceeds size limit")
    if len(manifest_raw) + len(raw) + sum(map(len, artifacts.values())) > MAX_ARCHIVE:
        raise ContractError("revision exceeds archive size limit")
    target = revisions / revision
    if target.exists() or target.is_symlink():
        existing, _ = _read_manifest(root, project_id, revision)
        if existing != manifest:
            raise ContractError("revision collision")
        read_program(root, project_id, revision)
        fsync_dir(revisions)
        return manifest
    pending = Path(tempfile.mkdtemp(dir=revisions, prefix=".pending-"))
    try:
        atomic_write(pending / "program.json", raw)
        for name, data in artifacts.items():
            atomic_write(pending / name, data)
        atomic_write(pending / "manifest.json", manifest_raw)
        fsync_dir(pending)
        os.replace(pending, target)
        fsync_dir(revisions)
    finally:
        if pending.exists():
            for entry in pending.iterdir():
                entry.unlink()
            pending.rmdir()
    return manifest


def revision_history(root: Path, project_id: str, revision: str):
    """Yield verified newest-first records within the portable export history window."""
    seen = set()
    marker = _project(root, project_id) / "WINDOW"
    try:
        if marker.is_symlink():
            raise ContractError("symlink in revision")
        boundary = (
            validate_digest(marker.read_text(encoding="ascii").strip()) if marker.exists() else None
        )
    except (OSError, UnicodeError, ContractError) as exc:
        raise ContractError(
            "unreadable history window boundary", code="storage_unavailable"
        ) from exc
    expanded = 0
    while revision is not None and revision != boundary and len(seen) < MAX_REVISIONS:
        if revision in seen:
            raise ContractError("cyclic revision history", code="storage_unavailable")
        seen.add(revision)
        manifest, manifest_raw = _read_manifest(root, project_id, revision)
        program, program_raw = _read_program(root, project_id, manifest)
        artifacts = _read_artifacts(root, project_id, manifest, program)
        expanded += len(manifest_raw) + len(program_raw) + sum(map(len, artifacts.values()))
        if expanded > MAX_ARCHIVE:
            raise ContractError("expanded history exceeds archive size limit")
        yield manifest, manifest_raw, program_raw, artifacts
        revision = manifest["parent_revision"]


def archive_header(project_id: str, revision: str, boundary: str | None) -> dict:
    """Build the portable archive header; window_parent_revision marks a truncated window."""
    header = dict(schema_version="0.1", project_id=project_id, revision=revision)
    if boundary is not None:
        header["window_parent_revision"] = boundary
    return header


def parse_archive_header(header: dict) -> tuple[str, str, str | None]:
    """Validate an archive header; return (project_id, revision, window_parent_revision)."""
    if (
        not isinstance(header, dict)
        or not {"schema_version", "project_id", "revision"}.issubset(header)
        or set(header) - {"schema_version", "project_id", "revision", "window_parent_revision"}
        or header["schema_version"] != "0.1"
    ):
        raise ContractError("invalid archive header")
    project_id = parse_uuid(header["project_id"])
    revision = validate_digest(header["revision"])
    boundary = header.get("window_parent_revision")
    if boundary is not None:
        validate_digest(boundary)
    return project_id, revision, boundary


def export_project(root: Path, project_id: str, revision: str) -> bytes:
    records = list(revision_history(root, project_id, revision))
    boundary = records[-1][0]["parent_revision"]
    header = archive_header(project_id, revision, boundary)
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        header_raw = dumps(header)
        archive.writestr("project.json", header_raw)
        expanded = len(header_raw)
        for manifest, manifest_raw, program, artifacts in records:
            expanded += len(manifest_raw) + len(program) + sum(map(len, artifacts.values()))
            if expanded > MAX_ARCHIVE:
                raise ContractError("expanded history exceeds archive size limit")
            prefix = f"revisions/{manifest['revision']}/"
            archive.writestr(prefix + "manifest.json", manifest_raw)
            archive.writestr(prefix + "program.json", program)
            for name in DESIGN_FILES:
                if name in artifacts:
                    archive.writestr(prefix + name, artifacts[name])
            if buffer.tell() > MAX_ARCHIVE:
                raise ContractError("archive exceeds size limit")
    data = buffer.getvalue()
    if len(data) > MAX_ARCHIVE:
        raise ContractError("archive exceeds size limit")
    return data


def import_project(root: Path, data: bytes) -> dict:
    if len(data) > MAX_ARCHIVE:
        raise ContractError("archive exceeds size limit")
    try:
        archive = zipfile.ZipFile(io.BytesIO(data))
        infos = archive.infolist()
        if len(infos) > 5 * MAX_REVISIONS + 1 or len({i.filename for i in infos}) != len(infos):
            raise ContractError("duplicate or excessive archive members")
        members = {}
        total = 0
        for info in infos:
            parts = info.filename.split("/")
            valid = info.filename == "project.json" or (
                len(parts) == 3
                and parts[0] == "revisions"
                and parts[1]
                and parts[2] in ("manifest.json", "program.json", *DESIGN_FILES)
            )
            if not valid or info.is_dir() or info.external_attr >> 16 & 0o170000 == 0o120000:
                raise ContractError("unsafe archive member")
            if info.file_size > MAX_FILE or info.compress_size > MAX_FILE:
                raise ContractError("oversized archive member")
            total += info.file_size
            if total > MAX_ARCHIVE:
                raise ContractError("excessive expanded archive size")
            content = archive.read(info)
            if len(content) != info.file_size:
                raise ContractError("truncated archive")
            members[info.filename] = content
        header = loads(members["project.json"])
        project_id, revision, boundary = parse_archive_header(header)
        chain = []
        current = revision
        seen = set()
        while current is not None and current != boundary:
            if current in seen or len(seen) >= MAX_REVISIONS:
                raise ContractError("cyclic or excessive archive history")
            seen.add(current)
            prefix = f"revisions/{current}/"
            manifest = loads(members[prefix + "manifest.json"])
            program_raw = members[prefix + "program.json"]
            validate("manifest", manifest)
            if (
                manifest["revision"] != current
                or manifest["project_id"] != project_id
                or sha256(dumps({k: v for k, v in manifest.items() if k != "revision"})) != current
                or manifest["files"]["program.json"] != sha256(program_raw)
            ):
                raise ContractError("archive hash or identity mismatch")
            program = _check_program(manifest, program_raw)
            artifacts = {
                name: members[prefix + name] for name in manifest["files"] if name != "program.json"
            }
            _check_artifacts(manifest, artifacts, program)
            if manifest["parent_revision"] is None and artifacts:
                raise ContractError("design artifacts require a parent revision")
            if artifacts:
                validate_design_artifacts(artifacts, program, native=True)
            chain.append((manifest, members[prefix + "manifest.json"], program_raw, artifacts))
            current = manifest["parent_revision"]
        # A regular concept edit may only carry forward the exact accepted byte set.
        for child, parent in pairwise(chain):
            child_manifest, _, _, child_artifacts = child
            parent_manifest, _, _, parent_artifacts = parent
            if child_manifest["parent_revision"] != parent_manifest["revision"]:
                raise ContractError("broken archive parent chain")
            if child_manifest["request"].get("operation") == "accept_design" and loads(
                child[2]
            ) != loads(parent[2]):
                raise ContractError("design acceptance changed the program")
            if (
                child_manifest["request"].get("operation") != "accept_design"
                and child_artifacts != parent_artifacts
            ):
                raise ContractError("concept revision changed design artifacts")
        if boundary is not None and (len(chain) != MAX_REVISIONS or boundary in seen):
            raise ContractError("invalid archive window boundary")
        if set(members) != {"project.json"} | {
            f"revisions/{m['revision']}/{name}"
            for m, _, _, _ in chain
            for name in ("manifest.json", *m["files"])
        }:
            raise ContractError("unreferenced archive members")
        project = _project(root, project_id)
        revisions = project / "revisions"
        durable_mkdir(revisions)
        missing = []
        for manifest, manifest_raw, raw, artifacts in reversed(chain):
            target = revisions / manifest["revision"]
            if target.exists() or target.is_symlink():
                existing, existing_raw = _read_manifest(root, project_id, manifest["revision"])
                if existing_raw != manifest_raw or existing != manifest:
                    raise ContractError("import conflicts with existing revision")
                existing_program, program_raw = _read_program(root, project_id, manifest)
                if (
                    raw != program_raw
                    or _read_artifacts(root, project_id, manifest, existing_program) != artifacts
                ):
                    raise ContractError("import conflicts with existing revision files")
            else:
                missing.append((manifest, manifest_raw, raw, artifacts))
        for manifest, manifest_raw, raw, artifacts in missing:
            target = revisions / manifest["revision"]
            pending = Path(tempfile.mkdtemp(dir=revisions, prefix=".pending-"))
            try:
                atomic_write(pending / "program.json", raw)
                for name, payload in artifacts.items():
                    atomic_write(pending / name, payload)
                atomic_write(pending / "manifest.json", manifest_raw)
                fsync_dir(pending)
                os.replace(pending, target)
                fsync_dir(revisions)
            finally:
                if pending.exists():
                    for entry in pending.iterdir():
                        entry.unlink()
                    pending.rmdir()
        if boundary is not None:
            marker = project / "WINDOW"
            if marker.is_symlink():
                raise ContractError("symlink in revision", code="storage_unavailable")
            atomic_write(marker, (boundary + "\n").encode("ascii"))
        fsync_dir(revisions)
        return dict(project_id=project_id, revision=revision, revisions=len(chain))
    except (KeyError, OSError, zipfile.BadZipFile, ValueError) as exc:
        if isinstance(exc, ContractError):
            raise
        raise ContractError(f"invalid concept archive: {exc}") from exc
