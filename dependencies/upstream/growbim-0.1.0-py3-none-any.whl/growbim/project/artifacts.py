"""Closed design artifact set and canonical acceptance request."""

from __future__ import annotations

from growbim.storage import sha256
from opencea.contracts import ContractError, loads, parse_uuid, validate
from opencea.identity import validate_identity_map

DESIGN_FILES = ("model.ifc", "identity-map.json", "catalog.json")


def _files(artifacts: dict[str, bytes]) -> None:
    if not isinstance(artifacts, dict) or set(artifacts) != set(DESIGN_FILES):
        raise ContractError("design requires exactly three declared artifacts")
    if any(not isinstance(data, bytes) for data in artifacts.values()):
        raise ContractError("design artifacts must be bytes")


def validate_design_artifacts(
    artifacts: dict[str, bytes], program: dict, *, native: bool = False
) -> None:
    """Check provenance without native imports; validate IFC only when requested."""
    _files(artifacts)
    identity = loads(artifacts["identity-map.json"])
    catalog = loads(artifacts["catalog.json"])
    if identity.get("schema_version") != "0.2" or catalog.get("schema_version") != "0.2":
        raise ContractError("design requires active identity and catalog versions")
    validate("identity-map", identity)
    validate("catalog", catalog)
    if identity["project_id"] != program["project_id"] or identity["model_sha256"] != sha256(
        artifacts["model.ifc"]
    ):
        raise ContractError("design model or project identity mismatch")
    validate_identity_map(identity, catalog, program)
    if native:
        from growbim.ifc import validate_candidate

        validate_candidate(artifacts, program)


def design_request(
    project_id: str,
    expected_revision: str,
    request_id: str,
    artifacts: dict[str, bytes],
    decision: dict,
) -> dict:
    """Bind the complete byte set and an explicitly sourced reviewer decision."""
    _files(artifacts)
    if not isinstance(decision, dict) or set(decision) != {"reviewer", "reason", "source_ids"}:
        raise ContractError("invalid design decision")
    if any(
        not isinstance(decision[key], str) or not decision[key].strip()
        for key in ("reviewer", "reason")
    ):
        raise ContractError("design requires reviewer and reason")
    source_ids = decision["source_ids"]
    if (
        not isinstance(source_ids, list)
        or not source_ids
        or any(not isinstance(source, str) or parse_uuid(source) != source for source in source_ids)
        or len(source_ids) != len(set(source_ids))
    ):
        raise ContractError("design decision requires distinct source IDs")
    from growbim.storage import validate_digest

    return {
        "operation": "accept_design",
        "project_id": parse_uuid(project_id),
        "expected_revision": validate_digest(expected_revision),
        "request_id": parse_uuid(request_id),
        "artifacts": {name: sha256(artifacts[name]) for name in sorted(DESIGN_FILES)},
        "decision": {
            "reviewer": decision["reviewer"],
            "reason": decision["reason"],
            "source_ids": source_ids[:],
        },
    }
