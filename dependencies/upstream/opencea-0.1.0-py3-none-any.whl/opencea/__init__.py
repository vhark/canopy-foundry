"""OpenCEA local contracts; no network or application framework dependency."""
