"""Strict local JSON Schema 2020-12 contracts. Schema identifiers never resolve over the network."""

from __future__ import annotations

import json
import math
from functools import cache, lru_cache
from importlib.resources import files
from typing import Any
from uuid import UUID, uuid5

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource
from referencing.exceptions import Unresolvable
from rfc3339_validator import validate_rfc3339


class ContractError(ValueError):
    def __init__(self, message: str, *, code: str = "invalid_contract"):
        super().__init__(message)
        self.code = code


def parse_uuid(value: str) -> str:
    try:
        return str(UUID(value))
    except (ValueError, TypeError, AttributeError) as exc:
        raise ContractError("invalid UUID", code="invalid_uuid") from exc


# Private v0.1 schema namespace; never change it or existing filenames:
# each resource identifier is urn:uuid:<uuid5(namespace, filename)>.
_SCHEMA_NAMESPACE = UUID("c6f82219-7c47-497b-80cd-c0951a9b144c")
_SCHEMA_NAMESPACE_02 = UUID("67af3412-a1b3-4e29-ae14-f94122ce0402")


def _schema_id(filename: str, version: str = "0.1") -> str:
    namespace = _SCHEMA_NAMESPACE if version == "0.1" else _SCHEMA_NAMESPACE_02
    return f"urn:uuid:{uuid5(namespace, filename)}"


def _reject_unregistered(uri: str) -> Resource:
    raise ContractError(f"remote or unknown schema reference: {uri}")


def _unique(pairs: list[tuple[str, Any]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise ContractError(f"duplicate JSON key: {key}", code="invalid_json")
        result[key] = value
    return result


def _nonfinite(value: str) -> None:
    raise ContractError(f"non-finite JSON number: {value}", code="invalid_json")


def _finite_float(value: str) -> float:
    number = float(value)
    if not math.isfinite(number):
        raise ContractError("non-finite JSON number", code="invalid_json")
    return number


def loads(text: str | bytes) -> dict:
    try:
        value = json.loads(
            text, object_pairs_hook=_unique, parse_constant=_nonfinite, parse_float=_finite_float
        )
    except ContractError:
        raise
    except (ValueError, UnicodeError, RecursionError) as exc:
        raise ContractError(str(exc), code="invalid_json") from exc
    if not isinstance(value, dict):
        raise ContractError("top-level JSON must be an object", code="invalid_json")
    return value


def dumps(value: Any) -> bytes:
    try:
        return json.dumps(
            value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
        ).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise ContractError(str(exc)) from exc


@lru_cache(maxsize=1)
def _schemas() -> tuple[dict[tuple[str, str], dict], Registry]:
    schemas = {}
    resources = []
    for version in ("0.1", "0.2"):
        folder = files("opencea").joinpath("schemas", version)
        for entry in folder.iterdir():
            if entry.name.endswith(".json"):
                schema = loads(entry.read_text(encoding="utf-8"))
                Draft202012Validator.check_schema(schema)
                identifier = _schema_id(entry.name, version)
                if schema.get("$id") != identifier:
                    raise ContractError(f"untrusted schema identifier in {entry.name}")
                if entry.name != "definitions.json":
                    schemas[(version, entry.name[:-5])] = schema
                resources.append((identifier, Resource.from_contents(schema)))
    local_ids = {identifier for identifier, _ in resources}
    registry = Registry(retrieve=_reject_unregistered).with_resources(resources)

    def scan(value: Any, identifier: str) -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                if key == "$id" and child != identifier:
                    raise ContractError(f"untrusted schema identifier: {child}")
                if key in ("$ref", "$dynamicRef") and isinstance(child, str):
                    target = child.split("#", 1)[0]
                    if (target or identifier) not in local_ids:
                        raise ContractError(f"remote or unknown schema reference: {child}")
                    try:
                        registry.resolver(base_uri=identifier).lookup(child)
                    except Unresolvable as exc:
                        raise ContractError(f"remote or unknown schema reference: {child}") from exc
                scan(child, identifier)
        elif isinstance(value, list):
            for child in value:
                scan(child, identifier)

    for identifier, resource in resources:
        scan(resource.contents, identifier)
    return schemas, registry


@cache
def _validator(kind: str, version: str = "0.1") -> Draft202012Validator:
    schemas, registry = _schemas()
    if (version, kind) not in schemas:
        raise ContractError(f"unknown schema kind/version: {kind}/{version}")
    checker = FormatChecker()
    checker.checks("date-time")(lambda value: not isinstance(value, str) or validate_rfc3339(value))
    return Draft202012Validator(schemas[(version, kind)], registry=registry, format_checker=checker)


def load_document(kind: str, text: str | bytes) -> dict:
    """Intake a typed, schema-checked standalone document."""
    document = loads(text)
    validate(kind, document)
    return document


def validate(kind: str, payload: dict) -> None:
    if not isinstance(payload, dict):
        raise ContractError("payload must be an object")
    # Also detects invalid/nonfinite in Python dictionaries before schema evaluation.
    loads(dumps(payload))
    version = payload.get("schema_version", "0.1")
    if not isinstance(version, str) or version not in ("0.1", "0.2"):
        raise ContractError(f"unsupported schema version: {version}")
    validator = _validator(kind, version)
    errors = sorted(
        validator.iter_errors(payload),
        key=lambda error: (tuple(str(p) for p in error.absolute_path), error.message),
    )
    if errors:
        error = errors[0]
        raise ContractError(f"{'.'.join(map(str, error.absolute_path)) or kind}: {error.message}")
