"""Pure, source-backed identity and temporal consistency for accepted IFC candidates."""

from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timedelta
from itertools import pairwise
from uuid import UUID

from opencea.contracts import ContractError, validate


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ContractError(message)


def _utc(value: str) -> datetime:
    # The schema enforces RFC3339 and an explicit zero UTC offset.
    stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
    _require(stamp.utcoffset() == timedelta(0), "timestamp must be UTC")
    return stamp


def _sources(record: dict, known: set[str], description: str) -> None:
    for source in record["source_ids"]:
        _require(source in known, f"{description}: unknown source {source}")


def _index(records: list[dict], namespace: str, occupied: set[UUID]) -> dict[str, dict]:
    indexed = {}
    for record in records:
        identifier = record["id"]
        key = UUID(identifier)
        _require(
            key not in occupied, f"duplicate {namespace} identity across namespaces: {identifier}"
        )
        occupied.add(key)
        indexed[identifier] = record
    return indexed


def _intervals(records: list[dict], key: str, label: str) -> None:
    groups: dict[str, list[tuple[datetime, datetime | None]]] = defaultdict(list)
    for record in records:
        start = _utc(record["starts_at"])
        end = _utc(record["ends_at"]) if record["ends_at"] is not None else None
        _require(end is None or end > start, f"{label} end must follow start")
        groups[record[key]].append((start, end))
    for intervals in groups.values():
        intervals.sort(key=lambda interval: interval[0])
        for previous, following in pairwise(intervals):
            _require(
                previous[1] is not None and previous[1] <= following[0],
                f"{label} intervals overlap",
            )


def validate_identity_map(identity: dict, catalog: dict, program: dict) -> None:
    """Validate closed identity records, typed references, sources and UTC history.

    This is deliberately independent of IFC: native checks of actual entities and
    model bytes belong to the optional IFC adapter, not program readers.
    """
    validate("identity-map", identity)
    _require(identity["schema_version"] == "0.2", "identity map requires schema version 0.2")
    validate("catalog", catalog)
    validate("program", program)
    _require(identity["project_id"] == program["project_id"], "identity project mismatch")

    sources = {record["id"] for record in program["sources"]}
    _require(len(sources) == len(program["sources"]), "duplicate program source")
    _sources(identity, sources, "identity map")
    occupied = {UUID(identity["id"])}
    products = _index(catalog["items"], "product", occupied)
    subjects = _index(identity["subjects"], "subject", occupied)
    roles = _index(identity["roles"], "role", occupied)
    assets = _index(identity["assets"], "asset", occupied)
    elements = _index(identity["elements"], "element", occupied)
    channels = _index(identity["channels"], "channel", occupied)
    _index(identity["deployments"], "deployment", occupied)
    _index(identity["occupancies"], "occupancy", occupied)

    statements = {statement["id"]: statement for statement in program["statements"]}
    _require(len(statements) == len(program["statements"]), "duplicate program statement")
    for item in products.values():
        _sources(item, sources, "catalog product")
        for value in item["properties"].values():
            _sources(value, sources, "catalog quantity")
            _require(type(value["value"]) in (int, float), "catalog quantity must be numeric")
    used_statements: set[str] = set()
    for subject in subjects.values():
        _sources(subject, sources, "subject")
        for identifier in subject["statement_ids"]:
            statement = statements.get(identifier)
            _require(
                statement is not None
                and statement["subject_id"] == subject["id"]
                and statement["kind"] in ("reported", "verified"),
                f"subject has unknown, hypothetical or unrelated statement: {identifier}",
            )
            _require(identifier not in used_statements, "statement belongs to multiple subjects")
            used_statements.add(identifier)
            _sources(statement, sources, "subject statement")
    for role in roles.values():
        _sources(role, sources, "role")
    for asset in assets.values():
        _sources(asset, sources, "asset")
        _require(asset["product_id"] in products, "asset references unknown catalog product")
    for channel in channels.values():
        _sources(channel, sources, "channel")

    global_ids = set()
    attached_assets = set()
    for element in elements.values():
        global_id = element["ifc_global_id"]
        _require(global_id not in global_ids, "duplicate IFC GlobalId across element history")
        global_ids.add(global_id)
        product_id, role_id, asset_id = (
            element[key] for key in ("product_id", "role_id", "asset_id")
        )
        _require(product_id is None or product_id in products, "element references unknown product")
        _require(role_id is None or role_id in roles, "element references unknown role")
        _require(asset_id is None or asset_id in assets, "element references unknown asset")
        _require(
            asset_id is None or element["evidence_kind"] == "reported",
            "proposed element cannot have an installed asset",
        )
        if asset_id is not None:
            _require(asset_id not in attached_assets, "asset attached to multiple elements")
            attached_assets.add(asset_id)
            _require(
                product_id == assets[asset_id]["product_id"],
                "asset and element catalog products disagree",
            )
    for asset_id in assets:
        _require(asset_id in attached_assets, "installed asset has no mapped element")

    bindings = set()
    for binding in identity["bindings"]:
        subject_id, element_id = binding["program_subject_id"], binding["element_id"]
        _require(subject_id in subjects, "binding references unknown explicit program subject")
        _require(
            element_id in elements and elements[element_id]["state"] == "active",
            "binding requires an active element",
        )
        pair = subject_id, element_id
        _require(pair not in bindings, "duplicate binding")
        bindings.add(pair)
    unresolved = set()
    for binding in identity["unresolved_bindings"]:
        subject_id, element_id = binding["program_subject_id"], binding["element_id"]
        _require(subject_id in subjects, "unresolved binding references unknown subject")
        _require(
            element_id in elements and elements[element_id]["state"] == "retired",
            "unresolved binding requires a retired element",
        )
        pair = subject_id, element_id
        _require(
            pair not in unresolved and pair not in bindings, "duplicate or contradictory binding"
        )
        unresolved.add(pair)

    retiring: dict[str, datetime] = {}
    created: dict[str, tuple[datetime, str]] = {}
    seen_transitions = set()
    for transition in identity["transitions"]:
        kind = transition["kind"]
        source_id, target_id = transition["from_element_id"], transition["to_element_id"]
        _require(source_id in elements, "transition references unknown originating element")
        _require(
            (target_id is None) == (kind == "retire"),
            "retire requires null target; copy and replace require a target",
        )
        _require(
            target_id is None or target_id in elements and target_id != source_id,
            "transition references unknown or identical target",
        )
        when = _utc(transition["at"])
        transition_key = kind, source_id, target_id, when
        _require(transition_key not in seen_transitions, "duplicate transition")
        seen_transitions.add(transition_key)
        if kind in ("retire", "replace"):
            _require(elements[source_id]["state"] == "retired", "transition origin must be retired")
            _require(source_id not in retiring, "retired element has multiple exit transitions")
            retiring[source_id] = when
        if target_id is not None:
            _require(target_id not in created, "element has multiple creation transitions")
            created[target_id] = (when, source_id)
        if kind == "replace":
            _require(
                elements[source_id]["asset_id"] is not None
                and elements[target_id]["asset_id"] is not None,
                "replacement requires old and new installed units",
            )
    for element in elements.values():
        _require(
            (element["id"] in retiring) == (element["state"] == "retired"),
            "retired element requires exactly one retirement transition",
        )
        origin = created.get(element["id"])
        if origin is not None and element["id"] in retiring:
            _require(origin[0] < retiring[element["id"]], "element retirement must follow creation")
    for transition in identity["transitions"]:
        source_id = transition["from_element_id"]
        when = _utc(transition["at"])
        if source_id in created:
            _require(created[source_id][0] <= when, "transition precedes source creation")
        if transition["kind"] == "copy" and source_id in retiring:
            _require(when < retiring[source_id], "cannot copy a retired physical element")
    # Equal timestamps do not make a circular creation history possible.
    checked = set()
    for element_id in created:
        lineage = set()
        while element_id in created and element_id not in checked:
            _require(element_id not in lineage, "cyclic element creation history")
            lineage.add(element_id)
            element_id = created[element_id][1]
        checked.update(lineage)

    for deployment in identity["deployments"]:
        channel_id, asset_id, element_id = (
            deployment[key] for key in ("channel_id", "asset_id", "element_id")
        )
        _require(channel_id in channels, "deployment references unknown channel")
        _require(asset_id in assets, "deployment references unknown asset")
        _require(element_id in elements, "deployment references unknown element")
        _require(
            elements[element_id]["asset_id"] == asset_id,
            "deployment asset is not installed on its element",
        )
    for occupancy in identity["occupancies"]:
        role_id, element_id = occupancy["role_id"], occupancy["element_id"]
        _require(
            role_id in roles and element_id in elements,
            "occupancy references unknown role or element",
        )
        _require(
            elements[element_id]["role_id"] == role_id,
            "occupancy role is not assigned to its element",
        )
    _intervals(identity["deployments"], "channel_id", "channel deployment")
    _intervals(identity["occupancies"], "role_id", "role occupancy")
    for record in (*identity["deployments"], *identity["occupancies"]):
        origin = created.get(record["element_id"])
        if origin is not None:
            _require(
                _utc(record["starts_at"]) >= origin[0],
                "temporal interval precedes element creation",
            )
        retired_at = retiring.get(record["element_id"])
        if retired_at is not None:
            end = record["ends_at"]
            _require(
                end is not None and _utc(end) <= retired_at,
                "retired element has an open or post-retirement interval",
            )
